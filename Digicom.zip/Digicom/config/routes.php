<?php
declare(strict_types=1);

use App\Core\Router;
use App\Middleware\AuthMiddleware;
use App\Middleware\CsrfMiddleware;

/**
 * Fichier de définition des routes DIGI ERP
 * Retourne un callable qui configure le routeur
 */

return function (Router $router): void {
    $auth = [AuthMiddleware::class];
    $authCsrf = [AuthMiddleware::class, CsrfMiddleware::class];

    // ============================================
    // AUTHENTIFICATION
    // ============================================
    $router->get('/login', 'App\Controllers\AuthController', 'loginForm');
    $router->post('/login', 'App\Controllers\AuthController', 'login', [CsrfMiddleware::class]);
    $router->get('/logout', 'App\Controllers\AuthController', 'logout');
    $router->get('/change-password', 'App\Controllers\AuthController', 'changePasswordForm', $auth);
    $router->post('/change-password', 'App\Controllers\AuthController', 'changePassword', $authCsrf);
    $router->get('/2fa', 'App\Controllers\AuthController', 'twoFactorForm');
    $router->post('/2fa', 'App\Controllers\AuthController', 'twoFactorVerify', [CsrfMiddleware::class]);

    // ============================================
    // DASHBOARD
    // ============================================
    $router->get('/', 'App\Controllers\DashboardController', 'index', $auth);
    $router->get('/dashboard', 'App\Controllers\DashboardController', 'index', $auth);
    $router->get('/dashboard/stats', 'App\Controllers\DashboardController', 'stats', $auth);

    // ============================================
    // CRM
    // ============================================
    $router->get('/crm', 'App\Controllers\CrmController', 'index', $auth);
    $router->get('/crm/clients', 'App\Controllers\CrmController', 'clients', $auth);
    $router->get('/crm/clients/create', 'App\Controllers\CrmController', 'createClient', $auth);
    $router->post('/crm/clients/create', 'App\Controllers\CrmController', 'storeClient', $authCsrf);
    $router->get('/crm/clients/{id}', 'App\Controllers\CrmController', 'showClient', $auth);
    $router->get('/crm/clients/{id}/edit', 'App\Controllers\CrmController', 'editClient', $auth);
    $router->post('/crm/clients/{id}/edit', 'App\Controllers\CrmController', 'updateClient', $authCsrf);
    $router->post('/crm/clients/{id}/delete', 'App\Controllers\CrmController', 'deleteClient', $authCsrf);
    $router->get('/crm/kanban', 'App\Controllers\CrmController', 'kanban', $auth);
    $router->post('/crm/kanban/update', 'App\Controllers\CrmController', 'updateKanban', $authCsrf);
    $router->get('/crm/export', 'App\Controllers\CrmController', 'export', $auth);
    $router->post('/crm/import', 'App\Controllers\CrmController', 'import', $authCsrf);

    // ============================================
    // GESTION COMMERCIALE
    // ============================================
    $router->get('/commercial', 'App\Controllers\CommercialController', 'index', $auth);
    $router->get('/commercial/quotes', 'App\Controllers\CommercialController', 'quotes', $auth);
    $router->get('/commercial/quotes/create', 'App\Controllers\CommercialController', 'createQuote', $auth);
    $router->post('/commercial/quotes/create', 'App\Controllers\CommercialController', 'storeQuote', $authCsrf);
    $router->get('/commercial/quotes/{id}', 'App\Controllers\CommercialController', 'showQuote', $auth);
    $router->get('/commercial/quotes/{id}/edit', 'App\Controllers\CommercialController', 'editQuote', $auth);
    $router->post('/commercial/quotes/{id}/edit', 'App\Controllers\CommercialController', 'updateQuote', $authCsrf);
    $router->post('/commercial/quotes/{id}/convert', 'App\Controllers\CommercialController', 'convertToInvoice', $authCsrf);
    $router->get('/commercial/quotes/{id}/pdf', 'App\Controllers\CommercialController', 'quotePdf', $auth);
    $router->get('/commercial/invoices', 'App\Controllers\CommercialController', 'invoices', $auth);
    $router->get('/commercial/invoices/create', 'App\Controllers\CommercialController', 'createInvoice', $auth);
    $router->post('/commercial/invoices/create', 'App\Controllers\CommercialController', 'storeInvoice', $authCsrf);
    $router->get('/commercial/invoices/{id}', 'App\Controllers\CommercialController', 'showInvoice', $auth);
    $router->post('/commercial/invoices/{id}/payment', 'App\Controllers\CommercialController', 'addPayment', $authCsrf);
    $router->get('/commercial/invoices/{id}/pdf', 'App\Controllers\CommercialController', 'invoicePdf', $auth);
    $router->get('/commercial/receivables', 'App\Controllers\CommercialController', 'receivables', $auth);

    // ============================================
    // GESTION DE PROJETS
    // ============================================
    $router->get('/projects', 'App\Controllers\ProjectController', 'index', $auth);
    $router->get('/projects/create', 'App\Controllers\ProjectController', 'create', $auth);
    $router->post('/projects/create', 'App\Controllers\ProjectController', 'store', $authCsrf);
    $router->get('/projects/{id}', 'App\Controllers\ProjectController', 'show', $auth);
    $router->get('/projects/{id}/edit', 'App\Controllers\ProjectController', 'edit', $auth);
    $router->post('/projects/{id}/edit', 'App\Controllers\ProjectController', 'update', $authCsrf);
    $router->post('/projects/{id}/close', 'App\Controllers\ProjectController', 'close', $authCsrf);
    $router->get('/projects/{id}/gantt', 'App\Controllers\ProjectController', 'gantt', $auth);
    $router->get('/tasks', 'App\Controllers\ProjectController', 'tasks', $auth);
    $router->get('/tasks/create', 'App\Controllers\ProjectController', 'createTask', $auth);
    $router->post('/tasks/create', 'App\Controllers\ProjectController', 'storeTask', $authCsrf);
    $router->get('/tasks/{id}', 'App\Controllers\ProjectController', 'showTask', $auth);
    $router->get('/tasks/{id}/edit', 'App\Controllers\ProjectController', 'editTask', $auth);
    $router->post('/tasks/{id}/edit', 'App\Controllers\ProjectController', 'updateTask', $authCsrf);
    $router->post('/tasks/{id}/status', 'App\Controllers\ProjectController', 'updateTaskStatus', $authCsrf);
    $router->post('/tasks/{id}/comment', 'App\Controllers\ProjectController', 'addComment', $authCsrf);

    // ============================================
    // RESSOURCES HUMAINES
    // ============================================
    $router->get('/hr', 'App\Controllers\HrController', 'index', $auth);
    $router->get('/hr/employees', 'App\Controllers\HrController', 'employees', $auth);
    $router->get('/hr/employees/create', 'App\Controllers\HrController', 'createEmployee', $auth);
    $router->post('/hr/employees/create', 'App\Controllers\HrController', 'storeEmployee', $authCsrf);
    $router->get('/hr/employees/{id}', 'App\Controllers\HrController', 'showEmployee', $auth);
    $router->get('/hr/employees/{id}/edit', 'App\Controllers\HrController', 'editEmployee', $auth);
    $router->post('/hr/employees/{id}/edit', 'App\Controllers\HrController', 'updateEmployee', $authCsrf);
    $router->get('/hr/leaves', 'App\Controllers\HrController', 'leaves', $auth);
    $router->get('/hr/leaves/create', 'App\Controllers\HrController', 'createLeave', $auth);
    $router->post('/hr/leaves/create', 'App\Controllers\HrController', 'storeLeave', $authCsrf);
    $router->post('/hr/leaves/{id}/approve', 'App\Controllers\HrController', 'approveLeave', $authCsrf);
    $router->post('/hr/leaves/{id}/reject', 'App\Controllers\HrController', 'rejectLeave', $authCsrf);
    $router->get('/hr/evaluations', 'App\Controllers\HrController', 'evaluations', $auth);
    $router->get('/hr/evaluations/create', 'App\Controllers\HrController', 'createEvaluation', $auth);
    $router->post('/hr/evaluations/create', 'App\Controllers\HrController', 'storeEvaluation', $authCsrf);

    // ============================================
    // COMPTABILITÉ & FINANCES
    // ============================================
    $router->get('/finance', 'App\Controllers\FinanceController', 'index', $auth);
    $router->get('/finance/transactions', 'App\Controllers\FinanceController', 'transactions', $auth);
    $router->get('/finance/transactions/create', 'App\Controllers\FinanceController', 'createTransaction', $auth);
    $router->post('/finance/transactions/create', 'App\Controllers\FinanceController', 'storeTransaction', $authCsrf);
    $router->post('/finance/transactions/{id}/validate', 'App\Controllers\FinanceController', 'validateTransaction', $authCsrf);
    $router->get('/finance/budget', 'App\Controllers\FinanceController', 'budget', $auth);
    $router->post('/finance/budget/update', 'App\Controllers\FinanceController', 'updateBudget', $authCsrf);
    $router->get('/finance/reports', 'App\Controllers\FinanceController', 'reports', $auth);
    $router->get('/finance/export', 'App\Controllers\FinanceController', 'export', $auth);

    // ============================================
    // DIGI COM ACADEMY
    // ============================================
    $router->get('/academy', 'App\Controllers\AcademyController', 'index', $auth);
    $router->get('/academy/trainings', 'App\Controllers\AcademyController', 'trainings', $auth);
    $router->get('/academy/trainings/create', 'App\Controllers\AcademyController', 'createTraining', $auth);
    $router->post('/academy/trainings/create', 'App\Controllers\AcademyController', 'storeTraining', $authCsrf);
    $router->get('/academy/trainings/{id}', 'App\Controllers\AcademyController', 'showTraining', $auth);
    $router->get('/academy/trainings/{id}/edit', 'App\Controllers\AcademyController', 'editTraining', $auth);
    $router->post('/academy/trainings/{id}/edit', 'App\Controllers\AcademyController', 'updateTraining', $authCsrf);
    $router->get('/academy/registrations', 'App\Controllers\AcademyController', 'registrations', $auth);
    $router->post('/academy/registrations/create', 'App\Controllers\AcademyController', 'storeRegistration', $authCsrf);
    $router->post('/academy/registrations/{id}/status', 'App\Controllers\AcademyController', 'updateRegistrationStatus', $authCsrf);

    // ============================================
    // ÉVÉNEMENTIEL & ACTIVATION
    // ============================================
    $router->get('/events', 'App\Controllers\EventController', 'index', $auth);
    $router->get('/events/create', 'App\Controllers\EventController', 'create', $auth);
    $router->post('/events/create', 'App\Controllers\EventController', 'store', $authCsrf);
    $router->get('/events/{id}', 'App\Controllers\EventController', 'show', $auth);
    $router->get('/events/{id}/edit', 'App\Controllers\EventController', 'edit', $auth);
    $router->post('/events/{id}/edit', 'App\Controllers\EventController', 'update', $authCsrf);
    $router->post('/events/{id}/delete', 'App\Controllers\EventController', 'delete', $authCsrf);

    // ============================================
    // INNOVATION LAB
    // ============================================
    $router->get('/innovation', 'App\Controllers\InnovationController', 'index', $auth);
    $router->get('/innovation/projects', 'App\Controllers\InnovationController', 'projects', $auth);
    $router->get('/innovation/projects/create', 'App\Controllers\InnovationController', 'create', $auth);
    $router->post('/innovation/projects/create', 'App\Controllers\InnovationController', 'store', $authCsrf);
    $router->get('/innovation/projects/{id}', 'App\Controllers\InnovationController', 'show', $auth);
    $router->get('/innovation/library', 'App\Controllers\InnovationController', 'library', $auth);

    // ============================================
    // GESTION DOCUMENTAIRE
    // ============================================
    $router->get('/documents', 'App\Controllers\DocumentController', 'index', $auth);
    $router->get('/documents/upload', 'App\Controllers\DocumentController', 'uploadForm', $auth);
    $router->post('/documents/upload', 'App\Controllers\DocumentController', 'upload', $authCsrf);
    $router->get('/documents/{id}', 'App\Controllers\DocumentController', 'show', $auth);
    $router->get('/documents/{id}/download', 'App\Controllers\DocumentController', 'download', $auth);
    $router->post('/documents/{id}/delete', 'App\Controllers\DocumentController', 'delete', $authCsrf);

    // ============================================
    // STOCK & ÉQUIPEMENTS
    // ============================================
    $router->get('/stock', 'App\Controllers\StockController', 'index', $auth);
    $router->get('/stock/equipments', 'App\Controllers\StockController', 'equipments', $auth);
    $router->get('/stock/equipments/create', 'App\Controllers\StockController', 'create', $auth);
    $router->post('/stock/equipments/create', 'App\Controllers\StockController', 'store', $authCsrf);
    $router->get('/stock/equipments/{id}', 'App\Controllers\StockController', 'show', $auth);
    $router->post('/stock/equipments/{id}/assign', 'App\Controllers\StockController', 'assign', $authCsrf);

    // ============================================
    // ASSURANCE QUALITÉ
    // ============================================
    $router->get('/quality', 'App\Controllers\QualityController', 'index', $auth);
    $router->get('/quality/procedures', 'App\Controllers\QualityController', 'procedures', $auth);
    $router->get('/quality/non-conformities', 'App\Controllers\QualityController', 'nonConformities', $auth);
    $router->post('/quality/non-conformities/create', 'App\Controllers\QualityController', 'storeNC', $authCsrf);
    $router->get('/quality/audits', 'App\Controllers\QualityController', 'audits', $auth);
    $router->get('/quality/satisfaction', 'App\Controllers\QualityController', 'satisfaction', $auth);

    // ============================================
    // NOTIFICATIONS
    // ============================================
    $router->get('/notifications', 'App\Controllers\NotificationController', 'index', $auth);
    $router->post('/notifications/{id}/read', 'App\Controllers\NotificationController', 'markRead', $authCsrf);
    $router->post('/notifications/read-all', 'App\Controllers\NotificationController', 'markAllRead', $authCsrf);

    // ============================================
    // RAPPORTS
    // ============================================
    $router->get('/reports', 'App\Controllers\ReportController', 'index', $auth);
    $router->get('/reports/commercial', 'App\Controllers\ReportController', 'commercial', $auth);
    $router->get('/reports/financial', 'App\Controllers\ReportController', 'financial', $auth);
    $router->get('/reports/hr', 'App\Controllers\ReportController', 'hr', $auth);
    $router->get('/reports/projects', 'App\Controllers\ReportController', 'projects', $auth);
    $router->get('/reports/academy', 'App\Controllers\ReportController', 'academy', $auth);
    $router->get('/reports/export/{type}', 'App\Controllers\ReportController', 'export', $auth);

    // ============================================
    // ADMINISTRATION (CEO)
    // ============================================
    $router->get('/admin', 'App\Controllers\AdminController', 'index', $auth);
    $router->get('/admin/users', 'App\Controllers\AdminController', 'users', $auth);
    $router->get('/admin/users/create', 'App\Controllers\AdminController', 'createUser', $auth);
    $router->post('/admin/users/create', 'App\Controllers\AdminController', 'storeUser', $authCsrf);
    $router->get('/admin/users/{id}/edit', 'App\Controllers\AdminController', 'editUser', $auth);
    $router->post('/admin/users/{id}/edit', 'App\Controllers\AdminController', 'updateUser', $authCsrf);
    $router->post('/admin/users/{id}/suspend', 'App\Controllers\AdminController', 'suspendUser', $authCsrf);
    $router->post('/admin/users/{id}/activate', 'App\Controllers\AdminController', 'activateUser', $authCsrf);
    $router->get('/admin/logs', 'App\Controllers\AdminController', 'logs', $auth);
    $router->get('/admin/settings', 'App\Controllers\AdminController', 'settings', $auth);
    $router->post('/admin/settings', 'App\Controllers\AdminController', 'updateSettings', $authCsrf);
    $router->post('/admin/backup', 'App\Controllers\AdminController', 'createBackup', $authCsrf);
    $router->get('/admin/backups', 'App\Controllers\AdminController', 'backups', $auth);
};
