<?php
return [
    'ceo' => ['*' => ['*']],

    'coo' => [
        'dashboard'  => ['read'],
        'projects'   => ['read', 'create', 'update', 'validate'],
        'hr'         => ['read', 'create', 'update'],
        'finance'    => ['read', 'validate'],
        'crm'        => ['read', 'create', 'update'],
        'reports'    => ['read', 'export'],
    ],

    'digital_project_manager' => [
        'projects'   => ['read', 'create', 'update'],
        'tasks'      => ['read', 'create', 'update', 'validate'],
        'crm'        => ['read'],
        'documents'  => ['read', 'create'],
    ],

    'responsable_commercial' => [
        'crm'        => ['read', 'create', 'update', 'delete'],
        'commercial' => ['read', 'create', 'update', 'validate'],
        'clients'    => ['read', 'create', 'update'],
        'quotes'     => ['read', 'create', 'update'],
        'contracts'  => ['read', 'create'],
        'reports'    => ['read', 'export'],
    ],

    'responsable_finance' => [
        'finance'    => ['read', 'create', 'update', 'validate', 'export'],
        'invoices'   => ['read', 'create', 'update'],
        'budget'     => ['read', 'create', 'update'],
        'reports'    => ['read', 'export'],
    ],

    'responsable_rh' => [
        'hr'          => ['read', 'create', 'update', 'validate'],
        'leaves'      => ['read', 'validate'],
        'evaluations' => ['read', 'create', 'update'],
        'reports'     => ['read', 'export'],
    ],

    'responsable_academy' => [
        'academy'   => ['read', 'create', 'update', 'delete', 'validate'],
        'trainings' => ['read', 'create', 'update'],
        'reports'   => ['read', 'export'],
    ],

    'responsable_evenementiel' => [
        'events'    => ['read', 'create', 'update', 'delete'],
        'budget'    => ['read'],
        'documents' => ['read', 'create'],
    ],

    'responsable_qualite' => [
        'quality'   => ['read', 'create', 'update', 'validate'],
        'documents' => ['read', 'create', 'update'],
        'reports'   => ['read', 'export'],
    ],

    'responsable_innovation' => [
        'innovation' => ['read', 'create', 'update'],
        'projects'   => ['read'],
        'documents'  => ['read', 'create'],
    ],

    'collaborateur' => [
        'dashboard' => ['read'],
        'projects'  => ['read'],
        'tasks'     => ['read', 'update'],
        'documents' => ['read'],
    ],

    'stagiaire' => [
        'dashboard' => ['read'],
        'tasks'     => ['read'],
    ],

    'client' => [
        'client_portal' => ['read'],
        'projects'      => ['read'],
        'invoices'      => ['read'],
    ],

    'partenaire' => [
        'partner_portal' => ['read'],
    ],
];
