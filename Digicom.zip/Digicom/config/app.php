<?php

return [
    'name' => $_ENV['APP_NAME'] ?? 'DIGI ERP',
    'url' => $_ENV['APP_URL'] ?? 'http://localhost',
    'env' => $_ENV['APP_ENV'] ?? 'development',
    'secret' => $_ENV['APP_SECRET'] ?? '',
    'timezone' => 'Africa/Bamako',
    'locale' => 'fr_FR',
    'currency' => [
        'code' => 'XOF',
        'symbol' => 'FCFA',
        'tax_rate' => 18.00,
    ],
    'pagination' => [
        'per_page' => 20,
    ],
    'upload' => [
        'max_size' => (int)($_ENV['UPLOAD_MAX_SIZE'] ?? 10485760),
        'allowed_types' => [
            'image/jpeg',
            'image/png',
            'image/gif',
            'image/webp',
            'application/pdf',
            'application/msword',
            'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            'application/vnd.ms-excel',
            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            'text/csv',
            'application/zip',
        ],
    ],
    'session' => [
        'lifetime' => (int)($_ENV['SESSION_LIFETIME'] ?? 3600),
    ],
    'security' => [
        'max_login_attempts' => 5,
        'login_lockout_minutes' => 15,
        'password_min_length' => 8,
    ],
];
