<?php
declare(strict_types=1);

/**
 * Seeder : Vérification des rôles dans la base de données
 */

require_once __DIR__ . '/../../vendor/autoload.php';

echo "✅ Configuration des rôles chargée depuis config/roles.php\n";
echo "   Les rôles sont gérés via la colonne 'role' dans la table 'users'.\n";
echo "   Aucune table séparée de rôles n'est nécessaire.\n";
echo "   Rôles disponibles : ceo, coo, digital_project_manager, responsable_commercial,\n";
echo "   responsable_finance, responsable_rh, responsable_academy,\n";
echo "   responsable_evenementiel, responsable_qualite, responsable_innovation,\n";
echo "   collaborateur, stagiaire, client, partenaire\n";
