<?php
declare(strict_types=1);

/**
 * Seeder : Insertion du compte administrateur CEO par défaut
 * Email: ceo@digicom.ml / Mot de passe: Admin2025!
 */

require_once __DIR__ . '/../../vendor/autoload.php';

$dotenv = Dotenv\Dotenv::createImmutable(dirname(__DIR__, 2));
$dotenv->safeLoad();

$dsn = sprintf(
    'mysql:host=%s;port=%s;dbname=%s;charset=utf8mb4',
    $_ENV['DB_HOST'] ?? '127.0.0.1',
    $_ENV['DB_PORT'] ?? '3306',
    $_ENV['DB_NAME'] ?? 'digi_erp'
);

try {
    $pdo = new PDO($dsn, $_ENV['DB_USER'] ?? 'root', $_ENV['DB_PASS'] ?? '', [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
} catch (PDOException $e) {
    echo "⚠️  Connexion DB impossible : " . $e->getMessage() . "\n";
    exit(1);
}

// Vérifier si un CEO existe déjà
$stmt = $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'ceo'");
if ($stmt->fetchColumn() > 0) {
    echo "✅ Un compte CEO existe déjà. Aucune insertion.\n";
    exit(0);
}

// Insérer le CEO
$password = password_hash('Admin2025!', PASSWORD_BCRYPT, ['cost' => 12]);

$stmt = $pdo->prepare("
    INSERT INTO users (name, email, password, role, status, must_change_password, phone)
    VALUES (?, ?, ?, 'ceo', 'active', 1, ?)
");

$stmt->execute(['CEO DIGI COM', 'ceo@digicom.ml', $password, '+22300000000']);

$userId = (int) $pdo->lastInsertId();

// Créer la fiche employé associée
$stmt = $pdo->prepare("
    INSERT INTO employees (user_id, employee_number, position, department, hire_date, status)
    VALUES (?, 'EMP-0001', 'CEO & Fondateur', 'Direction Générale', CURDATE(), 'active')
");
$stmt->execute([$userId]);

echo "✅ Compte CEO créé avec succès !\n";
echo "   Email : ceo@digicom.ml\n";
echo "   Mot de passe : Admin2025!\n";
echo "   ⚠️  Changez le mot de passe dès la première connexion.\n";
