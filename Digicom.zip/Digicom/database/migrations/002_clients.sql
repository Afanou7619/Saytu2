-- Migration 002 : Clients / Prospects
CREATE TABLE IF NOT EXISTS clients (
    id INT AUTO_INCREMENT PRIMARY KEY,
    type ENUM('prospect','client','partenaire') DEFAULT 'prospect',
    company_name VARCHAR(150),
    contact_name VARCHAR(100),
    email VARCHAR(150),
    phone VARCHAR(20),
    address TEXT,
    segment VARCHAR(50),
    source VARCHAR(100),
    status ENUM('active','inactive','converted') DEFAULT 'active',
    pipeline_stage VARCHAR(50) DEFAULT 'nouveau',
    assigned_to INT,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (assigned_to) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
