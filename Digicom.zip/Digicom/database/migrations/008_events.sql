-- Migration 008 : Événements
CREATE TABLE IF NOT EXISTS events (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    type ENUM('conference','workshop','activation','internal','other') DEFAULT 'other',
    start_datetime DATETIME,
    end_datetime DATETIME,
    location VARCHAR(255),
    budget DECIMAL(12,2),
    spent DECIMAL(12,2) DEFAULT 0,
    status ENUM('planning','confirmed','ongoing','completed','cancelled') DEFAULT 'planning',
    responsible_id INT,
    description TEXT,
    max_participants INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (responsible_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS event_participants (
    id INT AUTO_INCREMENT PRIMARY KEY,
    event_id INT NOT NULL,
    name VARCHAR(150),
    email VARCHAR(150),
    phone VARCHAR(20),
    status ENUM('registered','confirmed','attended','cancelled') DEFAULT 'registered',
    badge_code VARCHAR(50),
    registered_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (event_id) REFERENCES events(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
