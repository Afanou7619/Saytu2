-- Migration 007 : Academy
CREATE TABLE IF NOT EXISTS trainings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    category VARCHAR(100),
    description TEXT,
    price DECIMAL(10,2),
    duration_hours INT,
    max_participants INT,
    trainer_id INT,
    status ENUM('draft','published','ongoing','completed','cancelled') DEFAULT 'draft',
    start_date DATE,
    end_date DATE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (trainer_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS training_registrations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    training_id INT NOT NULL,
    learner_name VARCHAR(150),
    learner_email VARCHAR(150),
    learner_phone VARCHAR(20),
    status ENUM('registered','paid','attending','certified','dropped') DEFAULT 'registered',
    payment_status ENUM('pending','paid','refunded') DEFAULT 'pending',
    amount_paid DECIMAL(10,2),
    registered_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (training_id) REFERENCES trainings(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
