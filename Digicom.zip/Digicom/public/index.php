<?php
declare(strict_types=1);

define("BASE_PATH", dirname(__DIR__));
define("APP_PATH", BASE_PATH . "/app");
define("PUBLIC_PATH", __DIR__);
define("STORAGE_PATH", BASE_PATH . "/storage");

// Détection du chemin de base (sous-dossier) de l'application
// Ex: /Digicom si le site est dans http://localhost/Digicom, ou '' si à la racine
$docRoot = rtrim(str_replace("\\", "/", $_SERVER["DOCUMENT_ROOT"]), "/");
$basePath = rtrim(str_replace("\\", "/", BASE_PATH), "/");
if ($basePath !== $docRoot && str_starts_with($basePath, $docRoot . "/")) {
    $baseUrl = substr($basePath, strlen($docRoot));
} else {
    $baseUrl = "";
}
define("BASE_URL", $baseUrl);

require_once BASE_PATH . "/vendor/autoload.php";

// Chargement .env
$dotenv = Dotenv\Dotenv::createImmutable(BASE_PATH);
$dotenv->safeLoad();

// Correction de APP_URL si le site est dans un sous-dossier
if (BASE_URL !== "" && isset($_ENV["APP_URL"])) {
    $_ENV["APP_URL"] = rtrim($_ENV["APP_URL"], "/") . BASE_URL;
}

// Démarrage de la session sécurisée
if (session_status() === PHP_SESSION_NONE) {
    session_start([
        "cookie_httponly" => true,
        "cookie_secure" => isset($_SERVER["HTTPS"]),
        "cookie_samesite" => "Strict",
        "use_strict_mode" => true,
    ]);
}

// Réécriture des URLs absolues si l'app est dans un sous-dossier
if (BASE_URL !== "") {
    ob_start(function (string $buffer): string {
        // Réécrit action="/..." href="/..." src="/..."
        $buffer = preg_replace(
            '/(\s)(action|href|src)=(["\'])\/(?!\/)([^"\']*)\3/i',
            '$1$2=$3' . BASE_URL . '/$4$3',
            $buffer,
        );
        return $buffer;
    });
}

// Lancement de l'application
$app = new App\Core\App();
$app->run();
