<?php
declare(strict_types=1);

namespace App\Core;

use Dompdf\Dompdf;
use Dompdf\Options;
use App\Models\Quote;
use App\Models\Invoice;
use App\Models\Client;

class PdfGenerator
{
    /**
     * Génère un PDF pour un devis
     */
    public static function generateQuote(array $quote): string
    {
        $items = Quote::items($quote['id']);
        $client = Client::find($quote['client_id']);

        $options = new Options();
        $options->set('defaultFont', 'DejaVu Sans');
        $options->set('isHtml5ParserEnabled', true);

        $dompdf = new Dompdf($options);

        $html = self::renderTemplate('pdf/quote', [
            'quote' => $quote,
            'items' => $items,
            'client' => $client,
        ]);

        $dompdf->loadHtml($html);
        $dompdf->setPaper('A4', 'portrait');
        $dompdf->render();

        $exportDir = STORAGE_PATH . '/exports/';
        if (!is_dir($exportDir)) {
            mkdir($exportDir, 0755, true);
        }

        $filename = $exportDir . 'quote_' . $quote['reference'] . '.pdf';
        file_put_contents($filename, $dompdf->output());

        return $filename;
    }

    /**
     * Génère un PDF pour une facture
     */
    public static function generateInvoice(array $invoice): string
    {
        $items = Invoice::items($invoice['id']);
        $client = Client::find($invoice['client_id']);
        $payments = Invoice::payments($invoice['id']);

        $options = new Options();
        $options->set('defaultFont', 'DejaVu Sans');
        $options->set('isHtml5ParserEnabled', true);

        $dompdf = new Dompdf($options);

        $html = self::renderTemplate('pdf/invoice', [
            'invoice' => $invoice,
            'items' => $items,
            'client' => $client,
            'payments' => $payments,
        ]);

        $dompdf->loadHtml($html);
        $dompdf->setPaper('A4', 'portrait');
        $dompdf->render();

        $exportDir = STORAGE_PATH . '/exports/';
        if (!is_dir($exportDir)) {
            mkdir($exportDir, 0755, true);
        }

        $filename = $exportDir . 'invoice_' . $invoice['reference'] . '.pdf';
        file_put_contents($filename, $dompdf->output());

        return $filename;
    }

    /**
     * Rend un template pour PDF
     */
    private static function renderTemplate(string $template, array $data): string
    {
        extract($data);
        ob_start();
        $path = APP_PATH . '/Views/' . $template . '.php';
        if (file_exists($path)) {
            include $path;
        } else {
            echo '<p>Template introuvable</p>';
        }
        return ob_get_clean();
    }
}
