<?php
declare(strict_types=1);

/**
 * Fichier de fonctions utilitaires globales
 * Chargé automatiquement via Composer autoload (files)
 */

if (!function_exists("config")) {
    /**
     * Récupère une valeur de configuration
     */
    function config(string $key, mixed $default = null): mixed
    {
        static $config = [];

        $parts = explode(".", $key, 2);
        $file = $parts[0];

        if (!isset($config[$file])) {
            $path = BASE_PATH . "/config/" . $file . ".php";
            $config[$file] = file_exists($path) ? require $path : [];
        }

        if (count($parts) === 1) {
            return $config[$file];
        }

        $keys = explode(".", $parts[1]);
        $value = $config[$file];
        foreach ($keys as $k) {
            if (!is_array($value) || !array_key_exists($k, $value)) {
                return $default;
            }
            $value = $value[$k];
        }

        return $value;
    }
}

if (!function_exists("e")) {
    /**
     * Échappe une chaîne pour affichage HTML
     */
    function e(?string $value): string
    {
        return htmlspecialchars($value ?? "", ENT_QUOTES | ENT_HTML5, "UTF-8");
    }
}

if (!function_exists("old")) {
    /**
     * Récupère une ancienne valeur de formulaire (après soumission invalide)
     */
    function old(string $key, mixed $default = ""): mixed
    {
        return $_SESSION["_old_input"][$key] ?? $default;
    }
}

if (!function_exists("flash")) {
    /**
     * Récupère et efface un message flash
     */
    function flash(string $key = "success"): ?string
    {
        $message = $_SESSION["_flash"][$key] ?? null;
        unset($_SESSION["_flash"][$key]);
        return $message;
    }
}

if (!function_exists("setFlash")) {
    /**
     * Définit un message flash
     */
    function setFlash(string $key, string $message): void
    {
        $_SESSION["_flash"][$key] = $message;
    }
}

if (!function_exists("csrfToken")) {
    /**
     * Génère le champ CSRF token pour les formulaires
     */
    function csrfToken(): string
    {
        return App\Middleware\CsrfMiddleware::field();
    }
}

if (!function_exists("csrfField")) {
    /**
     * Génère le champ CSRF token pour les formulaires
     */
    function csrfField(): string
    {
        return App\Middleware\CsrfMiddleware::field();
    }
}

if (!function_exists("url")) {
    /**
     * Génère une URL relative à la racine de l'application
     * Prend en compte automatiquement un éventuel sous-dossier
     * Ex: url('/login') -> '/Digicom/login' si le site est dans /Digicom
     */
    function url(string $path = "/"): string
    {
        $base = defined("BASE_URL") ? BASE_URL : "";
        return $base . "/" . ltrim($path, "/");
    }
}

if (!function_exists("baseUrl")) {
    /**
     * Génère une URL absolue
     */
    function baseUrl(string $path = ""): string
    {
        $base = $_ENV["APP_URL"] ?? "http://localhost";
        return rtrim($base, "/") . "/" . ltrim($path, "/");
    }
}

if (!function_exists("asset")) {
    /**
     * Génère l'URL d'un asset
     */
    function asset(string $path): string
    {
        return baseUrl("assets/" . ltrim($path, "/"));
    }
}

if (!function_exists("formatCurrency")) {
    /**
     * Formate un montant en FCFA
     */
    function formatCurrency(
        float|int $amount,
        string $currency = "FCFA",
    ): string {
        return number_format($amount, 0, ",", " ") . " " . $currency;
    }
}

if (!function_exists("formatDate")) {
    /**
     * Formate une date
     */
    function formatDate(?string $date, string $format = "d/m/Y"): string
    {
        if (!$date) {
            return "—";
        }
        $d = new DateTimeImmutable($date);
        return $d->format($format);
    }
}

if (!function_exists("formatDateTime")) {
    /**
     * Formate une date avec heure
     */
    function formatDateTime(
        ?string $datetime,
        string $format = "d/m/Y H:i",
    ): string {
        if (!$datetime) {
            return "—";
        }
        $d = new DateTimeImmutable($datetime);
        return $d->format($format);
    }
}

if (!function_exists("timeAgo")) {
    /**
     * Affiche le temps écoulé en français
     */
    function timeAgo(?string $datetime): string
    {
        if (!$datetime) {
            return "—";
        }

        $now = new DateTimeImmutable();
        $date = new DateTimeImmutable($datetime);
        $diff = $now->diff($date);

        if ($diff->y > 0) {
            return "{$diff->y} an" . ($diff->y > 1 ? "s" : "");
        }
        if ($diff->m > 0) {
            return "{$diff->m} mois";
        }
        if ($diff->d > 0) {
            return "{$diff->d} jour" . ($diff->d > 1 ? "s" : "");
        }
        if ($diff->h > 0) {
            return "{$diff->h}h";
        }
        if ($diff->i > 0) {
            return "{$diff->i} min";
        }
        return "À l'instant";
    }
}

if (!function_exists("slugify")) {
    /**
     * Crée un slug à partir d'une chaîne
     */
    function slugify(string $text): string
    {
        $text = transliterator_transliterate("Any-Latin; Latin-ASCII", $text);
        $text = strtolower($text);
        $text = preg_replace("/[^a-z0-9]+/", "-", $text);
        return trim($text, "-");
    }
}

if (!function_exists("truncate")) {
    /**
     * Tronque une chaîne
     */
    function truncate(
        string $text,
        int $length = 100,
        string $suffix = "...",
    ): string {
        if (mb_strlen($text) <= $length) {
            return $text;
        }
        return mb_substr($text, 0, $length) . $suffix;
    }
}

if (!function_exists("generateReference")) {
    /**
     * Génère une référence unique
     */
    function generateReference(string $prefix, int $id = 0): string
    {
        $year = date("Y");
        $number = str_pad((string) $id, 4, "0", STR_PAD_LEFT);
        return "{$prefix}-{$year}-{$number}";
    }
}

if (!function_exists("statusBadge")) {
    /**
     * Génère un badge de statut HTML
     */
    function statusBadge(string $status): string
    {
        $classes = [
            "active" => "bg-green-100 text-green-800",
            "inactive" => "bg-gray-100 text-gray-800",
            "draft" => "bg-gray-100 text-gray-600",
            "sent" => "bg-blue-100 text-blue-800",
            "paid" => "bg-green-100 text-green-800",
            "overdue" => "bg-red-100 text-red-800",
            "pending" => "bg-yellow-100 text-yellow-800",
            "approved" => "bg-green-100 text-green-800",
            "rejected" => "bg-red-100 text-red-800",
            "cancelled" => "bg-red-100 text-red-800",
            "completed" => "bg-green-100 text-green-800",
            "on_hold" => "bg-yellow-100 text-yellow-800",
            "in_progress" => "bg-blue-100 text-blue-800",
            "todo" => "bg-gray-100 text-gray-600",
            "done" => "bg-green-100 text-green-800",
            "review" => "bg-purple-100 text-purple-800",
        ];

        $class = $classes[$status] ?? "bg-gray-100 text-gray-600";
        $label = ucfirst(str_replace("_", " ", $status));

        return "<span class='px-2 py-1 text-xs font-medium rounded-full {$class}'>{$label}</span>";
    }
}
