<?php
declare(strict_types=1);

namespace App\Core;

abstract class Middleware
{
    abstract public function handle(): void;

    /**
     * Redirige vers le login
     */
    protected function redirectToLogin(): void
    {
        header("Location: " . url("/login"));
        exit();
    }

    /**
     * Redirige vers une page d'erreur
     */
    protected function abort(
        int $code = 403,
        string $message = "Accès non autorisé",
    ): void {
        http_response_code($code);
        if (file_exists(APP_PATH . "/Views/errors/" . $code . ".php")) {
            include APP_PATH . "/Views/errors/" . $code . ".php";
        } else {
            echo "<h1>{$code} - {$message}</h1>";
        }
        exit();
    }
}
