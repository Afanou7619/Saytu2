<?php
declare(strict_types=1);

namespace App\Core;

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

class ExcelExporter
{
    /**
     * Exporte la liste des clients
     */
    public static function exportClients(array $clients): string
    {
        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();
        $sheet->setTitle('Clients');

        $headers = ['ID', 'Entreprise', 'Contact', 'Email', 'Téléphone', 'Segment', 'Type', 'Statut', 'Créé le'];
        foreach ($headers as $col => $header) {
            $sheet->setCellValueByColumnAndRow($col + 1, 1, $header);
        }

        foreach ($clients as $row => $client) {
            $sheet->setCellValueByColumnAndRow(1, $row + 2, $client['id']);
            $sheet->setCellValueByColumnAndRow(2, $row + 2, $client['company_name']);
            $sheet->setCellValueByColumnAndRow(3, $row + 2, $client['contact_name']);
            $sheet->setCellValueByColumnAndRow(4, $row + 2, $client['email']);
            $sheet->setCellValueByColumnAndRow(5, $row + 2, $client['phone']);
            $sheet->setCellValueByColumnAndRow(6, $row + 2, $client['segment']);
            $sheet->setCellValueByColumnAndRow(7, $row + 2, $client['type']);
            $sheet->setCellValueByColumnAndRow(8, $row + 2, $client['status']);
            $sheet->setCellValueByColumnAndRow(9, $row + 2, $client['created_at']);
        }

        return self::save($spreadsheet, 'clients_' . date('Ymd_His') . '.xlsx');
    }

    /**
     * Exporte les transactions
     */
    public static function exportTransactions(array $transactions): string
    {
        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();
        $sheet->setTitle('Transactions');

        $headers = ['ID', 'Date', 'Type', 'Catégorie', 'Description', 'Montant', 'Référence', 'Statut'];
        foreach ($headers as $col => $header) {
            $sheet->setCellValueByColumnAndRow($col + 1, 1, $header);
        }

        foreach ($transactions as $row => $t) {
            $sheet->setCellValueByColumnAndRow(1, $row + 2, $t['id']);
            $sheet->setCellValueByColumnAndRow(2, $row + 2, $t['transaction_date']);
            $sheet->setCellValueByColumnAndRow(3, $row + 2, $t['type']);
            $sheet->setCellValueByColumnAndRow(4, $row + 2, $t['category']);
            $sheet->setCellValueByColumnAndRow(5, $row + 2, $t['description']);
            $sheet->setCellValueByColumnAndRow(6, $row + 2, $t['amount']);
            $sheet->setCellValueByColumnAndRow(7, $row + 2, $t['reference']);
            $sheet->setCellValueByColumnAndRow(8, $row + 2, $t['status']);
        }

        return self::save($spreadsheet, 'transactions_' . date('Ymd_His') . '.xlsx');
    }

    /**
     * Exporte les factures
     */
    public static function exportInvoices(array $invoices): string
    {
        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();
        $sheet->setTitle('Factures');

        $headers = ['Référence', 'Client', 'Montant HT', 'TVA', 'TTC', 'Payé', 'Reste', 'Échéance', 'Statut'];
        foreach ($headers as $col => $header) {
            $sheet->setCellValueByColumnAndRow($col + 1, 1, $header);
        }

        foreach ($invoices as $row => $inv) {
            $sheet->setCellValueByColumnAndRow(1, $row + 2, $inv['reference']);
            $sheet->setCellValueByColumnAndRow(2, $row + 2, $inv['client_id']); // Nom à résoudre
            $sheet->setCellValueByColumnAndRow(3, $row + 2, $inv['total_ht']);
            $sheet->setCellValueByColumnAndRow(4, $row + 2, $inv['tax_rate']);
            $sheet->setCellValueByColumnAndRow(5, $row + 2, $inv['total_ttc']);
            $sheet->setCellValueByColumnAndRow(6, $row + 2, $inv['paid_amount']);
            $sheet->setCellValueByColumnAndRow(7, $row + 2, ($inv['total_ttc'] ?? 0) - ($inv['paid_amount'] ?? 0));
            $sheet->setCellValueByColumnAndRow(8, $row + 2, $inv['due_date']);
            $sheet->setCellValueByColumnAndRow(9, $row + 2, $inv['status']);
        }

        return self::save($spreadsheet, 'factures_' . date('Ymd_His') . '.xlsx');
    }

    /**
     * Sauvegarde le fichier Excel
     */
    private static function save(Spreadsheet $spreadsheet, string $filename): string
    {
        $exportDir = STORAGE_PATH . '/exports/';
        if (!is_dir($exportDir)) {
            mkdir($exportDir, 0755, true);
        }

        $filepath = $exportDir . $filename;
        $writer = new Xlsx($spreadsheet);
        $writer->save($filepath);

        return $filepath;
    }
}
