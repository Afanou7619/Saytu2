<?php
declare(strict_types=1);

namespace App\Core;

class Router
{
    private array $routes = [];

    public function get(string $path, string $controller, string $method, array $middleware = []): void
    {
        $this->routes[] = ['GET', $path, $controller, $method, $middleware];
    }

    public function post(string $path, string $controller, string $method, array $middleware = []): void
    {
        $this->routes[] = ['POST', $path, $controller, $method, $middleware];
    }

    public function put(string $path, string $controller, string $method, array $middleware = []): void
    {
        $this->routes[] = ['PUT', $path, $controller, $method, $middleware];
    }

    public function delete(string $path, string $controller, string $method, array $middleware = []): void
    {
        $this->routes[] = ['DELETE', $path, $controller, $method, $middleware];
    }

    public function dispatch(string $httpMethod, string $uri): void
    {
        // Support des méthodes PUT/DELETE via champ caché _method
        if ($httpMethod === 'POST' && isset($_POST['_method'])) {
            $httpMethod = strtoupper($_POST['_method']);
        }

        $uri = strtok($uri, '?');

        foreach ($this->routes as [$method, $path, $controller, $action, $middlewares]) {
            $pattern = preg_replace('/\{([a-z_]+)\}/', '(?P<$1>[^/]+)', $path);
            $pattern = '#^' . $pattern . '$#';

            if ($method === $httpMethod && preg_match($pattern, $uri, $matches)) {
                $params = array_filter($matches, 'is_string', ARRAY_FILTER_USE_KEY);

                // Exécution des middlewares
                foreach ($middlewares as $middleware) {
                    $m = new $middleware();
                    $m->handle();
                }

                $ctrl = new $controller();
                call_user_func_array([$ctrl, $action], $params);
                return;
            }
        }

        http_response_code(404);
        if (file_exists(APP_PATH . '/Views/errors/404.php')) {
            include APP_PATH . '/Views/errors/404.php';
        } else {
            echo '<h1>404 - Page non trouvée</h1>';
        }
    }
}
