<?php
declare(strict_types=1);

namespace App\Core;

use App\Models\User;
use App\Models\ActivityLog;

class Auth
{
    public static function login(string $email, string $password): bool
    {
        $user = User::findByEmail($email);

        if (!$user || !password_verify($password, $user["password"])) {
            ActivityLog::record(null, "LOGIN_FAILED", ["email" => $email]);
            return false;
        }

        if ($user["status"] !== "active") {
            return false;
        }

        $_SESSION["user_id"] = $user["id"];
        $_SESSION["user_role"] = $user["role"];
        $_SESSION["user_name"] = $user["name"];
        $_SESSION["login_at"] = time();

        // Régénération de l'ID de session
        session_regenerate_id(true);

        // Mise à jour last_login
        User::updateLastLogin($user["id"]);

        ActivityLog::record($user["id"], "LOGIN_SUCCESS");
        return true;
    }

    public static function logout(): void
    {
        if (self::check()) {
            ActivityLog::record(self::id(), "LOGOUT");
        }
        session_destroy();
        header("Location: " . url("/login"));
        exit();
    }

    public static function check(): bool
    {
        return isset($_SESSION["user_id"]);
    }

    public static function id(): ?int
    {
        return $_SESSION["user_id"] ?? null;
    }

    public static function role(): ?string
    {
        return $_SESSION["user_role"] ?? null;
    }

    public static function name(): ?string
    {
        return $_SESSION["user_name"] ?? null;
    }

    public static function can(string $module, string $action = "read"): bool
    {
        if (self::role() === "ceo") {
            return true; // Super Admin a tous les droits
        }

        $roles = config("roles");
        $permissions =
            $roles[self::role()][$module] ?? ($roles[self::role()]["*"] ?? []);

        return in_array($action, $permissions) || in_array("*", $permissions);
    }

    public static function user(): ?array
    {
        if (!self::check()) {
            return null;
        }
        return User::find(self::id());
    }

    public static function mustChangePassword(): bool
    {
        $user = self::user();
        return $user && ($user["must_change_password"] ?? 0) == 1;
    }
}
