<?php
declare(strict_types=1);

namespace App\Core;

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

class Mailer
{
    private PHPMailer $mailer;

    public function __construct()
    {
        $this->mailer = new PHPMailer(true);

        $this->mailer->isSMTP();
        $this->mailer->Host = $_ENV['MAIL_HOST'] ?? 'smtp.gmail.com';
        $this->mailer->Port = (int)($_ENV['MAIL_PORT'] ?? 587);
        $this->mailer->SMTPAuth = true;
        $this->mailer->Username = $_ENV['MAIL_USERNAME'] ?? '';
        $this->mailer->Password = $_ENV['MAIL_PASSWORD'] ?? '';
        $this->mailer->SMTPSecure = $_ENV['MAIL_ENCRYPTION'] ?? 'tls';
        $this->mailer->CharSet = 'UTF-8';

        $fromEmail = $_ENV['MAIL_USERNAME'] ?? 'noreply@digicom.ml';
        $fromName = $_ENV['MAIL_FROM_NAME'] ?? 'DIGI ERP';
        $this->mailer->setFrom($fromEmail, $fromName);
    }

    /**
     * Envoie un email simple
     */
    public function send(string $to, string $subject, string $body, array $attachments = []): bool
    {
        try {
            $this->mailer->clearAddresses();
            $this->mailer->clearAttachments();

            $this->mailer->addAddress($to);
            $this->mailer->Subject = $subject;
            $this->mailer->isHTML(true);
            $this->mailer->Body = $body;
            $this->mailer->AltBody = strip_tags($body);

            foreach ($attachments as $attachment) {
                $this->mailer->addAttachment($attachment);
            }

            $this->mailer->send();
            Logger::info("Email envoyé à {$to} : {$subject}");
            return true;
        } catch (Exception $e) {
            Logger::error("Échec envoi email à {$to} : " . $e->getMessage());
            return false;
        }
    }

    /**
     * Envoie un email avec template
     */
    public function sendTemplate(string $to, string $subject, string $template, array $data = [], array $attachments = []): bool
    {
        $templatePath = APP_PATH . '/Views/emails/' . $template . '.php';

        if (!file_exists($templatePath)) {
            Logger::error("Template email introuvable : {$template}");
            return false;
        }

        ob_start();
        extract($data);
        include $templatePath;
        $body = ob_get_clean();

        return $this->send($to, $subject, $body, $attachments);
    }

    /**
     * Envoie un email à plusieurs destinataires
     */
    public function sendBulk(array $recipients, string $subject, string $body): array
    {
        $results = [];
        foreach ($recipients as $recipient) {
            $results[$recipient] = $this->send($recipient, $subject, $body);
        }
        return $results;
    }
}
