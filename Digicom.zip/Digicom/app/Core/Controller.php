<?php
declare(strict_types=1);

namespace App\Core;

use App\Middleware\CsrfMiddleware;

abstract class Controller
{
    protected function view(
        string $view,
        array $data = [],
        string $layout = "main",
    ): void {
        View::render($view, $data, $layout);
    }

    protected function json(array $data, int $statusCode = 200): void
    {
        http_response_code($statusCode);
        header("Content-Type: application/json; charset=utf-8");
        echo json_encode($data, JSON_UNESCAPED_UNICODE);
        exit();
    }

    protected function redirect(string $url): void
    {
        // Utilise url() si c'est un chemin absolu commençant par /
        if (str_starts_with($url, "/")) {
            $url = url($url);
        }
        header("Location: " . $url);
        exit();
    }

    protected function back(): void
    {
        $referer = $_SERVER["HTTP_REFERER"] ?? url("/");
        $this->redirect($referer);
    }

    protected function validateCsrf(): void
    {
        $token = $_POST["csrf_token"] ?? "";
        if (!CsrfMiddleware::verify($token)) {
            $this->json(["error" => "Token CSRF invalide"], 403);
        }
    }
}
