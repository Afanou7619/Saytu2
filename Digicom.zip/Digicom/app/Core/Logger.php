<?php
declare(strict_types=1);

namespace App\Core;

use Monolog\Logger as MonologLogger;
use Monolog\Handler\StreamHandler;
use Monolog\Level;

class Logger
{
    private static ?MonologLogger $instance = null;

    public static function getInstance(): MonologLogger
    {
        if (self::$instance === null) {
            self::$instance = new MonologLogger('digi-erp');

            $logFile = STORAGE_PATH . '/logs/app-' . date('Y-m-d') . '.log';
            self::$instance->pushHandler(new StreamHandler($logFile, Level::Debug));

            // En production, niveau Warning minimum
            if (($_ENV['APP_ENV'] ?? 'development') === 'production') {
                self::$instance->pushHandler(new StreamHandler($logFile, Level::Warning));
            }
        }

        return self::$instance;
    }

    public static function info(string $message, array $context = []): void
    {
        self::getInstance()->info($message, $context);
    }

    public static function warning(string $message, array $context = []): void
    {
        self::getInstance()->warning($message, $context);
    }

    public static function error(string $message, array $context = []): void
    {
        self::getInstance()->error($message, $context);
    }

    public static function critical(string $message, array $context = []): void
    {
        self::getInstance()->critical($message, $context);
    }

    public static function debug(string $message, array $context = []): void
    {
        self::getInstance()->debug($message, $context);
    }
}
