<?php
declare(strict_types=1);

namespace App\Core;

use PDO;

abstract class Model
{
    protected static string $table;
    protected static string $primaryKey = 'id';
    protected static array $fillable = [];

    /**
     * Récupère tous les enregistrements
     */
    public static function all(string $orderBy = '', string $direction = 'DESC'): array
    {
        $sql = "SELECT * FROM " . static::$table;
        if ($orderBy) {
            $sql .= " ORDER BY {$orderBy} {$direction}";
        }
        return Database::fetchAll($sql);
    }

    /**
     * Récupère un enregistrement par ID
     */
    public static function find(int $id): ?array
    {
        return Database::fetch(
            "SELECT * FROM " . static::$table . " WHERE " . static::$primaryKey . " = ?",
            [$id]
        );
    }

    /**
     * Récupère par colonne
     */
    public static function findBy(string $column, mixed $value): ?array
    {
        return Database::fetch(
            "SELECT * FROM " . static::$table . " WHERE {$column} = ? LIMIT 1",
            [$value]
        );
    }

    /**
     * Récupère tous les enregistrements par colonne
     */
    public static function findAllBy(string $column, mixed $value, string $orderBy = ''): array
    {
        $sql = "SELECT * FROM " . static::$table . " WHERE {$column} = ?";
        if ($orderBy) {
            $sql .= " ORDER BY {$orderBy}";
        }
        return Database::fetchAll($sql, [$value]);
    }

    /**
     * Crée un enregistrement
     */
    public static function create(array $data): int
    {
        $filtered = array_intersect_key($data, array_flip(static::$fillable));
        return Database::insert(static::$table, $filtered);
    }

    /**
     * Met à jour un enregistrement
     */
    public static function update(int $id, array $data): int
    {
        $filtered = array_intersect_key($data, array_flip(static::$fillable));
        return Database::update(static::$table, $filtered, static::$primaryKey . ' = ?', [$id]);
    }

    /**
     * Supprime un enregistrement
     */
    public static function delete(int $id): int
    {
        return Database::delete(static::$table, static::$primaryKey . ' = ?', [$id]);
    }

    /**
     * Compte les enregistrements
     */
    public static function count(string $where = '', array $params = []): int
    {
        $sql = "SELECT COUNT(*) FROM " . static::$table;
        if ($where) {
            $sql .= " WHERE {$where}";
        }
        return (int) Database::fetch($sql, $params)['COUNT(*)'];
    }

    /**
     * Pagination simple
     */
    public static function paginate(int $page = 1, int $perPage = 20, string $orderBy = '', string $direction = 'DESC', string $where = '', array $params = []): array
    {
        $offset = ($page - 1) * $perPage;
        $sql = "SELECT * FROM " . static::$table;
        if ($where) {
            $sql .= " WHERE {$where}";
        }
        if ($orderBy) {
            $sql .= " ORDER BY {$orderBy} {$direction}";
        }
        $sql .= " LIMIT {$perPage} OFFSET {$offset}";

        $total = static::count($where, $params);
        $items = Database::fetchAll($sql, $params);

        return [
            'items' => $items,
            'total' => $total,
            'page' => $page,
            'per_page' => $perPage,
            'last_page' => (int) ceil($total / $perPage),
        ];
    }
}
