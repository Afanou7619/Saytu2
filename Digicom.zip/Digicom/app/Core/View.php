<?php
declare(strict_types=1);

namespace App\Core;

class View
{
    private static array $globalData = [];

    /**
     * Partage une variable avec toutes les vues
     */
    public static function share(string $key, mixed $value): void
    {
        self::$globalData[$key] = $value;
    }

    /**
     * Rend une vue avec layout
     */
    public static function render(string $view, array $data = [], string $layout = 'main'): void
    {
        $data = array_merge(self::$globalData, $data);
        extract($data);

        // Capture le contenu de la vue
        ob_start();
        $viewPath = APP_PATH . '/Views/' . $view . '.php';
        if (!file_exists($viewPath)) {
            throw new \RuntimeException("Vue introuvable : {$view}");
        }
        include $viewPath;
        $content = ob_get_clean();

        // Insère dans le layout
        $layoutPath = APP_PATH . '/Views/layouts/' . $layout . '.php';
        if (!file_exists($layoutPath)) {
            throw new \RuntimeException("Layout introuvable : {$layout}");
        }
        include $layoutPath;
    }

    /**
     * Rend une vue partielle (sans layout)
     */
    public static function partial(string $view, array $data = []): string
    {
        extract(array_merge(self::$globalData, $data));
        ob_start();
        include APP_PATH . '/Views/' . $view . '.php';
        return ob_get_clean();
    }
}
