<div class="space-y-6">
    <div class="flex items-center justify-between">
        <h1 class="text-xl font-bold text-gray-900"><?= e($title ?? 'Rapport Commercial') ?></h1>
        <div class="flex items-center gap-3">
            <form method="get" class="flex items-center gap-2">
                <select name="year" class="text-sm border border-gray-200 rounded-lg px-3 py-2 bg-white focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                    <?php foreach (($years ?? range(date('Y') - 3, date('Y'))) as $y): ?>
                    <option value="<?= $y ?>" <?= ($selectedYear ?? date('Y')) == $y ? 'selected' : '' ?>><?= $y ?></option>
                    <?php endforeach; ?>
                </select>
                <button type="submit" class="text-sm px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition">Filtrer</button>
            </form>
            <a href="/reports/export/commercial" class="text-sm px-4 py-2 bg-white border border-gray-200 text-gray-700 rounded-lg hover:bg-gray-50 transition flex items-center gap-1.5">
                <i class="fas fa-download text-gray-400"></i> Export
            </a>
        </div>
    </div>

    <!-- KPI: Quote Stats -->
    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div class="bg-white rounded-xl shadow-sm p-5 border border-gray-100">
            <p class="text-sm text-gray-500">Devis émis</p>
            <p class="text-2xl font-bold text-gray-900"><?= (int)($quoteStats['total'] ?? 0) ?></p>
        </div>
        <div class="bg-white rounded-xl shadow-sm p-5 border border-gray-100">
            <p class="text-sm text-gray-500">Devis acceptés</p>
            <p class="text-2xl font-bold text-green-600"><?= (int)($quoteStats['accepted'] ?? 0) ?></p>
        </div>
        <div class="bg-white rounded-xl shadow-sm p-5 border border-gray-100">
            <p class="text-sm text-gray-500">Devis rejetés</p>
            <p class="text-2xl font-bold text-red-600"><?= (int)($quoteStats['rejected'] ?? 0) ?></p>
        </div>
    </div>

    <!-- Monthly Revenue Table -->
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <div class="px-6 py-4 border-b border-gray-100 flex items-center justify-between">
            <h3 class="text-sm font-semibold text-gray-700">Revenus mensuels</h3>
            <span class="text-xs text-gray-400"><?= e($selectedYear ?? date('Y')) ?></span>
        </div>
        <table class="w-full">
            <thead class="bg-gray-50">
                <tr>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Mois</th>
                    <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">Revenus</th>
                    <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">Dépenses</th>
                    <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">Solde</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-100">
                <?php foreach ($monthlyRevenue ?? [] as $row): ?>
                <tr class="hover:bg-gray-50 transition">
                    <td class="px-6 py-4 text-sm font-medium text-gray-700"><?= e($row['month'] ?? '—') ?></td>
                    <td class="px-6 py-4 text-sm text-right text-green-600"><?= formatCurrency($row['income'] ?? 0) ?></td>
                    <td class="px-6 py-4 text-sm text-right text-red-600"><?= formatCurrency($row['expense'] ?? 0) ?></td>
                    <td class="px-6 py-4 text-sm text-right font-semibold <?= ($row['balance'] ?? 0) >= 0 ? 'text-green-700' : 'text-red-700' ?>">
                        <?= formatCurrency($row['balance'] ?? 0) ?>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php if (empty($monthlyRevenue)): ?>
                <tr><td colspan="4" class="px-6 py-8 text-center text-gray-400">Aucune donnée pour cette période</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Top Clients -->
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <div class="px-6 py-4 border-b border-gray-100">
            <h3 class="text-sm font-semibold text-gray-700">Top Clients</h3>
        </div>
        <div class="p-6">
            <?php if (!empty($topClients)): ?>
                <?php $maxAmount = max(array_column($topClients, 'total')); ?>
                <?php foreach ($topClients as $client): ?>
                <div class="flex items-center gap-4 mb-4 last:mb-0">
                    <span class="text-sm font-medium text-gray-700 w-48 truncate" title="<?= e($client['company_name'] ?? $client['name'] ?? '—') ?>">
                        <?= e($client['company_name'] ?? $client['name'] ?? '—') ?>
                    </span>
                    <div class="flex-1 bg-gray-100 rounded-full h-5 overflow-hidden">
                        <div class="bg-blue-500 h-full rounded-full transition-all duration-500" style="width: <?= $maxAmount > 0 ? round((($client['total'] ?? 0) / $maxAmount) * 100) : 0 ?>%"></div>
                    </div>
                    <span class="text-sm font-semibold text-gray-900 w-32 text-right"><?= formatCurrency($client['total'] ?? 0) ?></span>
                </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p class="text-center text-gray-400 py-4">Aucun client</p>
            <?php endif; ?>
        </div>
    </div>
</div>
