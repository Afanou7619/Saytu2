<div class="space-y-6">
    <div class="flex items-center justify-between">
        <h1 class="text-xl font-bold text-gray-900"><?= e($title ?? 'Rapport Ressources Humaines') ?></h1>
        <div>
            <a href="/reports/export/hr" class="text-sm px-4 py-2 bg-white border border-gray-200 text-gray-700 rounded-lg hover:bg-gray-50 transition flex items-center gap-1.5">
                <i class="fas fa-download text-gray-400"></i> Export
            </a>
        </div>
    </div>

    <!-- KPI Cards: Leaves by Type -->
    <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div class="bg-white rounded-xl shadow-sm p-5 border border-gray-100">
            <p class="text-sm text-gray-500">Effectif total</p>
            <p class="text-2xl font-bold text-gray-900"><?= (int)($totalEmployees ?? 0) ?></p>
        </div>
        <?php foreach ($leavesByType ?? [] as $leave): ?>
        <div class="bg-white rounded-xl shadow-sm p-5 border border-gray-100">
            <p class="text-sm text-gray-500"><?= e($leave['type'] ?? '—') ?></p>
            <p class="text-2xl font-bold text-indigo-600"><?= (int)($leave['count'] ?? 0) ?></p>
        </div>
        <?php endforeach; ?>
        <?php if (empty($leavesByType)): ?>
        <div class="bg-white rounded-xl shadow-sm p-5 border border-gray-100 col-span-3">
            <p class="text-sm text-gray-500">Congés</p>
            <p class="text-sm text-gray-400 mt-1">Aucune donnée</p>
        </div>
        <?php endif; ?>
    </div>

    <!-- Employees Table -->
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <div class="px-6 py-4 border-b border-gray-100 flex items-center justify-between">
            <h3 class="text-sm font-semibold text-gray-700">Liste des employés</h3>
            <span class="text-xs text-gray-400"><?= count($employees ?? []) ?> employé(s)</span>
        </div>
        <div class="overflow-x-auto">
            <table class="w-full">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Nom</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Poste</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Département</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Statut</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Ancienneté</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-100">
                    <?php foreach ($employees ?? [] as $emp): ?>
                    <tr class="hover:bg-gray-50 transition">
                        <td class="px-6 py-4">
                            <span class="text-sm font-medium text-gray-900"><?= e(trim(($emp['first_name'] ?? '') . ' ' . ($emp['last_name'] ?? ''))) ?: '—' ?></span>
                        </td>
                        <td class="px-6 py-4 text-sm text-gray-700"><?= e($emp['position'] ?? '—') ?></td>
                        <td class="px-6 py-4 text-sm text-gray-500"><?= e($emp['department'] ?? '—') ?></td>
                        <td class="px-6 py-4"><?= statusBadge($emp['status'] ?? 'active') ?></td>
                        <td class="px-6 py-4 text-sm text-gray-500"><?= e($emp['seniority'] ?? '—') ?></td>
                    </tr>
                    <?php endforeach; ?>
                    <?php if (empty($employees)): ?>
                    <tr><td colspan="5" class="px-6 py-8 text-center text-gray-400">Aucun employé trouvé</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
