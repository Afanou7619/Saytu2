<div class="space-y-6">
    <div class="flex items-center justify-between">
        <h1 class="text-xl font-bold text-gray-900"><?= e($title ?? 'Rapport Academy') ?></h1>
        <div>
            <a href="/reports/export/academy" class="text-sm px-4 py-2 bg-white border border-gray-200 text-gray-700 rounded-lg hover:bg-gray-50 transition flex items-center gap-1.5">
                <i class="fas fa-download text-gray-400"></i> Export
            </a>
        </div>
    </div>

    <!-- KPI Cards -->
    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div class="bg-white rounded-xl shadow-sm p-5 border border-gray-100">
            <p class="text-sm text-gray-500">Total inscriptions</p>
            <p class="text-2xl font-bold text-indigo-600"><?= (int)($totalRegistrations ?? 0) ?></p>
        </div>
        <div class="bg-white rounded-xl shadow-sm p-5 border border-gray-100">
            <p class="text-sm text-gray-500">Revenus générés</p>
            <p class="text-2xl font-bold text-green-600"><?= formatCurrency($totalRevenue ?? 0) ?></p>
        </div>
    </div>

    <!-- Trainings Table -->
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <div class="px-6 py-4 border-b border-gray-100 flex items-center justify-between">
            <h3 class="text-sm font-semibold text-gray-700">Formations</h3>
            <span class="text-xs text-gray-400"><?= count($trainings ?? []) ?> formation(s)</span>
        </div>
        <div class="overflow-x-auto">
            <table class="w-full">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Formation</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Formateur</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Date</th>
                        <th class="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase">Inscriptions</th>
                        <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">Revenus</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Statut</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-100">
                    <?php foreach ($trainings ?? [] as $t): ?>
                    <tr class="hover:bg-gray-50 transition">
                        <td class="px-6 py-4">
                            <span class="text-sm font-medium text-gray-900"><?= e($t['title'] ?? $t['name'] ?? '—') ?></span>
                        </td>
                        <td class="px-6 py-4 text-sm text-gray-700"><?= e($t['trainer_name'] ?? '—') ?></td>
                        <td class="px-6 py-4 text-sm text-gray-500"><?= formatDate($t['start_date'] ?? $t['date'] ?? null) ?></td>
                        <td class="px-6 py-4 text-sm text-center font-semibold text-indigo-600">
                            <?= (int)($t['registrations_count'] ?? $t['registrations'] ?? 0) ?>
                        </td>
                        <td class="px-6 py-4 text-sm text-right font-medium text-green-600">
                            <?= formatCurrency($t['revenue'] ?? 0) ?>
                        </td>
                        <td class="px-6 py-4"><?= statusBadge($t['status'] ?? 'active') ?></td>
                    </tr>
                    <?php endforeach; ?>
                    <?php if (empty($trainings)): ?>
                    <tr><td colspan="6" class="px-6 py-8 text-center text-gray-400">Aucune formation trouvée</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
