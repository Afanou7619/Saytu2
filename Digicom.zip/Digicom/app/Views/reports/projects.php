<div class="space-y-6">
    <div class="flex items-center justify-between">
        <h1 class="text-xl font-bold text-gray-900"><?= e($title ?? 'Rapport Projets') ?></h1>
        <div>
            <a href="/reports/export/projects" class="text-sm px-4 py-2 bg-white border border-gray-200 text-gray-700 rounded-lg hover:bg-gray-50 transition flex items-center gap-1.5">
                <i class="fas fa-download text-gray-400"></i> Export
            </a>
        </div>
    </div>

    <!-- KPI Cards -->
    <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div class="bg-white rounded-xl shadow-sm p-5 border border-gray-100">
            <p class="text-sm text-gray-500">Projets actifs</p>
            <p class="text-2xl font-bold text-blue-600"><?= (int)($stats['active'] ?? 0) ?></p>
        </div>
        <div class="bg-white rounded-xl shadow-sm p-5 border border-gray-100">
            <p class="text-sm text-gray-500">Projets terminés</p>
            <p class="text-2xl font-bold text-green-600"><?= (int)($stats['completed'] ?? 0) ?></p>
        </div>
        <div class="bg-white rounded-xl shadow-sm p-5 border border-gray-100">
            <p class="text-sm text-gray-500">Dans les temps</p>
            <p class="text-2xl font-bold text-emerald-600"><?= (int)($stats['on_time'] ?? 0) ?></p>
        </div>
        <div class="bg-white rounded-xl shadow-sm p-5 border border-gray-100">
            <p class="text-sm text-gray-500">En retard</p>
            <p class="text-2xl font-bold text-red-600"><?= (int)($stats['delayed'] ?? 0) ?></p>
        </div>
    </div>

    <!-- Active Projects Table -->
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <div class="px-6 py-4 border-b border-gray-100 flex items-center justify-between">
            <h3 class="text-sm font-semibold text-gray-700">Projets actifs</h3>
            <span class="text-xs text-gray-400"><?= count($active ?? []) ?> projet(s)</span>
        </div>
        <div class="overflow-x-auto">
            <table class="w-full">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Projet</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Client</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Progression</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Échéance</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Statut</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-100">
                    <?php foreach ($active ?? [] as $project): ?>
                    <tr class="hover:bg-gray-50 transition">
                        <td class="px-6 py-4">
                            <span class="text-sm font-medium text-gray-900"><?= e($project['name'] ?? '—') ?></span>
                        </td>
                        <td class="px-6 py-4 text-sm text-gray-700"><?= e($project['client_name'] ?? '—') ?></td>
                        <td class="px-6 py-4">
                            <div class="flex items-center gap-3">
                                <div class="w-24 bg-gray-200 rounded-full h-2 overflow-hidden">
                                    <div class="bg-blue-500 h-full rounded-full" style="width: <?= max(0, min(100, (int)($project['progress'] ?? 0))) ?>%"></div>
                                </div>
                                <span class="text-xs text-gray-500"><?= (int)($project['progress'] ?? 0) ?>%</span>
                            </div>
                        </td>
                        <td class="px-6 py-4 text-sm text-gray-500"><?= formatDate($project['deadline'] ?? null) ?></td>
                        <td class="px-6 py-4"><?= statusBadge($project['status'] ?? 'active') ?></td>
                    </tr>
                    <?php endforeach; ?>
                    <?php if (empty($active)): ?>
                    <tr><td colspan="5" class="px-6 py-8 text-center text-gray-400">Aucun projet actif</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Completed Projects Table -->
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <div class="px-6 py-4 border-b border-gray-100 flex items-center justify-between">
            <h3 class="text-sm font-semibold text-gray-700">Projets terminés</h3>
            <span class="text-xs text-gray-400"><?= count($completed ?? []) ?> projet(s)</span>
        </div>
        <div class="overflow-x-auto">
            <table class="w-full">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Projet</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Client</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Début</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Livré le</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Respect délai</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-100">
                    <?php foreach ($completed ?? [] as $project): ?>
                    <tr class="hover:bg-gray-50 transition">
                        <td class="px-6 py-4">
                            <span class="text-sm font-medium text-gray-900"><?= e($project['name'] ?? '—') ?></span>
                        </td>
                        <td class="px-6 py-4 text-sm text-gray-700"><?= e($project['client_name'] ?? '—') ?></td>
                        <td class="px-6 py-4 text-sm text-gray-500"><?= formatDate($project['start_date'] ?? null) ?></td>
                        <td class="px-6 py-4 text-sm text-gray-500"><?= formatDate($project['completed_date'] ?? null) ?></td>
                        <td class="px-6 py-4">
                            <?php if (($project['on_time'] ?? false)): ?>
                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                                <i class="fas fa-check-circle mr-1"></i> Dans les temps
                            </span>
                            <?php else: ?>
                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
                                <i class="fas fa-exclamation-circle mr-1"></i> En retard
                            </span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php if (empty($completed)): ?>
                    <tr><td colspan="5" class="px-6 py-8 text-center text-gray-400">Aucun projet terminé</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
