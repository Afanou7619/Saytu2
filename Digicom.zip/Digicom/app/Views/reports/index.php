<div class="space-y-6">
    <div class="flex items-center justify-between">
        <h1 class="text-xl font-bold text-gray-900"><?= e($title ?? 'Rapports') ?></h1>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
        <a href="/reports/commercial" class="bg-white rounded-xl shadow-sm p-6 border border-gray-100 hover:border-blue-200 hover:shadow-md transition">
            <div class="flex items-center gap-4">
                <div class="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                    <i class="fas fa-chart-line text-blue-600 text-xl"></i>
                </div>
                <div>
                    <p class="text-sm font-semibold text-gray-700">Commercial</p>
                    <p class="text-xs text-gray-500">Devis, factures, clients</p>
                </div>
            </div>
        </a>

        <a href="/reports/financial" class="bg-white rounded-xl shadow-sm p-6 border border-gray-100 hover:border-green-200 hover:shadow-md transition">
            <div class="flex items-center gap-4">
                <div class="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                    <i class="fas fa-coins text-green-600 text-xl"></i>
                </div>
                <div>
                    <p class="text-sm font-semibold text-gray-700">Financier</p>
                    <p class="text-xs text-gray-500">Revenus, dépenses, trésorerie</p>
                </div>
            </div>
        </a>

        <a href="/reports/hr" class="bg-white rounded-xl shadow-sm p-6 border border-gray-100 hover:border-purple-200 hover:shadow-md transition">
            <div class="flex items-center gap-4">
                <div class="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                    <i class="fas fa-user-tie text-purple-600 text-xl"></i>
                </div>
                <div>
                    <p class="text-sm font-semibold text-gray-700">Ressources Humaines</p>
                    <p class="text-xs text-gray-500">Effectifs, congés, évaluations</p>
                </div>
            </div>
        </a>

        <a href="/reports/projects" class="bg-white rounded-xl shadow-sm p-6 border border-gray-100 hover:border-orange-200 hover:shadow-md transition">
            <div class="flex items-center gap-4">
                <div class="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
                    <i class="fas fa-diagram-project text-orange-600 text-xl"></i>
                </div>
                <div>
                    <p class="text-sm font-semibold text-gray-700">Projets</p>
                    <p class="text-xs text-gray-500">Avancement, délais, budgets</p>
                </div>
            </div>
        </a>

        <a href="/reports/academy" class="bg-white rounded-xl shadow-sm p-6 border border-gray-100 hover:border-indigo-200 hover:shadow-md transition">
            <div class="flex items-center gap-4">
                <div class="w-12 h-12 bg-indigo-100 rounded-lg flex items-center justify-center">
                    <i class="fas fa-graduation-cap text-indigo-600 text-xl"></i>
                </div>
                <div>
                    <p class="text-sm font-semibold text-gray-700">Academy</p>
                    <p class="text-xs text-gray-500">Formations, inscriptions</p>
                </div>
            </div>
        </a>

        <div class="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
            <h3 class="text-sm font-semibold text-gray-700 mb-3">Exports rapides</h3>
            <div class="space-y-2">
                <a href="/reports/export/clients" class="block text-sm text-blue-600 hover:underline">
                    <i class="fas fa-download mr-1"></i> Export Clients (Excel)
                </a>
                <a href="/reports/export/transactions" class="block text-sm text-blue-600 hover:underline">
                    <i class="fas fa-download mr-1"></i> Export Transactions (Excel)
                </a>
                <a href="/reports/export/invoices" class="block text-sm text-blue-600 hover:underline">
                    <i class="fas fa-download mr-1"></i> Export Factures (Excel)
                </a>
            </div>
        </div>
    </div>
</div>
