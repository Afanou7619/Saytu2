<div class="space-y-6">
    <div class="flex items-center justify-between">
        <h1 class="text-xl font-bold text-gray-900"><?= e($title ?? 'Rapport Financier') ?></h1>
        <div class="flex items-center gap-3">
            <form method="get" class="flex items-center gap-2">
                <select name="year" class="text-sm border border-gray-200 rounded-lg px-3 py-2 bg-white focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                    <?php foreach (($years ?? range(date('Y') - 3, date('Y'))) as $y): ?>
                    <option value="<?= $y ?>" <?= ($selectedYear ?? date('Y')) == $y ? 'selected' : '' ?>><?= $y ?></option>
                    <?php endforeach; ?>
                </select>
                <button type="submit" class="text-sm px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition">Filtrer</button>
            </form>
            <a href="/reports/export/financial" class="text-sm px-4 py-2 bg-white border border-gray-200 text-gray-700 rounded-lg hover:bg-gray-50 transition flex items-center gap-1.5">
                <i class="fas fa-download text-gray-400"></i> Export
            </a>
        </div>
    </div>

    <!-- KPI Cards -->
    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div class="bg-white rounded-xl shadow-sm p-5 border border-gray-100">
            <p class="text-sm text-gray-500">Revenus totaux</p>
            <p class="text-2xl font-bold text-green-600"><?= formatCurrency($totalIncome ?? 0) ?></p>
        </div>
        <div class="bg-white rounded-xl shadow-sm p-5 border border-gray-100">
            <p class="text-sm text-gray-500">Dépenses totales</p>
            <p class="text-2xl font-bold text-red-600"><?= formatCurrency($totalExpense ?? 0) ?></p>
        </div>
        <div class="bg-white rounded-xl shadow-sm p-5 border border-gray-100">
            <p class="text-sm text-gray-500">Solde net</p>
            <p class="text-2xl font-bold <?= ($totalIncome ?? 0) - ($totalExpense ?? 0) >= 0 ? 'text-green-700' : 'text-red-700' ?>">
                <?= formatCurrency(($totalIncome ?? 0) - ($totalExpense ?? 0)) ?>
            </p>
        </div>
    </div>

    <!-- Yearly Breakdown Table -->
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <div class="px-6 py-4 border-b border-gray-100 flex items-center justify-between">
            <h3 class="text-sm font-semibold text-gray-700">Détail mensuel</h3>
            <span class="text-xs text-gray-400"><?= e($selectedYear ?? date('Y')) ?></span>
        </div>
        <table class="w-full">
            <thead class="bg-gray-50">
                <tr>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Mois</th>
                    <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">Revenus</th>
                    <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">Dépenses</th>
                    <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">Net</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-100">
                <?php foreach ($yearlyData ?? [] as $row): ?>
                <tr class="hover:bg-gray-50 transition">
                    <td class="px-6 py-4 text-sm font-medium text-gray-700"><?= e($row['month'] ?? '—') ?></td>
                    <td class="px-6 py-4 text-sm text-right text-green-600"><?= formatCurrency($row['income'] ?? 0) ?></td>
                    <td class="px-6 py-4 text-sm text-right text-red-600"><?= formatCurrency($row['expense'] ?? 0) ?></td>
                    <td class="px-6 py-4 text-sm text-right font-semibold <?= ($row['net'] ?? 0) >= 0 ? 'text-green-700' : 'text-red-700' ?>">
                        <?= formatCurrency($row['net'] ?? 0) ?>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php if (empty($yearlyData)): ?>
                <tr><td colspan="4" class="px-6 py-8 text-center text-gray-400">Aucune donnée pour cette période</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Categories Breakdown -->
    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
            <div class="px-6 py-4 border-b border-gray-100">
                <h3 class="text-sm font-semibold text-gray-700">Répartition par catégorie</h3>
            </div>
            <div class="p-6">
                <?php if (!empty($categories)): ?>
                    <?php $maxCat = max(array_column($categories, 'amount')); ?>
                    <?php foreach ($categories as $cat): ?>
                    <div class="flex items-center gap-4 mb-4 last:mb-0">
                        <span class="text-sm font-medium text-gray-700 w-32 truncate"><?= e($cat['name'] ?? '—') ?></span>
                        <div class="flex-1 bg-gray-100 rounded-full h-4 overflow-hidden">
                            <div class="<?= ($cat['amount'] ?? 0) >= 0 ? 'bg-green-500' : 'bg-red-500' ?> h-full rounded-full transition-all duration-500"
                                 style="width: <?= $maxCat > 0 ? max(round((abs($cat['amount'] ?? 0) / $maxCat) * 100), 4) : 0 ?>%"></div>
                        </div>
                        <span class="text-sm font-semibold text-gray-900 w-28 text-right <?= ($cat['amount'] ?? 0) >= 0 ? 'text-green-600' : 'text-red-600' ?>">
                            <?= formatCurrency($cat['amount'] ?? 0) ?>
                        </span>
                    </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p class="text-center text-gray-400 py-4">Aucune catégorie</p>
                <?php endif; ?>
            </div>
        </div>

        <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
            <h3 class="text-sm font-semibold text-gray-700 mb-4">Résumé</h3>
            <dl class="space-y-3">
                <div class="flex justify-between">
                    <dt class="text-sm text-gray-500">Revenus nets</dt>
                    <dd class="text-sm font-semibold text-green-600"><?= formatCurrency($totalIncome ?? 0) ?></dd>
                </div>
                <div class="flex justify-between">
                    <dt class="text-sm text-gray-500">Dépenses</dt>
                    <dd class="text-sm font-semibold text-red-600"><?= formatCurrency($totalExpense ?? 0) ?></dd>
                </div>
                <div class="border-t border-gray-100 pt-3 flex justify-between">
                    <dt class="text-sm font-medium text-gray-700">Solde</dt>
                    <dd class="text-sm font-bold <?= ($totalIncome ?? 0) - ($totalExpense ?? 0) >= 0 ? 'text-green-700' : 'text-red-700' ?>">
                        <?= formatCurrency(($totalIncome ?? 0) - ($totalExpense ?? 0)) ?>
                    </dd>
                </div>
            </dl>
        </div>
    </div>
</div>
