<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($title ?? 'Impression') ?> – DIGI ERP</title>
    <style>
        body { font-family: 'DejaVu Sans', Arial, sans-serif; font-size: 12px; color: #333; }
        .container { max-width: 800px; margin: 0 auto; padding: 20px; }
        table { width: 100%; border-collapse: collapse; margin: 15px 0; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background: #f8f9fa; }
        .text-right { text-align: right; }
        .text-center { text-align: center; }
        .header { border-bottom: 2px solid #1a56db; padding-bottom: 15px; margin-bottom: 20px; }
        .footer { margin-top: 30px; font-size: 11px; color: #666; }
        @media print { body { padding: 0; } }
    </style>
</head>
<body>
    <div class="container">
        <?= $content ?? '' ?>
    </div>
</body>
</html>
