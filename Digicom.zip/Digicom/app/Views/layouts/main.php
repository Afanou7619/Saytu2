<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($title ?? "DIGI ERP") ?> – DIGI ERP</title>
    <link rel="icon" href="<?= asset("img/logo.jpeg") ?>">

    <!-- Tailwind CSS via CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4"></script>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        primary: '#1a56db',
                        secondary: '#7c3aed',
                        success: '#059669',
                        danger: '#dc2626',
                        warning: '#d97706',
                    }
                }
            }
        }
    </script>
</head>
<body class="bg-gray-50 min-h-screen">
    <div class="flex h-screen overflow-hidden">
        <!-- Sidebar -->
        <aside class="hidden lg:flex lg:flex-col w-64 bg-gray-900 text-white">
            <div class="px-6 py-5 border-b border-gray-700">
                            <img src="<?= asset(
                                "img/logo.jpeg",
                            ) ?>" alt="DIGI COM" class="h-10 mb-2 rounded-[15px]">
                            <p class="text-gray-400 text-xs"><?= e(
                                \App\Core\Auth::name(),
                            ) ?></p>
                        </div>

            <nav class="flex-1 overflow-y-auto py-4 px-3 space-y-1">
                <?php
                $menuItems = [
                    [
                        "icon" => "fa-chart-pie",
                        "label" => "Tableau de bord",
                        "url" => "/dashboard",
                        "module" => "dashboard",
                    ],
                    [
                        "icon" => "fa-users",
                        "label" => "CRM",
                        "url" => "/crm",
                        "module" => "crm",
                    ],
                    [
                        "icon" => "fa-file-invoice",
                        "label" => "Commercial",
                        "url" => "/commercial",
                        "module" => "commercial",
                    ],
                    [
                        "icon" => "fa-diagram-project",
                        "label" => "Projets",
                        "url" => "/projects",
                        "module" => "projects",
                    ],
                    [
                        "icon" => "fa-user-tie",
                        "label" => "RH",
                        "url" => "/hr",
                        "module" => "hr",
                    ],
                    [
                        "icon" => "fa-coins",
                        "label" => "Finance",
                        "url" => "/finance",
                        "module" => "finance",
                    ],
                    [
                        "icon" => "fa-graduation-cap",
                        "label" => "Academy",
                        "url" => "/academy",
                        "module" => "academy",
                    ],
                    [
                        "icon" => "fa-calendar-star",
                        "label" => "Événements",
                        "url" => "/events",
                        "module" => "events",
                    ],
                    [
                        "icon" => "fa-lightbulb",
                        "label" => "Innovation",
                        "url" => "/innovation",
                        "module" => "innovation",
                    ],
                    [
                        "icon" => "fa-folder-open",
                        "label" => "Documents",
                        "url" => "/documents",
                        "module" => "documents",
                    ],
                    [
                        "icon" => "fa-boxes",
                        "label" => "Stock",
                        "url" => "/stock",
                        "module" => "stock",
                    ],
                    [
                        "icon" => "fa-clipboard-check",
                        "label" => "Qualité",
                        "url" => "/quality",
                        "module" => "quality",
                    ],
                    [
                        "icon" => "fa-chart-bar",
                        "label" => "Rapports",
                        "url" => "/reports",
                        "module" => "reports",
                    ],
                ];

                if (\App\Core\Auth::role() === "ceo") {
                    $menuItems[] = [
                        "icon" => "fa-cogs",
                        "label" => "Admin",
                        "url" => "/admin",
                        "module" => "admin",
                    ];
                }

                $currentPath = parse_url($_SERVER["REQUEST_URI"], PHP_URL_PATH);
                foreach ($menuItems as $item):
                    $isActive = str_starts_with($currentPath, $item["url"])
                        ? "bg-gray-800 text-white"
                        : "text-gray-300 hover:bg-gray-800 hover:text-white";
                    if (
                        \App\Core\Auth::can($item["module"], "read") ||
                        $item["module"] === "dashboard"
                    ): ?>
                <a href="<?= e(
                    $item["url"],
                ) ?>" class="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm <?= $isActive ?> transition">
                    <i class="fas <?= $item["icon"] ?> w-5 text-center"></i>
                    <span><?= e($item["label"]) ?></span>
                </a>
                <?php endif;
                endforeach;
                ?>
            </nav>

            <div class="px-3 py-4 border-t border-gray-700">
                <a href="/logout" class="flex items-center gap-3 px-3 py-2 text-sm text-gray-400 hover:text-white rounded-lg hover:bg-gray-800 transition">
                    <i class="fas fa-sign-out-alt w-5 text-center"></i>
                    <span>Déconnexion</span>
                </a>
            </div>
        </aside>

        <!-- Contenu principal -->
        <main class="flex-1 overflow-y-auto">
            <!-- Header -->
            <header class="bg-white shadow-sm border-b border-gray-200 px-6 py-4 flex items-center justify-between">
                <div class="flex items-center gap-4">
                    <button class="lg:hidden text-gray-500" onclick="toggleSidebar()">
                        <i class="fas fa-bars text-xl"></i>
                    </button>
                    <h2 class="text-lg font-semibold text-gray-800"><?= e(
                        $title ?? "DIGI ERP",
                    ) ?></h2>
                </div>
                <div class="flex items-center gap-4">
                    <!-- Notifications -->
                    <?php $unread = \App\Models\Notification::unreadCount(
                        \App\Core\Auth::id(),
                    ); ?>
                    <a href="/notifications" class="relative text-gray-500 hover:text-primary">
                        <i class="fas fa-bell text-lg"></i>
                        <?php if ($unread > 0): ?>
                        <span class="absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center"><?= $unread ?></span>
                        <?php endif; ?>
                    </a>

                    <!-- Profil -->
                    <div class="flex items-center gap-2">
                        <div class="w-8 h-8 bg-primary text-white rounded-full flex items-center justify-center text-sm font-bold">
                            <?= e(
                                mb_substr(\App\Core\Auth::name() ?? "?", 0, 1),
                            ) ?>
                        </div>
                        <span class="text-sm text-gray-600 hidden sm:block"><?= e(
                            \App\Core\Auth::name(),
                        ) ?></span>
                    </div>
                </div>
            </header>

            <!-- Messages flash -->
            <?php if ($msg = flash("success")): ?>
            <div class="mx-6 mt-4 p-4 bg-green-50 border border-green-200 text-green-800 rounded-lg flex items-center gap-3">
                <i class="fas fa-check-circle"></i> <?= e($msg) ?>
            </div>
            <?php endif; ?>
            <?php if ($msg = flash("error")): ?>
            <div class="mx-6 mt-4 p-4 bg-red-50 border border-red-200 text-red-800 rounded-lg flex items-center gap-3">
                <i class="fas fa-exclamation-circle"></i> <?= e($msg) ?>
            </div>
            <?php endif; ?>

            <!-- Contenu de la vue -->
            <div class="p-6">
                <?= $content ?? "" ?>
            </div>
        </main>
    </div>
</body>
</html>
