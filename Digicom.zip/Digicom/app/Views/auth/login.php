<div class="bg-white rounded-xl shadow-lg p-8">
    <div class="text-center mb-6">
        <img src="<?= asset(
            "img/logo.jpeg",
        ) ?>" alt="DIGI COM" class="h-20 mx-auto mb-3 rounded-[15px]">
        <p class="text-gray-500 text-sm">Plateforme de gestion intégrée</p>
    </div>

    <form method="POST" action="/login" class="space-y-4">
        <?= csrfField() ?>

        <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Email</label>
            <input type="email" name="email" required autofocus
                   class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                   placeholder="votre@email.com">
        </div>

        <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Mot de passe</label>
            <input type="password" name="password" required
                   class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                   placeholder="••••••••">
        </div>

        <button type="submit" class="w-full py-2.5 px-4 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg transition">
            <i class="fas fa-sign-in-alt mr-2"></i> Se connecter
        </button>
    </form>

    <div class="mt-6 text-center text-sm text-gray-500">
        <p>DIGI COM © <?= date("Y") ?> – Tous droits réservés</p>
    </div>
</div>
