<div class="bg-white rounded-xl shadow-lg p-8">
    <h2 class="text-xl font-bold text-gray-900 mb-4">Vérification en deux étapes</h2>
    <p class="text-gray-600 mb-6">Entrez le code à 6 chiffres généré par votre application d'authentification.</p>

    <form method="POST" action="/2fa" class="space-y-4">
        <?= csrfField() ?>
        <input type="text" name="code" maxlength="6" required
               class="w-full px-4 py-2.5 border border-gray-300 rounded-lg text-center text-2xl tracking-widest focus:ring-2 focus:ring-blue-500"
               placeholder="000000">

        <button type="submit" class="w-full py-2.5 px-4 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg transition">
            Vérifier
        </button>
    </form>
</div>
