<div class="space-y-6">
    <div class="flex items-center justify-between">
        <h1 class="text-xl font-bold text-gray-900">Employés</h1>
        <a href="/hr/employees/create" class="px-6 py-2.5 bg-blue-600 text-white text-sm rounded-lg hover:bg-blue-700">
            <i class="fas fa-plus mr-1"></i> Nouvel employé
        </a>
    </div>

    <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <table class="w-full">
            <thead class="bg-gray-50">
                <tr>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Nom</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Poste</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Département</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Type contrat</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Statut</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-100">
                <?php foreach ($employees as $emp): ?>
                <tr class="hover:bg-gray-50 transition">
                    <td class="px-6 py-4">
                        <a href="/hr/employees/<?= $emp['id'] ?>" class="text-sm font-medium text-blue-600 hover:underline">
                            <?= e($emp['name']) ?>
                        </a>
                    </td>
                    <td class="px-6 py-4 text-sm text-gray-700"><?= e($emp['position'] ?? '—') ?></td>
                    <td class="px-6 py-4 text-sm text-gray-700"><?= e($emp['department'] ?? '—') ?></td>
                    <td class="px-6 py-4 text-sm text-gray-700"><?= e($emp['contract_type'] ?? '—') ?></td>
                    <td class="px-6 py-4"><?= statusBadge($emp['status'] ?? 'inactive') ?></td>
                </tr>
                <?php endforeach; ?>
                <?php if (empty($employees)): ?>
                <tr>
                    <td colspan="5" class="px-6 py-8 text-center text-gray-400">Aucun employé trouvé</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
