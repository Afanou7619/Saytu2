<div class="space-y-6">
    <div class="flex items-center justify-between">
        <h1 class="text-xl font-bold text-gray-900">Demandes de congés</h1>
        <a href="/hr/leaves/create" class="px-6 py-2.5 bg-blue-600 text-white text-sm rounded-lg hover:bg-blue-700">
            <i class="fas fa-plus mr-1"></i> Nouvelle demande
        </a>
    </div>

    <!-- Filtres -->
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-4">
        <form method="GET" action="/hr/leaves" class="flex flex-wrap items-center gap-3">
            <select name="status" class="px-3 py-2 border border-gray-300 rounded-lg text-sm">
                <option value="">Tous les statuts</option>
                <option value="pending" <?= ($currentStatus ?? '') === 'pending' ? 'selected' : '' ?>>En attente</option>
                <option value="approved" <?= ($currentStatus ?? '') === 'approved' ? 'selected' : '' ?>>Approuvé</option>
                <option value="rejected" <?= ($currentStatus ?? '') === 'rejected' ? 'selected' : '' ?>>Rejeté</option>
            </select>
            <button type="submit" class="px-4 py-2 text-sm bg-gray-100 text-gray-600 rounded-lg hover:bg-gray-200">
                <i class="fas fa-filter mr-1"></i> Filtrer
            </button>
            <?php if (!empty($currentStatus)): ?>
            <a href="/hr/leaves" class="px-4 py-2 text-sm text-gray-500 hover:text-gray-700">
                <i class="fas fa-times mr-1"></i> Réinitialiser
            </a>
            <?php endif; ?>
        </form>
    </div>

    <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <table class="w-full">
            <thead class="bg-gray-50">
                <tr>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Employé</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Type</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Dates</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Jours</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Statut</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-100">
                <?php foreach ($leaves as $leave): ?>
                <tr class="hover:bg-gray-50 transition">
                    <td class="px-6 py-4">
                        <a href="/hr/employees/<?= $leave['employee_id'] ?>" class="text-sm font-medium text-blue-600 hover:underline">
                            <?= e($leave['employee_name'] ?? '—') ?>
                        </a>
                    </td>
                    <td class="px-6 py-4 text-sm text-gray-700"><?= e($leave['type'] ?? '—') ?></td>
                    <td class="px-6 py-4 text-sm text-gray-700">
                        <?= formatDate($leave['start_date'] ?? null) ?> → <?= formatDate($leave['end_date'] ?? null) ?>
                    </td>
                    <td class="px-6 py-4 text-sm text-gray-700"><?= e($leave['days'] ?? '—') ?></td>
                    <td class="px-6 py-4"><?= statusBadge($leave['status'] ?? 'pending') ?></td>
                    <td class="px-6 py-4">
                        <?php if (($leave['status'] ?? '') === 'pending'): ?>
                        <div class="flex gap-1">
                            <form method="POST" action="/hr/leaves/<?= $leave['id'] ?>/approve" class="inline">
                                <?= csrfField() ?>
                                <button type="submit" class="px-3 py-1.5 text-xs bg-green-600 text-white rounded hover:bg-green-700">
                                    <i class="fas fa-check mr-1"></i> Approuver
                                </button>
                            </form>
                            <form method="POST" action="/hr/leaves/<?= $leave['id'] ?>/reject" class="inline">
                                <?= csrfField() ?>
                                <button type="submit" class="px-3 py-1.5 text-xs bg-red-600 text-white rounded hover:bg-red-700">
                                    <i class="fas fa-times mr-1"></i> Rejeter
                                </button>
                            </form>
                        </div>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php if (empty($leaves)): ?>
                <tr>
                    <td colspan="6" class="px-6 py-8 text-center text-gray-400">Aucune demande de congé trouvée</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
