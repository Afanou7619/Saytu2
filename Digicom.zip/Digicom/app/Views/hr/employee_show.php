<div class="space-y-6">
    <div class="flex items-center justify-between">
        <div>
            <h1 class="text-xl font-bold text-gray-900"><?= e($employee['name']) ?></h1>
            <p class="text-sm text-gray-500"><?= e($employee['position'] ?? '') ?> · <?= e($employee['department'] ?? '') ?></p>
        </div>
        <div class="flex gap-2">
            <a href="/hr/employees/<?= $employee['id'] ?>/edit" class="px-4 py-2 text-sm bg-blue-600 text-white rounded-lg hover:bg-blue-700">
                <i class="fas fa-edit mr-1"></i> Modifier
            </a>
        </div>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
        <!-- Informations -->
        <div class="md:col-span-2 space-y-6">
            <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                <h3 class="text-sm font-semibold text-gray-700 mb-4">Informations personnelles</h3>
                <dl class="grid grid-cols-2 gap-3 text-sm">
                    <dt class="text-gray-500">Email</dt>
                    <dd class="text-gray-800"><?= e($employee['email'] ?? '—') ?></dd>
                    <dt class="text-gray-500">Téléphone</dt>
                    <dd class="text-gray-800"><?= e($employee['phone'] ?? '—') ?></dd>
                    <dt class="text-gray-500">Rôle</dt>
                    <dd class="text-gray-800"><?= e($employee['role'] ?? '—') ?></dd>
                    <dt class="text-gray-500">Poste</dt>
                    <dd class="text-gray-800"><?= e($employee['position'] ?? '—') ?></dd>
                    <dt class="text-gray-500">Département</dt>
                    <dd class="text-gray-800"><?= e($employee['department'] ?? '—') ?></dd>
                    <dt class="text-gray-500">Type de contrat</dt>
                    <dd class="text-gray-800"><?= e($employee['contract_type'] ?? '—') ?></dd>
                    <dt class="text-gray-500">Date d'embauche</dt>
                    <dd class="text-gray-800"><?= formatDate($employee['hire_date'] ?? null) ?></dd>
                    <dt class="text-gray-500">Salaire</dt>
                    <dd class="text-gray-800"><?= isset($employee['salary']) ? formatCurrency((float) $employee['salary']) : '—' ?></dd>
                    <dt class="text-gray-500">Manager</dt>
                    <dd class="text-gray-800"><?= e($employee['manager_name'] ?? '—') ?></dd>
                    <dt class="text-gray-500">Statut</dt>
                    <dd><?= statusBadge($employee['status'] ?? 'inactive') ?></dd>
                </dl>
            </div>

            <!-- Congés -->
            <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                <h3 class="text-sm font-semibold text-gray-700 mb-3">Congés (<?= count($leaves ?? []) ?>)</h3>
                <?php if (!empty($leaves)): ?>
                <div class="space-y-2">
                    <?php foreach ($leaves as $leave): ?>
                    <div class="flex items-center justify-between py-2 px-3 rounded-lg hover:bg-gray-50 text-sm">
                        <div>
                            <span class="text-gray-700"><?= e($leave['type'] ?? '—') ?></span>
                            <span class="text-gray-400 ml-2">
                                <?= formatDate($leave['start_date'] ?? null) ?> → <?= formatDate($leave['end_date'] ?? null) ?>
                            </span>
                        </div>
                        <?= statusBadge($leave['status'] ?? 'pending') ?>
                    </div>
                    <?php endforeach; ?>
                </div>
                <?php else: ?>
                <p class="text-sm text-gray-400">Aucun congé enregistré</p>
                <?php endif; ?>
            </div>

            <!-- Évaluations -->
            <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                <h3 class="text-sm font-semibold text-gray-700 mb-3">Évaluations (<?= count($evaluations ?? []) ?>)</h3>
                <?php if (!empty($evaluations)): ?>
                <div class="space-y-2">
                    <?php foreach ($evaluations as $eval): ?>
                    <div class="flex items-center justify-between py-2 px-3 rounded-lg hover:bg-gray-50 text-sm">
                        <div>
                            <span class="text-gray-700"><?= e($eval['period'] ?? '—') ?></span>
                            <span class="text-yellow-600 font-medium ml-2"><?= e($eval['rating'] ?? '—') ?>/5</span>
                        </div>
                        <div class="flex items-center gap-3">
                            <span class="text-gray-400 text-xs"><?= e($eval['evaluator'] ?? '—') ?> · <?= formatDate($eval['date'] ?? null) ?></span>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
                <?php else: ?>
                <p class="text-sm text-gray-400">Aucune évaluation enregistrée</p>
                <?php endif; ?>
            </div>
        </div>

        <!-- Colonne latérale -->
        <div class="space-y-6">
            <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                <h3 class="text-sm font-semibold text-gray-700 mb-3">Actions rapides</h3>
                <div class="space-y-2">
                    <a href="/hr/leaves/create?employee_id=<?= $employee['id'] ?>" class="block w-full px-3 py-2 text-sm text-center bg-green-600 text-white rounded-lg hover:bg-green-700">
                        <i class="fas fa-calendar-plus mr-1"></i> Demande de congé
                    </a>
                    <a href="/hr/evaluations/create?employee_id=<?= $employee['id'] ?>" class="block w-full px-3 py-2 text-sm text-center bg-purple-600 text-white rounded-lg hover:bg-purple-700">
                        <i class="fas fa-star mr-1"></i> Nouvelle évaluation
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
