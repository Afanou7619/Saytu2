<div class="space-y-6">
    <div class="flex items-center justify-between">
        <h1 class="text-xl font-bold text-gray-900">Ressources Humaines</h1>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div class="bg-white rounded-xl shadow-sm p-5 border border-gray-100">
            <p class="text-sm text-gray-500">Effectif total</p>
            <p class="text-2xl font-bold text-gray-900"><?= $totalEmployees ?? 0 ?></p>
        </div>
        <div class="bg-white rounded-xl shadow-sm p-5 border border-gray-100">
            <p class="text-sm text-gray-500">Absents aujourd'hui</p>
            <p class="text-2xl font-bold text-orange-600"><?= count($todayAbsences ?? []) ?></p>
        </div>
        <div class="bg-white rounded-xl shadow-sm p-5 border border-gray-100">
            <p class="text-sm text-gray-500">Congés en attente</p>
            <a href="/hr/leaves" class="text-2xl font-bold text-yellow-600"><?= count($pendingLeaves ?? []) ?></a>
        </div>
        <div class="bg-white rounded-xl shadow-sm p-5 border border-gray-100">
            <p class="text-sm text-gray-500">Actions</p>
            <div class="flex gap-2 mt-1">
                <a href="/hr/employees/create" class="text-xs px-3 py-1.5 bg-blue-600 text-white rounded-lg">Nouvel employé</a>
                <a href="/hr/leaves/create" class="text-xs px-3 py-1.5 bg-green-600 text-white rounded-lg">Demande congé</a>
            </div>
        </div>
    </div>

    <!-- Employés actifs -->
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <div class="px-6 py-4 border-b border-gray-100">
            <h3 class="text-sm font-semibold text-gray-700">Employés actifs</h3>
        </div>
        <table class="w-full">
            <thead class="bg-gray-50">
                <tr>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Nom</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Poste</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Département</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Type</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-100">
                <?php foreach ($activeEmployees as $emp): ?>
                <tr class="hover:bg-gray-50">
                    <td class="px-6 py-4">
                        <a href="/hr/employees/<?= $emp['id'] ?>" class="text-sm font-medium text-blue-600"><?= e($emp['name']) ?></a>
                    </td>
                    <td class="px-6 py-4 text-sm text-gray-700"><?= e($emp['position']) ?></td>
                    <td class="px-6 py-4 text-sm text-gray-700"><?= e($emp['department']) ?></td>
                    <td class="px-6 py-4 text-sm"><?= e($emp['contract_type']) ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <div class="px-6 py-3 border-t">
            <a href="/hr/employees" class="text-sm text-blue-600 hover:underline">Voir tous les employés →</a>
        </div>
    </div>
</div>
