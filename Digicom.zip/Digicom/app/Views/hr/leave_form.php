<div class="max-w-2xl mx-auto space-y-6">
    <h1 class="text-xl font-bold text-gray-900">Demande de congé</h1>

    <form method="POST" action="/hr/leaves/create" class="bg-white rounded-xl shadow-sm border border-gray-100 p-6 space-y-4">
        <?= csrfField() ?>

        <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Type de congé <span class="text-red-500">*</span></label>
            <select name="type" required class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500">
                <option value="">— Sélectionner —</option>
                <option value="paid" <?= old('type') === 'paid' ? 'selected' : '' ?>>Congé payé</option>
                <option value="sick" <?= old('type') === 'sick' ? 'selected' : '' ?>>Congé maladie</option>
                <option value="unpaid" <?= old('type') === 'unpaid' ? 'selected' : '' ?>>Congé sans solde</option>
                <option value="other" <?= old('type') === 'other' ? 'selected' : '' ?>>Autre</option>
            </select>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Date de début <span class="text-red-500">*</span></label>
                <input type="date" name="start_date" value="<?= e(old('start_date')) ?>" required
                       class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Date de fin <span class="text-red-500">*</span></label>
                <input type="date" name="end_date" value="<?= e(old('end_date')) ?>" required
                       class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
            </div>
        </div>

        <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Motif</label>
            <textarea name="reason" rows="4" placeholder="Décrivez le motif de votre demande..."
                      class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500"><?= e(old('reason')) ?></textarea>
        </div>

        <div class="flex gap-3 pt-2">
            <button type="submit" class="px-6 py-2.5 bg-blue-600 text-white text-sm rounded-lg hover:bg-blue-700">
                <i class="fas fa-paper-plane mr-1"></i> Soumettre
            </button>
            <a href="/hr/leaves" class="px-6 py-2.5 bg-gray-100 text-gray-600 text-sm rounded-lg hover:bg-gray-200">Annuler</a>
        </div>
    </form>
</div>
