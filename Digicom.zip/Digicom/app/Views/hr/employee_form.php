<div class="max-w-3xl mx-auto space-y-6">
    <h1 class="text-xl font-bold text-gray-900"><?= isset($employee) ? 'Modifier l\'employé' : 'Nouvel employé' ?></h1>

    <form method="POST" action="<?= isset($employee) ? '/hr/employees/' . $employee['id'] . '/edit' : '/hr/employees/create' ?>" class="bg-white rounded-xl shadow-sm border border-gray-100 p-6 space-y-4">
        <?= csrfField() ?>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Nom complet <span class="text-red-500">*</span></label>
                <input type="text" name="name" value="<?= e($employee['name'] ?? old('name')) ?>" required
                       class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Email <span class="text-red-500">*</span></label>
                <input type="email" name="email" value="<?= e($employee['email'] ?? old('email')) ?>" required
                       class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Rôle <span class="text-red-500">*</span></label>
                <select name="role" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500">
                    <option value="">— Sélectionner —</option>
                    <option value="admin" <?= ($employee['role'] ?? old('role')) === 'admin' ? 'selected' : '' ?>>Administrateur</option>
                    <option value="manager" <?= ($employee['role'] ?? old('role')) === 'manager' ? 'selected' : '' ?>>Manager</option>
                    <option value="employee" <?= ($employee['role'] ?? old('role')) === 'employee' ? 'selected' : '' ?>>Employé</option>
                </select>
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Téléphone</label>
                <input type="text" name="phone" value="<?= e($employee['phone'] ?? old('phone')) ?>"
                       class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
            </div>
            <?php if (!isset($employee)): ?>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Mot de passe <span class="text-red-500">*</span></label>
                <input type="password" name="password" required
                       class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
            </div>
            <?php endif; ?>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Poste</label>
                <input type="text" name="position" value="<?= e($employee['position'] ?? old('position')) ?>"
                       class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Département</label>
                <input type="text" name="department" value="<?= e($employee['department'] ?? old('department')) ?>"
                       class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Type de contrat</label>
                <select name="contract_type" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500">
                    <option value="">— Sélectionner —</option>
                    <option value="CDI" <?= ($employee['contract_type'] ?? old('contract_type')) === 'CDI' ? 'selected' : '' ?>>CDI</option>
                    <option value="CDD" <?= ($employee['contract_type'] ?? old('contract_type')) === 'CDD' ? 'selected' : '' ?>>CDD</option>
                    <option value="Stage" <?= ($employee['contract_type'] ?? old('contract_type')) === 'Stage' ? 'selected' : '' ?>>Stage</option>
                    <option value="Freelance" <?= ($employee['contract_type'] ?? old('contract_type')) === 'Freelance' ? 'selected' : '' ?>>Freelance</option>
                </select>
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Date d'embauche</label>
                <input type="date" name="hire_date" value="<?= e($employee['hire_date'] ?? old('hire_date')) ?>"
                       class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Salaire</label>
                <input type="number" name="salary" step="0.01" value="<?= e($employee['salary'] ?? old('salary')) ?>"
                       class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Manager</label>
                <select name="manager_id" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500">
                    <option value="">— Aucun —</option>
                    <?php foreach ($managers as $mgr): ?>
                    <option value="<?= $mgr['id'] ?>" <?= ($employee['manager_id'] ?? old('manager_id')) == $mgr['id'] ? 'selected' : '' ?>>
                        <?= e($mgr['name']) ?>
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>

        <div class="flex gap-3 pt-2">
            <button type="submit" class="px-6 py-2.5 bg-blue-600 text-white text-sm rounded-lg hover:bg-blue-700">
                <i class="fas fa-save mr-1"></i> Enregistrer
            </button>
            <a href="/hr/employees" class="px-6 py-2.5 bg-gray-100 text-gray-600 text-sm rounded-lg hover:bg-gray-200">Annuler</a>
        </div>
    </form>
</div>
