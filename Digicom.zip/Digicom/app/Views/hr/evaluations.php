<div class="space-y-6">
    <div class="flex items-center justify-between">
        <h1 class="text-xl font-bold text-gray-900">Évaluations</h1>
        <a href="/hr/evaluations/create" class="px-6 py-2.5 bg-blue-600 text-white text-sm rounded-lg hover:bg-blue-700">
            <i class="fas fa-plus mr-1"></i> Nouvelle évaluation
        </a>
    </div>

    <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <table class="w-full">
            <thead class="bg-gray-50">
                <tr>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Employé</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Période</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Note</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Évaluateur</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Date</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-100">
                <?php foreach ($evaluations as $eval): ?>
                <tr class="hover:bg-gray-50 transition">
                    <td class="px-6 py-4">
                        <a href="/hr/employees/<?= $eval['employee_id'] ?>" class="text-sm font-medium text-blue-600 hover:underline">
                            <?= e($eval['employee_name'] ?? '—') ?>
                        </a>
                    </td>
                    <td class="px-6 py-4 text-sm text-gray-700"><?= e($eval['period'] ?? '—') ?></td>
                    <td class="px-6 py-4">
                        <span class="inline-flex items-center px-2 py-1 text-sm font-medium rounded-full bg-yellow-100 text-yellow-800">
                            <?= e($eval['rating'] ?? '—') ?>/5
                        </span>
                    </td>
                    <td class="px-6 py-4 text-sm text-gray-700"><?= e($eval['evaluator'] ?? '—') ?></td>
                    <td class="px-6 py-4 text-sm text-gray-500"><?= formatDate($eval['date'] ?? null) ?></td>
                </tr>
                <?php endforeach; ?>
                <?php if (empty($evaluations)): ?>
                <tr>
                    <td colspan="5" class="px-6 py-8 text-center text-gray-400">Aucune évaluation trouvée</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
