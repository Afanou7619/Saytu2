<div class="max-w-2xl mx-auto space-y-6">
    <h1 class="text-xl font-bold text-gray-900">Nouvelle évaluation</h1>

    <form method="POST" action="/hr/evaluations/create" class="bg-white rounded-xl shadow-sm border border-gray-100 p-6 space-y-4">
        <?= csrfField() ?>

        <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Employé <span class="text-red-500">*</span></label>
            <select name="employee_id" required class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500">
                <option value="">— Sélectionner —</option>
                <?php foreach ($employees as $emp): ?>
                <option value="<?= $emp['id'] ?>" <?= old('employee_id') == $emp['id'] ? 'selected' : '' ?>>
                    <?= e($emp['name']) ?> — <?= e($emp['department'] ?? '') ?>
                </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Période <span class="text-red-500">*</span></label>
                <input type="text" name="period" value="<?= e(old('period')) ?>" placeholder="Ex: T1 2026" required
                       class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Note (1-5) <span class="text-red-500">*</span></label>
                <input type="number" name="rating" min="1" max="5" step="1" value="<?= e(old('rating', '3')) ?>" required
                       class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
            </div>
        </div>

        <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Commentaires généraux</label>
            <textarea name="comments" rows="3" placeholder="Commentaires sur la performance globale..."
                      class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500"><?= e(old('comments')) ?></textarea>
        </div>

        <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Points forts</label>
            <textarea name="strengths" rows="3" placeholder="Compétences et réalisations notables..."
                      class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500"><?= e(old('strengths')) ?></textarea>
        </div>

        <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Axes d'amélioration</label>
            <textarea name="improvements" rows="3" placeholder="Points à travailler et objectifs..."
                      class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500"><?= e(old('improvements')) ?></textarea>
        </div>

        <div class="flex gap-3 pt-2">
            <button type="submit" class="px-6 py-2.5 bg-blue-600 text-white text-sm rounded-lg hover:bg-blue-700">
                <i class="fas fa-save mr-1"></i> Enregistrer
            </button>
            <a href="/hr/evaluations" class="px-6 py-2.5 bg-gray-100 text-gray-600 text-sm rounded-lg hover:bg-gray-200">Annuler</a>
        </div>
    </form>
</div>
