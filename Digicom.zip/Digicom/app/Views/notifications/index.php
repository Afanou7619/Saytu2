<div class="space-y-6">
    <div class="flex items-center justify-between">
        <h1 class="text-xl font-bold text-gray-900">Notifications</h1>
        <?php if ($unreadCount > 0): ?>
        <form method="POST" action="/notifications/read-all">
            <?= csrfField() ?>
            <button type="submit" class="px-4 py-2 text-sm bg-blue-600 text-white rounded-lg hover:bg-blue-700">
                <i class="fas fa-check-double mr-1"></i> Tout marquer comme lu
            </button>
        </form>
        <?php endif; ?>
    </div>

    <?php if (!empty($notifications)): ?>
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 divide-y divide-gray-100">
        <?php foreach ($notifications as $notif): ?>
        <div class="px-6 py-4 hover:bg-gray-50 transition <?= !$notif['is_read'] ? 'bg-blue-50/50 border-l-4 border-blue-500' : '' ?>">
            <div class="flex items-start justify-between">
                <a href="<?= e($notif['link'] ?: '#') ?>" class="flex-1">
                    <h4 class="text-sm font-medium text-gray-800"><?= e($notif['title']) ?></h4>
                    <p class="text-xs text-gray-500 mt-1"><?= e($notif['message']) ?></p>
                </a>
                <div class="flex items-center gap-2">
                    <span class="text-xs text-gray-400"><?= timeAgo($notif['created_at']) ?></span>
                    <?php if (!$notif['is_read']): ?>
                    <span class="w-2 h-2 bg-blue-500 rounded-full"></span>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <?php else: ?>
    <div class="text-center py-12 text-gray-400">
        <i class="fas fa-bell-slash text-4xl mb-3"></i>
        <p>Aucune notification</p>
    </div>
    <?php endif; ?>
</div>
