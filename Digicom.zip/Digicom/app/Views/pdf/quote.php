<div style="font-family: DejaVu Sans, sans-serif; max-width: 700px; margin: auto; padding: 30px;">
    <div style="border-bottom: 2px solid #1a56db; padding-bottom: 15px; margin-bottom: 20px;">
        <table width="100%">
            <tr>
                <td>
                    <h1 style="margin:0; color:#1a56db; font-size:24px;">DIGI COM</h1>
                    <p style="margin:4px 0; font-size:12px; color:#666;">Agence de Communication</p>
                </td>
                <td align="right">
                    <h2 style="margin:0; font-size:20px; color:#333;">DEVIS</h2>
                    <p style="margin:4px 0; font-size:12px;"><?= e($quote['reference']) ?></p>
                </td>
            </tr>
        </table>
    </div>

    <table width="100%" style="margin-bottom: 20px;">
        <tr>
            <td width="50%" style="vertical-align: top;">
                <strong style="font-size:12px;">Facturé à :</strong><br>
                <span style="font-size:13px;"><?= e($client['company_name'] ?? '') ?></span><br>
                <span style="font-size:12px; color:#555;"><?= e($client['contact_name'] ?? '') ?></span><br>
                <span style="font-size:12px; color:#555;"><?= e($client['email'] ?? '') ?></span><br>
                <span style="font-size:12px; color:#555;"><?= e($client['address'] ?? '') ?></span>
            </td>
            <td width="50%" align="right" style="vertical-align: top;">
                <table style="font-size:12px;">
                    <tr><td><strong>Date :</strong></td><td><?= formatDate($quote['created_at']) ?></td></tr>
                    <tr><td><strong>Valide jusqu'au :</strong></td><td><?= formatDate($quote['valid_until'] ?? null) ?></td></tr>
                    <tr><td><strong>Statut :</strong></td><td><?= e($quote['status']) ?></td></tr>
                </table>
            </td>
        </tr>
    </table>

    <table width="100%" style="border-collapse: collapse; margin-bottom: 20px;">
        <thead>
            <tr style="background:#f8f9fa;">
                <th style="border:1px solid #ddd; padding: 8px; text-align:left; font-size:12px;">Description</th>
                <th style="border:1px solid #ddd; padding: 8px; text-align:center; font-size:12px;">Qté</th>
                <th style="border:1px solid #ddd; padding: 8px; text-align:right; font-size:12px;">Prix unitaire</th>
                <th style="border:1px solid #ddd; padding: 8px; text-align:right; font-size:12px;">Total</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($items as $item): ?>
            <tr>
                <td style="border:1px solid #ddd; padding: 8px; font-size:12px;"><?= e($item['description']) ?></td>
                <td style="border:1px solid #ddd; padding: 8px; text-align:center; font-size:12px;"><?= $item['quantity'] ?></td>
                <td style="border:1px solid #ddd; padding: 8px; text-align:right; font-size:12px;"><?= formatCurrency($item['unit_price'] ?? 0) ?></td>
                <td style="border:1px solid #ddd; padding: 8px; text-align:right; font-size:12px;"><?= formatCurrency($item['total'] ?? 0) ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <div style="float:right; width:250px;">
        <table width="100%" style="font-size:14px;">
            <tr>
                <td style="padding:4px 0;">Total HT</td>
                <td align="right"><?= formatCurrency($quote['total_ht'] ?? 0) ?></td>
            </tr>
            <tr>
                <td style="padding:4px 0;">TVA (<?= $quote['tax_rate'] ?? 18 ?>%)</td>
                <td align="right"><?= formatCurrency(($quote['total_ttc'] ?? 0) - ($quote['total_ht'] ?? 0)) ?></td>
            </tr>
            <tr style="border-top:2px solid #333; font-weight:bold; font-size:16px;">
                <td style="padding:8px 0;">Total TTC</td>
                <td align="right"><?= formatCurrency($quote['total_ttc'] ?? 0) ?></td>
            </tr>
        </table>
    </div>

    <?php if ($quote['notes']): ?>
    <div style="clear:both; margin-top:30px; padding-top:20px; border-top:1px solid #eee;">
        <strong style="font-size:12px;">Notes :</strong>
        <p style="font-size:12px; color:#555;"><?= nl2br(e($quote['notes'])) ?></p>
    </div>
    <?php endif; ?>

    <div style="margin-top:50px; text-align:center; font-size:11px; color:#999;">
        <p>DIGI COM – Agence de Communication</p>
        <p>Devis généré le <?= date('d/m/Y à H:i') ?></p>
    </div>
</div>
