<div class="space-y-6">
    <div class="flex items-center justify-between">
        <h1 class="text-xl font-bold text-gray-900">Événementiel & Activation</h1>
        <a href="/events/create" class="px-4 py-2 text-sm bg-blue-600 text-white rounded-lg hover:bg-blue-700">
            <i class="fas fa-plus mr-1"></i> Nouvel événement
        </a>
    </div>

    <?php if (!empty($upcoming)): ?>
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <div class="px-6 py-4 border-b border-gray-100">
            <h3 class="text-sm font-semibold text-gray-700">Événements à venir</h3>
        </div>
        <div class="divide-y divide-gray-100">
            <?php foreach ($upcoming as $event): ?>
            <a href="/events/<?= $event['id'] ?>" class="flex items-center justify-between px-6 py-4 hover:bg-gray-50 transition">
                <div>
                    <p class="text-sm font-medium text-gray-800"><?= e($event['title']) ?></p>
                    <p class="text-xs text-gray-500">
                        <i class="far fa-calendar mr-1"></i><?= formatDateTime($event['start_datetime']) ?>
                        · <i class="fas fa-map-marker-alt mr-1"></i><?= e($event['location']) ?>
                    </p>
                </div>
                <div class="flex items-center gap-3">
                    <?= statusBadge($event['status']) ?>
                    <span class="text-sm font-medium"><?= formatCurrency($event['budget'] ?? 0) ?></span>
                </div>
            </a>
            <?php endforeach; ?>
        </div>
    </div>
    <?php endif; ?>

    <?php if (!empty($events['items'])): ?>
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <div class="px-6 py-4 border-b border-gray-100">
            <h3 class="text-sm font-semibold text-gray-700">Tous les événements</h3>
        </div>
        <table class="w-full">
            <thead class="bg-gray-50">
                <tr>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Titre</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Type</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Date</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Lieu</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Statut</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-100">
                <?php foreach ($events['items'] as $e): ?>
                <tr class="hover:bg-gray-50">
                    <td class="px-6 py-4"><a href="/events/<?= $e['id'] ?>" class="text-sm font-medium text-blue-600"><?= e($e['title']) ?></a></td>
                    <td class="px-6 py-4 text-sm"><?= e($e['type']) ?></td>
                    <td class="px-6 py-4 text-sm"><?= formatDateTime($e['start_datetime']) ?></td>
                    <td class="px-6 py-4 text-sm"><?= e($e['location']) ?></td>
                    <td class="px-6 py-4"><?= statusBadge($e['status']) ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
</div>
