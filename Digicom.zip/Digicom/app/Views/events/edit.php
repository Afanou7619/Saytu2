<div class="max-w-3xl mx-auto">
    <div class="mb-6 flex items-center justify-between">
        <div>
            <h3 class="text-xl font-semibold text-gray-800">Modifier l'événement</h3>
            <p class="text-sm text-gray-500 mt-1"><?= e($event['title']) ?></p>
        </div>
        <a href="/events/<?= e($event['id']) ?>" class="text-sm text-primary hover:underline">
            <i class="fas fa-arrow-left mr-1"></i> Retour
        </a>
    </div>

    <form action="/events/<?= e($event['id']) ?>/edit" method="POST" class="bg-white rounded-xl shadow-sm border border-gray-200 p-6 space-y-6">
        <?= csrfField() ?>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <!-- Titre -->
            <div class="md:col-span-2">
                <label for="title" class="block text-sm font-medium text-gray-700 mb-1">Titre <span class="text-red-500">*</span></label>
                <input type="text" name="title" id="title" value="<?= e(old('title', $event['title'])) ?>" required
                    class="w-full border border-gray-300 rounded-lg px-4 py-2.5 text-sm focus:ring-2 focus:ring-primary focus:border-primary outline-none">
            </div>

            <!-- Type -->
            <div>
                <label for="type" class="block text-sm font-medium text-gray-700 mb-1">Type <span class="text-red-500">*</span></label>
                <select name="type" id="type" required
                    class="w-full border border-gray-300 rounded-lg px-4 py-2.5 text-sm focus:ring-2 focus:ring-primary focus:border-primary outline-none bg-white">
                    <option value="">-- Sélectionner --</option>
                    <?php $types = ['conference' => 'Conférence', 'workshop' => 'Atelier', 'activation' => 'Activation', 'internal' => 'Interne', 'other' => 'Autre']; ?>
                    <?php foreach ($types as $val => $label): ?>
                    <option value="<?= $val ?>" <?= (old('type', $event['type']) === $val) ? 'selected' : '' ?>><?= $label ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <!-- Statut -->
            <div>
                <label for="status" class="block text-sm font-medium text-gray-700 mb-1">Statut</label>
                <select name="status" id="status"
                    class="w-full border border-gray-300 rounded-lg px-4 py-2.5 text-sm focus:ring-2 focus:ring-primary focus:border-primary outline-none bg-white">
                    <?php $statuses = ['draft' => 'Brouillon', 'planned' => 'Planifié', 'confirmed' => 'Confirmé', 'in_progress' => 'En cours', 'completed' => 'Terminé', 'cancelled' => 'Annulé']; ?>
                    <?php foreach ($statuses as $val => $label): ?>
                    <option value="<?= $val ?>" <?= (old('status', $event['status']) === $val) ? 'selected' : '' ?>><?= $label ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <!-- Date/Heure début -->
            <div>
                <label for="start_datetime" class="block text-sm font-medium text-gray-700 mb-1">Début <span class="text-red-500">*</span></label>
                <input type="datetime-local" name="start_datetime" id="start_datetime"
                    value="<?= e(old('start_datetime', $event['start_datetime'] ? date('Y-m-d\TH:i', strtotime($event['start_datetime'])) : '')) ?>" required
                    class="w-full border border-gray-300 rounded-lg px-4 py-2.5 text-sm focus:ring-2 focus:ring-primary focus:border-primary outline-none">
            </div>

            <!-- Date/Heure fin -->
            <div>
                <label for="end_datetime" class="block text-sm font-medium text-gray-700 mb-1">Fin <span class="text-red-500">*</span></label>
                <input type="datetime-local" name="end_datetime" id="end_datetime"
                    value="<?= e(old('end_datetime', $event['end_datetime'] ? date('Y-m-d\TH:i', strtotime($event['end_datetime'])) : '')) ?>" required
                    class="w-full border border-gray-300 rounded-lg px-4 py-2.5 text-sm focus:ring-2 focus:ring-primary focus:border-primary outline-none">
            </div>

            <!-- Lieu -->
            <div>
                <label for="location" class="block text-sm font-medium text-gray-700 mb-1">Lieu</label>
                <input type="text" name="location" id="location" value="<?= e(old('location', $event['location'])) ?>"
                    class="w-full border border-gray-300 rounded-lg px-4 py-2.5 text-sm focus:ring-2 focus:ring-primary focus:border-primary outline-none">
            </div>

            <!-- Budget -->
            <div>
                <label for="budget" class="block text-sm font-medium text-gray-700 mb-1">Budget</label>
                <input type="number" name="budget" id="budget" value="<?= e(old('budget', $event['budget'])) ?>" min="0" step="0.01"
                    class="w-full border border-gray-300 rounded-lg px-4 py-2.5 text-sm focus:ring-2 focus:ring-primary focus:border-primary outline-none">
            </div>

            <!-- Dépenses -->
            <div>
                <label for="spent" class="block text-sm font-medium text-gray-700 mb-1">
                    Dépenses
                    <?php if (!empty($event['budget'])): ?>
                    <span class="text-xs text-gray-400"> / Budget: <?= formatCurrency((float)$event['budget']) ?></span>
                    <?php endif; ?>
                </label>
                <input type="number" name="spent" id="spent" value="<?= e(old('spent', $event['spent'] ?? '0')) ?>" min="0" step="0.01"
                    class="w-full border border-gray-300 rounded-lg px-4 py-2.5 text-sm focus:ring-2 focus:ring-primary focus:border-primary outline-none">
            </div>

            <!-- Responsable -->
            <div>
                <label for="responsible_id" class="block text-sm font-medium text-gray-700 mb-1">Responsable</label>
                <select name="responsible_id" id="responsible_id"
                    class="w-full border border-gray-300 rounded-lg px-4 py-2.5 text-sm focus:ring-2 focus:ring-primary focus:border-primary outline-none bg-white">
                    <option value="">-- Sélectionner --</option>
                    <?php foreach ($users as $user): ?>
                    <option value="<?= e($user['id']) ?>" <?= (old('responsible_id', $event['responsible_id']) == $user['id']) ? 'selected' : '' ?>>
                        <?= e($user['name']) ?>
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <!-- Nombre max participants -->
            <div>
                <label for="max_participants" class="block text-sm font-medium text-gray-700 mb-1">Participants max</label>
                <input type="number" name="max_participants" id="max_participants" value="<?= e(old('max_participants', $event['max_participants'])) ?>" min="0"
                    class="w-full border border-gray-300 rounded-lg px-4 py-2.5 text-sm focus:ring-2 focus:ring-primary focus:border-primary outline-none">
            </div>
        </div>

        <!-- Description -->
        <div>
            <label for="description" class="block text-sm font-medium text-gray-700 mb-1">Description</label>
            <textarea name="description" id="description" rows="4"
                class="w-full border border-gray-300 rounded-lg px-4 py-2.5 text-sm focus:ring-2 focus:ring-primary focus:border-primary outline-none"><?= e(old('description', $event['description'])) ?></textarea>
        </div>

        <div class="flex items-center justify-end gap-3 pt-4 border-t border-gray-100">
            <a href="/events/<?= e($event['id']) ?>" class="px-4 py-2.5 text-sm text-gray-600 hover:text-gray-800 border border-gray-300 rounded-lg hover:bg-gray-50 transition">
                Annuler
            </a>
            <button type="submit" class="px-6 py-2.5 bg-primary text-white text-sm font-medium rounded-lg hover:bg-blue-700 transition">
                <i class="fas fa-save mr-2"></i> Enregistrer
            </button>
        </div>
    </form>
</div>
