<div class="max-w-3xl mx-auto">
    <div class="mb-6 flex items-center justify-between">
        <div>
            <h3 class="text-xl font-semibold text-gray-800">Nouvel événement</h3>
            <p class="text-sm text-gray-500 mt-1">Créez un nouvel événement dans le calendrier</p>
        </div>
        <a href="/events" class="text-sm text-primary hover:underline">
            <i class="fas fa-arrow-left mr-1"></i> Retour
        </a>
    </div>

    <form action="/events/create" method="POST" class="bg-white rounded-xl shadow-sm border border-gray-200 p-6 space-y-6">
        <?= csrfField() ?>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <!-- Titre -->
            <div class="md:col-span-2">
                <label for="title" class="block text-sm font-medium text-gray-700 mb-1">Titre <span class="text-red-500">*</span></label>
                <input type="text" name="title" id="title" value="<?= e(old('title')) ?>" required
                    class="w-full border border-gray-300 rounded-lg px-4 py-2.5 text-sm focus:ring-2 focus:ring-primary focus:border-primary outline-none"
                    placeholder="Titre de l'événement">
            </div>

            <!-- Type -->
            <div>
                <label for="type" class="block text-sm font-medium text-gray-700 mb-1">Type <span class="text-red-500">*</span></label>
                <select name="type" id="type" required
                    class="w-full border border-gray-300 rounded-lg px-4 py-2.5 text-sm focus:ring-2 focus:ring-primary focus:border-primary outline-none bg-white">
                    <option value="">-- Sélectionner --</option>
                    <option value="conference" <?= old('type') === 'conference' ? 'selected' : '' ?>>Conférence</option>
                    <option value="workshop" <?= old('type') === 'workshop' ? 'selected' : '' ?>>Atelier</option>
                    <option value="activation" <?= old('type') === 'activation' ? 'selected' : '' ?>>Activation</option>
                    <option value="internal" <?= old('type') === 'internal' ? 'selected' : '' ?>>Interne</option>
                    <option value="other" <?= old('type') === 'other' ? 'selected' : '' ?>>Autre</option>
                </select>
            </div>

            <!-- Statut -->
            <div>
                <label for="status" class="block text-sm font-medium text-gray-700 mb-1">Statut</label>
                <select name="status" id="status"
                    class="w-full border border-gray-300 rounded-lg px-4 py-2.5 text-sm focus:ring-2 focus:ring-primary focus:border-primary outline-none bg-white">
                    <option value="draft" <?= old('status') === 'draft' ? 'selected' : '' ?>>Brouillon</option>
                    <option value="planned" <?= old('status', 'planned') === 'planned' ? 'selected' : '' ?>>Planifié</option>
                    <option value="confirmed" <?= old('status') === 'confirmed' ? 'selected' : '' ?>>Confirmé</option>
                </select>
            </div>

            <!-- Date/Heure début -->
            <div>
                <label for="start_datetime" class="block text-sm font-medium text-gray-700 mb-1">Début <span class="text-red-500">*</span></label>
                <input type="datetime-local" name="start_datetime" id="start_datetime" value="<?= e(old('start_datetime')) ?>" required
                    class="w-full border border-gray-300 rounded-lg px-4 py-2.5 text-sm focus:ring-2 focus:ring-primary focus:border-primary outline-none">
            </div>

            <!-- Date/Heure fin -->
            <div>
                <label for="end_datetime" class="block text-sm font-medium text-gray-700 mb-1">Fin <span class="text-red-500">*</span></label>
                <input type="datetime-local" name="end_datetime" id="end_datetime" value="<?= e(old('end_datetime')) ?>" required
                    class="w-full border border-gray-300 rounded-lg px-4 py-2.5 text-sm focus:ring-2 focus:ring-primary focus:border-primary outline-none">
            </div>

            <!-- Lieu -->
            <div>
                <label for="location" class="block text-sm font-medium text-gray-700 mb-1">Lieu</label>
                <input type="text" name="location" id="location" value="<?= e(old('location')) ?>"
                    class="w-full border border-gray-300 rounded-lg px-4 py-2.5 text-sm focus:ring-2 focus:ring-primary focus:border-primary outline-none"
                    placeholder="Lieu de l'événement">
            </div>

            <!-- Budget -->
            <div>
                <label for="budget" class="block text-sm font-medium text-gray-700 mb-1">Budget</label>
                <input type="number" name="budget" id="budget" value="<?= e(old('budget')) ?>" min="0" step="0.01"
                    class="w-full border border-gray-300 rounded-lg px-4 py-2.5 text-sm focus:ring-2 focus:ring-primary focus:border-primary outline-none"
                    placeholder="0">
            </div>

            <!-- Responsable -->
            <div>
                <label for="responsible_id" class="block text-sm font-medium text-gray-700 mb-1">Responsable</label>
                <select name="responsible_id" id="responsible_id"
                    class="w-full border border-gray-300 rounded-lg px-4 py-2.5 text-sm focus:ring-2 focus:ring-primary focus:border-primary outline-none bg-white">
                    <option value="">-- Sélectionner --</option>
                    <?php foreach ($users as $user): ?>
                    <option value="<?= e($user['id']) ?>" <?= old('responsible_id') == $user['id'] ? 'selected' : '' ?>>
                        <?= e($user['name']) ?>
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <!-- Nombre max participants -->
            <div>
                <label for="max_participants" class="block text-sm font-medium text-gray-700 mb-1">Participants max</label>
                <input type="number" name="max_participants" id="max_participants" value="<?= e(old('max_participants')) ?>" min="0"
                    class="w-full border border-gray-300 rounded-lg px-4 py-2.5 text-sm focus:ring-2 focus:ring-primary focus:border-primary outline-none"
                    placeholder="Nombre maximum de participants">
            </div>
        </div>

        <!-- Description -->
        <div>
            <label for="description" class="block text-sm font-medium text-gray-700 mb-1">Description</label>
            <textarea name="description" id="description" rows="4"
                class="w-full border border-gray-300 rounded-lg px-4 py-2.5 text-sm focus:ring-2 focus:ring-primary focus:border-primary outline-none"
                placeholder="Description de l'événement..."><?= e(old('description')) ?></textarea>
        </div>

        <div class="flex items-center justify-end gap-3 pt-4 border-t border-gray-100">
            <a href="/events" class="px-4 py-2.5 text-sm text-gray-600 hover:text-gray-800 border border-gray-300 rounded-lg hover:bg-gray-50 transition">
                Annuler
            </a>
            <button type="submit" class="px-6 py-2.5 bg-primary text-white text-sm font-medium rounded-lg hover:bg-blue-700 transition">
                <i class="fas fa-save mr-2"></i> Créer l'événement
            </button>
        </div>
    </form>
</div>
