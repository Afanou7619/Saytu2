<?php
$eventTypes = [
    'conference'  => 'Conférence',
    'workshop'    => 'Atelier',
    'activation'  => 'Activation',
    'internal'    => 'Interne',
    'other'       => 'Autre',
];
?>

<div class="max-w-4xl mx-auto">
    <!-- En-tête -->
    <div class="mb-6 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div class="flex items-center gap-3">
            <a href="/events" class="text-gray-400 hover:text-gray-600">
                <i class="fas fa-arrow-left"></i>
            </a>
            <div>
                <h3 class="text-xl font-semibold text-gray-800"><?= e($event['title']) ?></h3>
                <p class="text-sm text-gray-500 mt-1">
                    <?= $eventTypes[$event['type']] ?? e($event['type']) ?>
                    &middot; <?= statusBadge($event['status']) ?>
                </p>
            </div>
        </div>
        <div class="flex items-center gap-3">
            <a href="/events/<?= e($event['id']) ?>/edit"
                class="px-4 py-2 text-sm bg-primary text-white rounded-lg hover:bg-blue-700 transition">
                <i class="fas fa-edit mr-2"></i> Modifier
            </a>
            <?php if ($event['status'] !== 'cancelled'): ?>
            <form action="/events/<?= e($event['id']) ?>/cancel" method="POST" onsubmit="return confirm('Annuler cet événement ?')">
                <?= csrfField() ?>
                <button type="submit"
                    class="px-4 py-2 text-sm bg-red-50 text-red-600 border border-red-200 rounded-lg hover:bg-red-100 transition">
                    <i class="fas fa-ban mr-2"></i> Annuler
                </button>
            </form>
            <?php endif; ?>
        </div>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <!-- Détails -->
        <div class="lg:col-span-2 space-y-6">
            <!-- Infos -->
            <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                <h4 class="text-sm font-semibold text-gray-500 uppercase tracking-wider mb-4">Détails</h4>
                <dl class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                        <dt class="text-xs text-gray-500">Date début</dt>
                        <dd class="text-sm font-medium text-gray-800"><?= formatDateTime($event['start_datetime']) ?></dd>
                    </div>
                    <div>
                        <dt class="text-xs text-gray-500">Date fin</dt>
                        <dd class="text-sm font-medium text-gray-800"><?= formatDateTime($event['end_datetime']) ?></dd>
                    </div>
                    <div>
                        <dt class="text-xs text-gray-500">Lieu</dt>
                        <dd class="text-sm font-medium text-gray-800"><?= e($event['location']) ?: '—' ?></dd>
                    </div>
                    <div>
                        <dt class="text-xs text-gray-500">Responsable</dt>
                        <dd class="text-sm font-medium text-gray-800"><?= e($event['responsible_name'] ?? '—') ?></dd>
                    </div>
                    <div>
                        <dt class="text-xs text-gray-500">Budget</dt>
                        <dd class="text-sm font-medium text-gray-800"><?= $event['budget'] ? formatCurrency((float)$event['budget']) : '—' ?></dd>
                    </div>
                    <div>
                        <dt class="text-xs text-gray-500">Dépenses</dt>
                        <dd class="text-sm font-medium <?= ($event['spent'] ?? 0) > ($event['budget'] ?? 0) ? 'text-red-600' : 'text-gray-800' ?>">
                            <?= !empty($event['spent']) ? formatCurrency((float)$event['spent']) : '—' ?>
                        </dd>
                    </div>
                    <div>
                        <dt class="text-xs text-gray-500">Participants</dt>
                        <dd class="text-sm font-medium text-gray-800">
                            <?= e($event['participant_count'] ?? count($participants)) ?>
                            <?= $event['max_participants'] ? '/ ' . e($event['max_participants']) . ' max' : '' ?>
                        </dd>
                    </div>
                    <div>
                        <dt class="text-xs text-gray-500">Créé le</dt>
                        <dd class="text-sm text-gray-500"><?= formatDate($event['created_at']) ?></dd>
                    </div>
                </dl>
                <?php if (!empty($event['description'])): ?>
                <div class="mt-5 pt-4 border-t border-gray-100">
                    <h5 class="text-xs font-semibold text-gray-500 uppercase mb-2">Description</h5>
                    <p class="text-sm text-gray-700 whitespace-pre-wrap"><?= e($event['description']) ?></p>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Sidebar : Participants -->
        <div class="space-y-6">
            <!-- Ajouter un participant -->
            <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-5">
                <h4 class="text-sm font-semibold text-gray-500 uppercase tracking-wider mb-4">Ajouter un participant</h4>
                <form action="/events/<?= e($event['id']) ?>/participants/add" method="POST" class="space-y-3">
                    <?= csrfField() ?>
                    <div>
                        <input type="text" name="name" placeholder="Nom" required
                            class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-primary focus:border-primary outline-none">
                    </div>
                    <div>
                        <input type="email" name="email" placeholder="Email"
                            class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-primary focus:border-primary outline-none">
                    </div>
                    <div>
                        <input type="text" name="phone" placeholder="Téléphone"
                            class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-primary focus:border-primary outline-none">
                    </div>
                    <button type="submit"
                        class="w-full px-4 py-2 bg-primary text-white text-sm rounded-lg hover:bg-blue-700 transition">
                        <i class="fas fa-plus mr-2"></i> Ajouter
                    </button>
                </form>
            </div>

            <!-- Liste des participants -->
            <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-5">
                <h4 class="text-sm font-semibold text-gray-500 uppercase tracking-wider mb-4">
                    Participants (<?= count($participants) ?>)
                </h4>
                <?php if (empty($participants)): ?>
                <p class="text-sm text-gray-400 text-center py-4">Aucun participant pour le moment.</p>
                <?php else: ?>
                <ul class="divide-y divide-gray-100">
                    <?php foreach ($participants as $p): ?>
                    <li class="py-3 flex items-center justify-between">
                        <div class="min-w-0">
                            <p class="text-sm font-medium text-gray-800 truncate"><?= e($p['name']) ?></p>
                            <?php if (!empty($p['email'])): ?>
                            <p class="text-xs text-gray-500 truncate"><?= e($p['email']) ?></p>
                            <?php endif; ?>
                        </div>
                        <form action="/events/<?= e($event['id']) ?>/participants/<?= e($p['id']) ?>/remove" method="POST" class="ml-2 flex-shrink-0"
                            onsubmit="return confirm('Retirer ce participant ?')">
                            <?= csrfField() ?>
                            <button class="text-gray-300 hover:text-red-500 transition" title="Retirer">
                                <i class="fas fa-times-circle"></i>
                            </button>
                        </form>
                    </li>
                    <?php endforeach; ?>
                </ul>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
