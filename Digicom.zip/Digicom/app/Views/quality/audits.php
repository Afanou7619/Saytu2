<div class="max-w-6xl mx-auto">
    <div class="mb-6 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
            <h3 class="text-xl font-semibold text-gray-800">Audits qualité</h3>
            <p class="text-sm text-gray-500 mt-1"><?= count($audits) ?> audit(s)</p>
        </div>
        <a href="/quality/audits/create" class="inline-flex items-center px-4 py-2.5 bg-primary text-white text-sm font-medium rounded-lg hover:bg-blue-700 transition">
            <i class="fas fa-plus mr-2"></i> Nouvel audit
        </a>
    </div>

    <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
        <?php if (empty($audits)): ?>
        <div class="p-12 text-center text-gray-400">
            <i class="fas fa-clipboard-check text-4xl mb-3"></i>
            <p class="text-sm">Aucun audit qualité pour le moment.</p>
        </div>
        <?php else: ?>
        <div class="overflow-x-auto">
            <table class="w-full text-sm">
                <thead>
                    <tr class="bg-gray-50 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">
                        <th class="px-6 py-3">Titre</th>
                        <th class="px-6 py-3">Date</th>
                        <th class="px-6 py-3">Auditeur</th>
                        <th class="px-6 py-3">Statut</th>
                        <th class="px-6 py-3">Score</th>
                        <th class="px-6 py-3 w-16"></th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-100">
                    <?php foreach ($audits as $audit): ?>
                    <tr class="hover:bg-gray-50 transition">
                        <td class="px-6 py-4">
                            <a href="/quality/audits/<?= e($audit['id']) ?>" class="font-medium text-gray-800 hover:text-primary transition">
                                <?= e($audit['title']) ?>
                            </a>
                        </td>
                        <td class="px-6 py-4 text-gray-500"><?= formatDate($audit['audit_date'] ?? $audit['date']) ?></td>
                        <td class="px-6 py-4 text-gray-600"><?= e($audit['auditor_name'] ?? '—') ?></td>
                        <td class="px-6 py-4"><?= statusBadge($audit['status']) ?></td>
                        <td class="px-6 py-4">
                            <?php if (isset($audit['score'])): ?>
                            <span class="font-semibold <?= $audit['score'] >= 80 ? 'text-green-600' : ($audit['score'] >= 50 ? 'text-yellow-600' : 'text-red-600') ?>">
                                <?= e($audit['score']) ?>%
                            </span>
                            <?php else: ?>
                            <span class="text-gray-300">—</span>
                            <?php endif; ?>
                        </td>
                        <td class="px-6 py-4">
                            <a href="/quality/audits/<?= e($audit['id']) ?>" class="text-gray-400 hover:text-primary">
                                <i class="fas fa-chevron-right"></i>
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>
    </div>
</div>
