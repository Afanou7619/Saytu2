<?php
$avgRating = $avgRating ?? 0;
$surveyCount = count($surveys ?? []);
?>

<div class="max-w-6xl mx-auto">
    <div class="mb-6">
        <h3 class="text-xl font-semibold text-gray-800">Satisfaction client</h3>
        <p class="text-sm text-gray-500 mt-1">Enquêtes de satisfaction</p>
    </div>

    <!-- Note moyenne -->
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div class="md:col-span-1 bg-white rounded-xl shadow-sm border border-gray-200 p-6 text-center">
            <p class="text-sm font-medium text-gray-500 uppercase tracking-wider mb-2">Note moyenne</p>
            <p class="text-5xl font-bold text-gray-800 mb-3"><?= number_format((float)$avgRating, 1) ?></p>
            <div class="flex items-center justify-center gap-1 text-2xl text-yellow-400">
                <?php for ($i = 1; $i <= 5; $i++): ?>
                <i class="fas <?= $i <= round($avgRating) ? 'fa-star' : 'fa-star text-gray-200' ?>"></i>
                <?php endfor; ?>
            </div>
            <p class="text-xs text-gray-400 mt-2">Sur <?= $surveyCount ?> enquête(s)</p>
        </div>

        <!-- Distribution -->
        <div class="md:col-span-2 bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <h4 class="text-sm font-semibold text-gray-500 uppercase tracking-wider mb-4">Distribution des notes</h4>
            <?php
            $distribution = $distribution ?? [];
            $maxCount = !empty($distribution) ? max($distribution ?: [0]) : 1;
            ?>
            <div class="space-y-3">
                <?php for ($star = 5; $star >= 1; $star--): ?>
                <?php $count = $distribution[$star] ?? 0; $pct = $maxCount > 0 ? ($count / $maxCount) * 100 : 0; ?>
                <div class="flex items-center gap-3">
                    <span class="text-sm text-gray-600 w-6 text-right"><?= $star ?></span>
                    <i class="fas fa-star text-yellow-400 text-sm w-4"></i>
                    <div class="flex-1 bg-gray-100 rounded-full h-3 overflow-hidden">
                        <div class="bg-yellow-400 h-3 rounded-full" style="width: <?= $pct ?>%"></div>
                    </div>
                    <span class="text-xs text-gray-500 w-8"><?= $count ?></span>
                </div>
                <?php endfor; ?>
            </div>
        </div>
    </div>

    <!-- Tableau des enquêtes -->
    <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden mb-6">
        <div class="px-6 py-4 border-b border-gray-100 flex items-center justify-between">
            <h4 class="text-sm font-semibold text-gray-500 uppercase tracking-wider">Enquêtes récentes</h4>
            <a href="/quality/satisfaction/create" class="text-xs text-primary hover:underline">
                <i class="fas fa-plus mr-1"></i> Nouvelle enquête
            </a>
        </div>
        <?php if (empty($surveys)): ?>
        <div class="p-12 text-center text-gray-400">
            <i class="fas fa-star text-3xl mb-3"></i>
            <p class="text-sm">Aucune enquête de satisfaction pour le moment.</p>
        </div>
        <?php else: ?>
        <div class="overflow-x-auto">
            <table class="w-full text-sm">
                <thead>
                    <tr class="bg-gray-50 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">
                        <th class="px-6 py-3">Client</th>
                        <th class="px-6 py-3">Note</th>
                        <th class="px-6 py-3">Feedback</th>
                        <th class="px-6 py-3">Date</th>
                        <th class="px-6 py-3 w-16"></th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-100">
                    <?php foreach ($surveys as $survey): ?>
                    <tr class="hover:bg-gray-50 transition">
                        <td class="px-6 py-4 font-medium text-gray-800"><?= e($survey['client_name'] ?? $survey['client'] ?? '—') ?></td>
                        <td class="px-6 py-4">
                            <div class="flex items-center gap-1 text-yellow-400 text-sm">
                                <?php for ($i = 1; $i <= 5; $i++): ?>
                                <i class="fas <?= $i <= ($survey['rating'] ?? 0) ? 'fa-star' : 'fa-star text-gray-200' ?>"></i>
                                <?php endfor; ?>
                            </div>
                        </td>
                        <td class="px-6 py-4 text-gray-600 max-w-xs truncate"><?= e($survey['feedback'] ?? '—') ?></td>
                        <td class="px-6 py-4 text-gray-500"><?= formatDate($survey['created_at']) ?></td>
                        <td class="px-6 py-4">
                            <a href="/quality/satisfaction/<?= e($survey['id']) ?>" class="text-gray-400 hover:text-primary">
                                <i class="fas fa-chevron-right"></i>
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>
    </div>
</div>
