<div class="max-w-6xl mx-auto">
    <div class="mb-6">
        <h3 class="text-xl font-semibold text-gray-800">Qualité</h3>
        <p class="text-sm text-gray-500 mt-1">Tableau de bord qualité</p>
    </div>

    <!-- KPI Cards -->
    <div class="grid grid-cols-1 sm:grid-cols-3 gap-6 mb-8">
        <!-- NC ouvertes -->
        <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div class="flex items-center justify-between mb-3">
                <span class="text-sm font-medium text-gray-500">NC ouvertes</span>
                <span class="w-10 h-10 bg-red-50 text-red-600 rounded-lg flex items-center justify-center">
                    <i class="fas fa-exclamation-triangle"></i>
                </span>
            </div>
            <p class="text-3xl font-bold text-gray-800"><?= (int)($openNcCount ?? 0) ?></p>
            <a href="/quality/non-conformities" class="inline-block mt-2 text-xs text-primary hover:underline">Voir les NC &rarr;</a>
        </div>

        <!-- Audits actifs -->
        <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div class="flex items-center justify-between mb-3">
                <span class="text-sm font-medium text-gray-500">Audits actifs</span>
                <span class="w-10 h-10 bg-blue-50 text-blue-600 rounded-lg flex items-center justify-center">
                    <i class="fas fa-clipboard-check"></i>
                </span>
            </div>
            <p class="text-3xl font-bold text-gray-800"><?= (int)($activeAuditsCount ?? 0) ?></p>
            <a href="/quality/audits" class="inline-block mt-2 text-xs text-primary hover:underline">Voir les audits &rarr;</a>
        </div>

        <!-- Satisfaction moyenne -->
        <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div class="flex items-center justify-between mb-3">
                <span class="text-sm font-medium text-gray-500">Satisfaction moyenne</span>
                <span class="w-10 h-10 bg-green-50 text-green-600 rounded-lg flex items-center justify-center">
                    <i class="fas fa-smile"></i>
                </span>
            </div>
            <p class="text-3xl font-bold text-gray-800"><?= number_format((float)($avgSatisfaction ?? 0), 1) ?>/5</p>
            <div class="flex items-center mt-1 text-yellow-400 text-sm">
                <?php for ($i = 1; $i <= 5; $i++): ?>
                <i class="fas <?= $i <= round($avgSatisfaction ?? 0) ? 'fa-star' : 'fa-star text-gray-200' ?>"></i>
                <?php endfor; ?>
            </div>
        </div>
    </div>

    <!-- Liens rapides -->
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <a href="/quality/procedures"
            class="bg-white rounded-xl shadow-sm border border-gray-200 p-5 hover:border-primary hover:shadow transition group">
            <div class="flex items-center gap-3 mb-2">
                <span class="w-10 h-10 bg-indigo-50 text-indigo-600 rounded-lg flex items-center justify-center group-hover:bg-indigo-100 transition">
                    <i class="fas fa-file-alt"></i>
                </span>
                <span class="text-sm font-semibold text-gray-800">Procédures</span>
            </div>
            <p class="text-xs text-gray-500">Gérer les procédures qualité</p>
        </a>

        <a href="/quality/non-conformities"
            class="bg-white rounded-xl shadow-sm border border-gray-200 p-5 hover:border-primary hover:shadow transition group">
            <div class="flex items-center gap-3 mb-2">
                <span class="w-10 h-10 bg-red-50 text-red-600 rounded-lg flex items-center justify-center group-hover:bg-red-100 transition">
                    <i class="fas fa-exclamation-circle"></i>
                </span>
                <span class="text-sm font-semibold text-gray-800">Non-conformités</span>
            </div>
            <p class="text-xs text-gray-500">Suivre les non-conformités</p>
        </a>

        <a href="/quality/audits"
            class="bg-white rounded-xl shadow-sm border border-gray-200 p-5 hover:border-primary hover:shadow transition group">
            <div class="flex items-center gap-3 mb-2">
                <span class="w-10 h-10 bg-blue-50 text-blue-600 rounded-lg flex items-center justify-center group-hover:bg-blue-100 transition">
                    <i class="fas fa-clipboard-list"></i>
                </span>
                <span class="text-sm font-semibold text-gray-800">Audits</span>
            </div>
            <p class="text-xs text-gray-500">Gérer les audits qualité</p>
        </a>

        <a href="/quality/satisfaction"
            class="bg-white rounded-xl shadow-sm border border-gray-200 p-5 hover:border-primary hover:shadow transition group">
            <div class="flex items-center gap-3 mb-2">
                <span class="w-10 h-10 bg-green-50 text-green-600 rounded-lg flex items-center justify-center group-hover:bg-green-100 transition">
                    <i class="fas fa-star"></i>
                </span>
                <span class="text-sm font-semibold text-gray-800">Satisfaction</span>
            </div>
            <p class="text-xs text-gray-500">Enquêtes de satisfaction</p>
        </a>
    </div>
</div>
