<?php
$severityColors = [
    'minor'    => 'bg-yellow-100 text-yellow-700',
    'major'    => 'bg-orange-100 text-orange-700',
    'critical' => 'bg-red-100 text-red-700',
];
$sourceLabels = [
    'internal' => 'Interne',
    'client'   => 'Client',
    'audit'    => 'Audit',
    'other'    => 'Autre',
];
?>

<div class="max-w-6xl mx-auto">
    <div class="mb-6 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
            <h3 class="text-xl font-semibold text-gray-800">Non-conformités</h3>
            <p class="text-sm text-gray-500 mt-1"><?= count($nonConformities) ?> NC(s)</p>
        </div>
        <button onclick="document.getElementById('nc-form').classList.toggle('hidden')"
            class="inline-flex items-center px-4 py-2.5 bg-primary text-white text-sm font-medium rounded-lg hover:bg-blue-700 transition">
            <i class="fas fa-plus mr-2"></i> Nouvelle NC
        </button>
    </div>

    <!-- Formulaire création rapide -->
    <div id="nc-form" class="hidden mb-6 bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <h4 class="text-sm font-semibold text-gray-500 uppercase tracking-wider mb-4">Nouvelle non-conformité</h4>
        <form action="/quality/non-conformities/create" method="POST" class="space-y-4">
            <?= csrfField() ?>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <label for="title" class="block text-xs text-gray-500 mb-1">Titre <span class="text-red-500">*</span></label>
                    <input type="text" name="title" id="title_nc" required
                        class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-primary focus:border-primary outline-none"
                        placeholder="Titre de la NC">
                </div>
                <div>
                    <label for="severity" class="block text-xs text-gray-500 mb-1">Sévérité <span class="text-red-500">*</span></label>
                    <select name="severity" id="severity" required
                        class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-primary focus:border-primary outline-none bg-white">
                        <option value="">-- Choisir --</option>
                        <option value="minor">Mineure</option>
                        <option value="major">Majeure</option>
                        <option value="critical">Critique</option>
                    </select>
                </div>
                <div>
                    <label for="source" class="block text-xs text-gray-500 mb-1">Source <span class="text-red-500">*</span></label>
                    <select name="source" id="source" required
                        class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-primary focus:border-primary outline-none bg-white">
                        <option value="">-- Choisir --</option>
                        <option value="internal">Interne</option>
                        <option value="client">Client</option>
                        <option value="audit">Audit</option>
                        <option value="other">Autre</option>
                    </select>
                </div>
                <div>
                    <label for="description_nc" class="block text-xs text-gray-500 mb-1">Description</label>
                    <input type="text" name="description" id="description_nc"
                        class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-primary focus:border-primary outline-none"
                        placeholder="Brève description">
                </div>
            </div>
            <div class="flex justify-end gap-2 pt-2">
                <button type="button" onclick="document.getElementById('nc-form').classList.add('hidden')"
                    class="px-3 py-1.5 text-xs text-gray-600 border border-gray-300 rounded-lg hover:bg-gray-50">
                    Annuler
                </button>
                <button type="submit" class="px-4 py-1.5 bg-primary text-white text-xs rounded-lg hover:bg-blue-700 transition">
                    <i class="fas fa-save mr-1"></i> Enregistrer
                </button>
            </div>
        </form>
    </div>

    <!-- Tableau NC -->
    <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
        <?php if (empty($nonConformities)): ?>
        <div class="p-12 text-center text-gray-400">
            <i class="fas fa-check-circle text-4xl mb-3"></i>
            <p class="text-sm">Aucune non-conformité enregistrée.</p>
        </div>
        <?php else: ?>
        <div class="overflow-x-auto">
            <table class="w-full text-sm">
                <thead>
                    <tr class="bg-gray-50 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">
                        <th class="px-6 py-3">Référence</th>
                        <th class="px-6 py-3">Titre</th>
                        <th class="px-6 py-3">Sévérité</th>
                        <th class="px-6 py-3">Source</th>
                        <th class="px-6 py-3">Statut</th>
                        <th class="px-6 py-3">Signalé par</th>
                        <th class="px-6 py-3 w-16"></th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-100">
                    <?php foreach ($nonConformities as $nc): ?>
                    <tr class="hover:bg-gray-50 transition">
                        <td class="px-6 py-4 font-mono text-xs text-gray-500"><?= e($nc['reference']) ?></td>
                        <td class="px-6 py-4 font-medium text-gray-800"><?= e($nc['title']) ?></td>
                        <td class="px-6 py-4">
                            <span class="px-2 py-1 text-xs font-medium rounded-full <?= $severityColors[$nc['severity']] ?? 'bg-gray-100 text-gray-600' ?>">
                                <?= ucfirst($nc['severity']) ?>
                            </span>
                        </td>
                        <td class="px-6 py-4 text-gray-600"><?= $sourceLabels[$nc['source']] ?? e($nc['source']) ?></td>
                        <td class="px-6 py-4"><?= statusBadge($nc['status']) ?></td>
                        <td class="px-6 py-4 text-gray-600"><?= e($nc['reporter_name'] ?? '—') ?></td>
                        <td class="px-6 py-4">
                            <a href="/quality/non-conformities/<?= e($nc['id']) ?>" class="text-gray-400 hover:text-primary">
                                <i class="fas fa-chevron-right"></i>
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>
    </div>
</div>
