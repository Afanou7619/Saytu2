<div class="max-w-6xl mx-auto">
    <div class="mb-6 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
            <h3 class="text-xl font-semibold text-gray-800">Procédures qualité</h3>
            <p class="text-sm text-gray-500 mt-1"><?= count($procedures) ?> procédure(s)</p>
        </div>
        <a href="/quality/procedures/create" class="inline-flex items-center px-4 py-2.5 bg-primary text-white text-sm font-medium rounded-lg hover:bg-blue-700 transition">
            <i class="fas fa-plus mr-2"></i> Nouvelle procédure
        </a>
    </div>

    <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
        <?php if (empty($procedures)): ?>
        <div class="p-12 text-center text-gray-400">
            <i class="fas fa-file-alt text-4xl mb-3"></i>
            <p class="text-sm">Aucune procédure qualité pour le moment.</p>
        </div>
        <?php else: ?>
        <div class="overflow-x-auto">
            <table class="w-full text-sm">
                <thead>
                    <tr class="bg-gray-50 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">
                        <th class="px-6 py-3">Titre</th>
                        <th class="px-6 py-3">Référence</th>
                        <th class="px-6 py-3">Version</th>
                        <th class="px-6 py-3">Statut</th>
                        <th class="px-6 py-3">Mise à jour</th>
                        <th class="px-6 py-3 w-16"></th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-100">
                    <?php foreach ($procedures as $procedure): ?>
                    <tr class="hover:bg-gray-50 transition">
                        <td class="px-6 py-4">
                            <a href="/documents/<?= e($procedure['id']) ?>" class="font-medium text-gray-800 hover:text-primary transition">
                                <?= e($procedure['title']) ?>
                            </a>
                        </td>
                        <td class="px-6 py-4 text-gray-500 font-mono text-xs"><?= e($procedure['reference'] ?? '—') ?></td>
                        <td class="px-6 py-4 text-gray-600"><?= e($procedure['version'] ?? '1.0') ?></td>
                        <td class="px-6 py-4"><?= statusBadge($procedure['status'] ?? 'active') ?></td>
                        <td class="px-6 py-4 text-gray-500"><?= formatDate($procedure['updated_at']) ?></td>
                        <td class="px-6 py-4">
                            <a href="/documents/<?= e($procedure['id']) ?>" class="text-gray-400 hover:text-primary">
                                <i class="fas fa-eye"></i>
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>
    </div>
</div>
