<?php
$moduleFilter = $_GET['module'] ?? '';
$userFilter = $_GET['user_id'] ?? '';
$modules = ['dashboard', 'crm', 'commercial', 'projects', 'hr', 'finance', 'academy', 'events', 'innovation', 'documents', 'stock', 'quality', 'reports', 'admin', 'auth'];
?>

<div class="max-w-7xl mx-auto">
    <div class="mb-6">
        <h3 class="text-xl font-semibold text-gray-800">Journaux d'activité</h3>
        <p class="text-sm text-gray-500 mt-1">Historique des actions dans le système</p>
    </div>

    <!-- Filtres -->
    <div class="mb-4 flex flex-wrap items-center gap-3">
        <div class="flex items-center gap-2">
            <span class="text-xs text-gray-500">Module :</span>
            <select onchange="this.form.submit()" name="module"
                class="border border-gray-300 rounded-lg px-3 py-1.5 text-xs focus:ring-2 focus:ring-primary focus:border-primary outline-none bg-white">
                <option value="">Tous</option>
                <?php foreach ($modules as $mod): ?>
                <option value="<?= $mod ?>" <?= $moduleFilter === $mod ? 'selected' : '' ?>><?= ucfirst($mod) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <?php if (!empty($usersList)): ?>
        <div class="flex items-center gap-2">
            <span class="text-xs text-gray-500">Utilisateur :</span>
            <select onchange="this.form.submit()" name="user_id"
                class="border border-gray-300 rounded-lg px-3 py-1.5 text-xs focus:ring-2 focus:ring-primary focus:border-primary outline-none bg-white">
                <option value="">Tous</option>
                <?php foreach ($usersList as $u): ?>
                <option value="<?= e($u['id']) ?>" <?= $userFilter == $u['id'] ? 'selected' : '' ?>><?= e($u['name']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <?php endif; ?>
    </div>

    <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
        <?php if (empty($logs)): ?>
        <div class="p-12 text-center text-gray-400">
            <i class="fas fa-history text-4xl mb-3"></i>
            <p class="text-sm">Aucune entrée dans le journal.</p>
        </div>
        <?php else: ?>
        <div class="overflow-x-auto">
            <table class="w-full text-sm">
                <thead>
                    <tr class="bg-gray-50 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">
                        <th class="px-6 py-3">Utilisateur</th>
                        <th class="px-6 py-3">Action</th>
                        <th class="px-6 py-3">Module</th>
                        <th class="px-6 py-3">Détails</th>
                        <th class="px-6 py-3">IP</th>
                        <th class="px-6 py-3">Date</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-100">
                    <?php foreach ($logs as $log): ?>
                    <tr class="hover:bg-gray-50 transition">
                        <td class="px-6 py-4">
                            <span class="font-medium text-gray-800"><?= e($log['user_name'] ?? $log['user'] ?? 'Système') ?></span>
                        </td>
                        <td class="px-6 py-4">
                            <span class="px-2 py-1 text-xs font-medium bg-gray-100 text-gray-700 rounded-full">
                                <?= e($log['action']) ?>
                            </span>
                        </td>
                        <td class="px-6 py-4 text-gray-600">
                            <span class="px-2 py-1 text-xs font-medium bg-blue-50 text-blue-700 rounded-full">
                                <?= e($log['module']) ?>
                            </span>
                        </td>
                        <td class="px-6 py-4 text-gray-500 max-w-xs">
                            <span class="truncate block" title="<?= e($log['details'] ?? '') ?>">
                                <?= e(truncate($log['details'] ?? '—', 60)) ?>
                            </span>
                        </td>
                        <td class="px-6 py-4 text-gray-400 font-mono text-xs"><?= e($log['ip_address'] ?? '—') ?></td>
                        <td class="px-6 py-4 text-gray-500 whitespace-nowrap"><?= formatDateTime($log['created_at']) ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <!-- Pagination -->
        <?php if (isset($totalPages) && $totalPages > 1): ?>
        <?php $currentPage = $_GET['page'] ?? 1; ?>
        <div class="px-6 py-4 border-t border-gray-100 flex items-center justify-between text-sm">
            <span class="text-gray-500">Page <?= $currentPage ?> sur <?= $totalPages ?></span>
            <div class="flex items-center gap-2">
                <?php if ($currentPage > 1): ?>
                <a href="?page=<?= $currentPage - 1 ?>&module=<?= e($moduleFilter) ?>&user_id=<?= e($userFilter) ?>"
                    class="px-3 py-1.5 text-xs border border-gray-300 rounded-lg hover:bg-gray-50">&laquo; Précédent</a>
                <?php endif; ?>
                <?php if ($currentPage < $totalPages): ?>
                <a href="?page=<?= $currentPage + 1 ?>&module=<?= e($moduleFilter) ?>&user_id=<?= e($userFilter) ?>"
                    class="px-3 py-1.5 text-xs border border-gray-300 rounded-lg hover:bg-gray-50">Suivant &raquo;</a>
                <?php endif; ?>
            </div>
        </div>
        <?php endif; ?>
        <?php endif; ?>
    </div>
</div>
