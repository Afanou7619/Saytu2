<?php
$roleFilter = $_GET['role'] ?? '';
$statusFilter = $_GET['status'] ?? '';
$roles = [
    'ceo'    => 'CEO',
    'admin'  => 'Admin',
    'manager' => 'Manager',
    'user'   => 'Utilisateur',
    'viewer' => 'Lecteur',
];
?>

<div class="max-w-7xl mx-auto">
    <div class="mb-6 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
            <h3 class="text-xl font-semibold text-gray-800">Utilisateurs</h3>
            <p class="text-sm text-gray-500 mt-1"><?= e($total ?? count($users)) ?> utilisateur(s)</p>
        </div>
        <a href="/admin/users/create" class="inline-flex items-center px-4 py-2.5 bg-primary text-white text-sm font-medium rounded-lg hover:bg-blue-700 transition">
            <i class="fas fa-plus mr-2"></i> Créer utilisateur
        </a>
    </div>

    <!-- Filtres -->
    <div class="mb-4 flex flex-wrap items-center gap-3">
        <div class="flex items-center gap-2">
            <span class="text-xs text-gray-500">Rôle :</span>
            <select onchange="window.location.search = 'role=' + this.value + '&status=<?= e($statusFilter) ?>'"
                class="border border-gray-300 rounded-lg px-3 py-1.5 text-xs focus:ring-2 focus:ring-primary focus:border-primary outline-none bg-white">
                <option value="">Tous</option>
                <?php foreach ($roles as $val => $label): ?>
                <option value="<?= $val ?>" <?= $roleFilter === $val ? 'selected' : '' ?>><?= $label ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="flex items-center gap-2">
            <span class="text-xs text-gray-500">Statut :</span>
            <select onchange="window.location.search = 'role=<?= e($roleFilter) ?>&status=' + this.value"
                class="border border-gray-300 rounded-lg px-3 py-1.5 text-xs focus:ring-2 focus:ring-primary focus:border-primary outline-none bg-white">
                <option value="">Tous</option>
                <option value="active" <?= $statusFilter === 'active' ? 'selected' : '' ?>>Actif</option>
                <option value="inactive" <?= $statusFilter === 'inactive' ? 'selected' : '' ?>>Inactif</option>
                <option value="suspended" <?= $statusFilter === 'suspended' ? 'selected' : '' ?>>Suspendu</option>
            </select>
        </div>
    </div>

    <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
        <?php if (empty($users)): ?>
        <div class="p-12 text-center text-gray-400">
            <i class="fas fa-users text-4xl mb-3"></i>
            <p class="text-sm">Aucun utilisateur trouvé.</p>
        </div>
        <?php else: ?>
        <div class="overflow-x-auto">
            <table class="w-full text-sm">
                <thead>
                    <tr class="bg-gray-50 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">
                        <th class="px-6 py-3">Nom</th>
                        <th class="px-6 py-3">Email</th>
                        <th class="px-6 py-3">Rôle</th>
                        <th class="px-6 py-3">Statut</th>
                        <th class="px-6 py-3">Créé le</th>
                        <th class="px-6 py-3 w-32">Actions</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-100">
                    <?php foreach ($users as $user): ?>
                    <tr class="hover:bg-gray-50 transition">
                        <td class="px-6 py-4 font-medium text-gray-800">
                            <div class="flex items-center gap-2">
                                <div class="w-7 h-7 bg-primary text-white rounded-full flex items-center justify-center text-xs font-bold">
                                    <?= e(mb_substr($user['name'] ?? '?', 0, 1)) ?>
                                </div>
                                <?= e($user['name']) ?>
                            </div>
                        </td>
                        <td class="px-6 py-4 text-gray-600"><?= e($user['email']) ?></td>
                        <td class="px-6 py-4">
                            <span class="px-2 py-1 text-xs font-medium bg-indigo-50 text-indigo-700 rounded-full">
                                <?= $roles[$user['role']] ?? e($user['role']) ?>
                            </span>
                        </td>
                        <td class="px-6 py-4"><?= statusBadge($user['status']) ?></td>
                        <td class="px-6 py-4 text-gray-500"><?= formatDate($user['created_at']) ?></td>
                        <td class="px-6 py-4">
                            <div class="flex items-center gap-2">
                                <a href="/admin/users/<?= e($user['id']) ?>/edit"
                                    class="text-gray-400 hover:text-primary transition" title="Modifier">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <?php if ($user['status'] === 'suspended' || $user['status'] === 'inactive'): ?>
                                <form action="/admin/users/<?= e($user['id']) ?>/activate" method="POST" class="inline">
                                    <?= csrfField() ?>
                                    <button title="Activer" class="text-gray-400 hover:text-green-600 transition">
                                        <i class="fas fa-check-circle"></i>
                                    </button>
                                </form>
                                <?php else: ?>
                                <form action="/admin/users/<?= e($user['id']) ?>/suspend" method="POST" class="inline"
                                    onsubmit="return confirm('Suspendre cet utilisateur ?')">
                                    <?= csrfField() ?>
                                    <button title="Suspendre" class="text-gray-400 hover:text-red-600 transition">
                                        <i class="fas fa-ban"></i>
                                    </button>
                                </form>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <!-- Pagination -->
        <?php if (isset($totalPages) && $totalPages > 1): ?>
        <?php $currentPage = $_GET['page'] ?? 1; ?>
        <div class="px-6 py-4 border-t border-gray-100 flex items-center justify-between text-sm">
            <span class="text-gray-500">
                Page <?= $currentPage ?> sur <?= $totalPages ?>
            </span>
            <div class="flex items-center gap-2">
                <?php if ($currentPage > 1): ?>
                <a href="?page=<?= $currentPage - 1 ?>&role=<?= e($roleFilter) ?>&status=<?= e($statusFilter) ?>"
                    class="px-3 py-1.5 text-xs border border-gray-300 rounded-lg hover:bg-gray-50">&laquo; Précédent</a>
                <?php endif; ?>
                <?php if ($currentPage < $totalPages): ?>
                <a href="?page=<?= $currentPage + 1 ?>&role=<?= e($roleFilter) ?>&status=<?= e($statusFilter) ?>"
                    class="px-3 py-1.5 text-xs border border-gray-300 rounded-lg hover:bg-gray-50">Suivant &raquo;</a>
                <?php endif; ?>
            </div>
        </div>
        <?php endif; ?>
        <?php endif; ?>
    </div>
</div>
