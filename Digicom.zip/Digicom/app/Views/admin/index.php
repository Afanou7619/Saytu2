<div class="space-y-6">
    <div class="flex items-center justify-between">
        <h1 class="text-xl font-bold text-gray-900">Administration</h1>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
        <a href="/admin/users" class="bg-white rounded-xl shadow-sm p-6 border border-gray-100 hover:border-blue-200 transition">
            <div class="flex items-center gap-4">
                <div class="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                    <i class="fas fa-users text-blue-600 text-xl"></i>
                </div>
                <div>
                    <p class="text-sm text-gray-500">Utilisateurs</p>
                    <p class="text-xl font-bold text-gray-900"><?= $totalUsers ?? 0 ?></p>
                    <p class="text-xs text-green-600"><?= $activeUsers ?? 0 ?> actifs</p>
                </div>
            </div>
        </a>

        <a href="/admin/logs" class="bg-white rounded-xl shadow-sm p-6 border border-gray-100 hover:border-blue-200 transition">
            <div class="flex items-center gap-4">
                <div class="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                    <i class="fas fa-history text-purple-600 text-xl"></i>
                </div>
                <div>
                    <p class="text-sm text-gray-500">Journaux</p>
                    <p class="text-xl font-bold text-gray-900">Activité</p>
                    <p class="text-xs text-gray-500">Logs système</p>
                </div>
            </div>
        </a>

        <a href="/admin/settings" class="bg-white rounded-xl shadow-sm p-6 border border-gray-100 hover:border-blue-200 transition">
            <div class="flex items-center gap-4">
                <div class="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
                    <i class="fas fa-cog text-orange-600 text-xl"></i>
                </div>
                <div>
                    <p class="text-sm text-gray-500">Paramètres</p>
                    <p class="text-xl font-bold text-gray-900">Configuration</p>
                    <p class="text-xs text-gray-500">Générale & backups</p>
                </div>
            </div>
        </a>
    </div>

    <?php if (!empty($recentLogs)): ?>
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <div class="px-6 py-4 border-b border-gray-100">
            <h3 class="text-sm font-semibold text-gray-700">Activité récente</h3>
        </div>
        <div class="divide-y divide-gray-100">
            <?php foreach ($recentLogs as $log): ?>
            <div class="px-6 py-3 flex items-center justify-between text-sm">
                <div>
                    <span class="font-medium text-gray-700"><?= e($log['user_name'] ?? 'Système') ?></span>
                    <span class="text-gray-500 ml-2"><?= e($log['action']) ?></span>
                    <span class="text-gray-400 text-xs ml-2">[<?= e($log['module']) ?>]</span>
                </div>
                <span class="text-xs text-gray-400"><?= timeAgo($log['created_at']) ?></span>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
    <?php endif; ?>
</div>
