<?php
$isEdit = isset($user) && !empty($user['id']);
$formAction = $isEdit ? '/admin/users/' . $user['id'] . '/edit' : '/admin/users/create';
$roles = [
    'ceo'     => 'CEO',
    'admin'   => 'Admin',
    'manager' => 'Manager',
    'user'    => 'Utilisateur',
    'viewer'  => 'Lecteur',
];
?>

<div class="max-w-2xl mx-auto">
    <div class="mb-6 flex items-center justify-between">
        <div>
            <h3 class="text-xl font-semibold text-gray-800"><?= $isEdit ? 'Modifier l\'utilisateur' : 'Créer un utilisateur' ?></h3>
            <p class="text-sm text-gray-500 mt-1">
                <?= $isEdit ? e($user['name'] . ' — ' . $user['email']) : 'Ajouter un nouvel utilisateur au système' ?>
            </p>
        </div>
        <a href="/admin/users" class="text-sm text-primary hover:underline">
            <i class="fas fa-arrow-left mr-1"></i> Retour
        </a>
    </div>

    <form action="<?= $formAction ?>" method="POST" class="bg-white rounded-xl shadow-sm border border-gray-200 p-6 space-y-6">
        <?= csrfField() ?>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <!-- Nom -->
            <div class="md:col-span-2">
                <label for="name" class="block text-sm font-medium text-gray-700 mb-1">Nom complet <span class="text-red-500">*</span></label>
                <input type="text" name="name" id="name"
                    value="<?= e(old('name', $isEdit ? $user['name'] : '')) ?>" required
                    class="w-full border border-gray-300 rounded-lg px-4 py-2.5 text-sm focus:ring-2 focus:ring-primary focus:border-primary outline-none"
                    placeholder="Nom complet">
            </div>

            <!-- Email -->
            <div>
                <label for="email" class="block text-sm font-medium text-gray-700 mb-1">Email <span class="text-red-500">*</span></label>
                <input type="email" name="email" id="email"
                    value="<?= e(old('email', $isEdit ? $user['email'] : '')) ?>" required
                    class="w-full border border-gray-300 rounded-lg px-4 py-2.5 text-sm focus:ring-2 focus:ring-primary focus:border-primary outline-none"
                    placeholder="email@exemple.com">
            </div>

            <!-- Téléphone -->
            <div>
                <label for="phone" class="block text-sm font-medium text-gray-700 mb-1">Téléphone</label>
                <input type="text" name="phone" id="phone"
                    value="<?= e(old('phone', $isEdit ? ($user['phone'] ?? '') : '')) ?>"
                    class="w-full border border-gray-300 rounded-lg px-4 py-2.5 text-sm focus:ring-2 focus:ring-primary focus:border-primary outline-none"
                    placeholder="+221 XX XXX XX XX">
            </div>

            <!-- Rôle -->
            <div>
                <label for="role" class="block text-sm font-medium text-gray-700 mb-1">Rôle <span class="text-red-500">*</span></label>
                <select name="role" id="role" required
                    class="w-full border border-gray-300 rounded-lg px-4 py-2.5 text-sm focus:ring-2 focus:ring-primary focus:border-primary outline-none bg-white">
                    <option value="">-- Sélectionner --</option>
                    <?php foreach ($roles as $val => $label): ?>
                    <option value="<?= $val ?>" <?= (old('role', $isEdit ? $user['role'] : '')) === $val ? 'selected' : '' ?>>
                        <?= $label ?>
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <!-- Statut (édition seulement) -->
            <?php if ($isEdit): ?>
            <div>
                <label for="status" class="block text-sm font-medium text-gray-700 mb-1">Statut</label>
                <select name="status" id="status"
                    class="w-full border border-gray-300 rounded-lg px-4 py-2.5 text-sm focus:ring-2 focus:ring-primary focus:border-primary outline-none bg-white">
                    <option value="active" <?= (old('status', $user['status'] ?? 'active')) === 'active' ? 'selected' : '' ?>>Actif</option>
                    <option value="inactive" <?= (old('status', $user['status'] ?? '')) === 'inactive' ? 'selected' : '' ?>>Inactif</option>
                    <option value="suspended" <?= (old('status', $user['status'] ?? '')) === 'suspended' ? 'selected' : '' ?>>Suspendu</option>
                </select>
            </div>
            <?php endif; ?>
        </div>

        <!-- Mot de passe -->
        <div class="border-t border-gray-100 pt-5">
            <h4 class="text-sm font-semibold text-gray-700 mb-3">
                <?= $isEdit ? 'Changer le mot de passe (laisser vide pour ne pas modifier)' : 'Mot de passe' ?>
            </h4>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label for="password" class="block text-sm font-medium text-gray-700 mb-1">
                        Mot de passe <?= $isEdit ? '' : '<span class="text-red-500">*</span>' ?>
                    </label>
                    <input type="password" name="password" id="password"
                        <?= $isEdit ? '' : 'required' ?>
                        class="w-full border border-gray-300 rounded-lg px-4 py-2.5 text-sm focus:ring-2 focus:ring-primary focus:border-primary outline-none"
                        placeholder="Minimum 8 caractères">
                </div>
                <div>
                    <label for="password_confirmation" class="block text-sm font-medium text-gray-700 mb-1">
                        Confirmation <?= $isEdit ? '' : '<span class="text-red-500">*</span>' ?>
                    </label>
                    <input type="password" name="password_confirmation" id="password_confirmation"
                        <?= $isEdit ? '' : 'required' ?>
                        class="w-full border border-gray-300 rounded-lg px-4 py-2.5 text-sm focus:ring-2 focus:ring-primary focus:border-primary outline-none"
                        placeholder="Confirmer le mot de passe">
                </div>
            </div>
        </div>

        <!-- Changer mot de passe au prochain login -->
        <div class="flex items-center gap-3">
            <input type="checkbox" name="must_change_password" id="must_change_password" value="1"
                <?= old('must_change_password', $isEdit ? ($user['must_change_password'] ?? false) : false) ? 'checked' : '' ?>
                class="w-4 h-4 text-primary border-gray-300 rounded focus:ring-primary">
            <label for="must_change_password" class="text-sm text-gray-700">
                L'utilisateur doit changer son mot de passe à la prochaine connexion
            </label>
        </div>

        <div class="flex items-center justify-end gap-3 pt-4 border-t border-gray-100">
            <a href="/admin/users" class="px-4 py-2.5 text-sm text-gray-600 hover:text-gray-800 border border-gray-300 rounded-lg hover:bg-gray-50 transition">
                Annuler
            </a>
            <button type="submit" class="px-6 py-2.5 bg-primary text-white text-sm font-medium rounded-lg hover:bg-blue-700 transition">
                <i class="fas fa-save mr-2"></i> <?= $isEdit ? 'Enregistrer' : 'Créer l\'utilisateur' ?>
            </button>
        </div>
    </form>
</div>
