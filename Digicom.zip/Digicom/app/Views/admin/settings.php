<div class="max-w-4xl mx-auto">
    <div class="mb-6">
        <h3 class="text-xl font-semibold text-gray-800">Paramètres</h3>
        <p class="text-sm text-gray-500 mt-1">Configuration du système</p>
    </div>

    <!-- Paramètres généraux -->
    <form action="/admin/settings" method="POST" class="bg-white rounded-xl shadow-sm border border-gray-200 p-6 space-y-6 mb-8">
        <?= csrfField() ?>

        <h4 class="text-sm font-semibold text-gray-500 uppercase tracking-wider">Général</h4>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
                <label for="APP_NAME" class="block text-sm font-medium text-gray-700 mb-1">Nom de l'application</label>
                <input type="text" name="APP_NAME" id="APP_NAME"
                    value="<?= e(old('APP_NAME', $settings['APP_NAME'] ?? 'DIGI ERP')) ?>"
                    class="w-full border border-gray-300 rounded-lg px-4 py-2.5 text-sm focus:ring-2 focus:ring-primary focus:border-primary outline-none">
            </div>
            <div>
                <label for="APP_URL" class="block text-sm font-medium text-gray-700 mb-1">URL de l'application</label>
                <input type="url" name="APP_URL" id="APP_URL"
                    value="<?= e(old('APP_URL', $settings['APP_URL'] ?? '')) ?>"
                    class="w-full border border-gray-300 rounded-lg px-4 py-2.5 text-sm focus:ring-2 focus:ring-primary focus:border-primary outline-none"
                    placeholder="https://exemple.com">
            </div>
        </div>

        <!-- Email -->
        <div class="border-t border-gray-100 pt-5">
            <h4 class="text-sm font-semibold text-gray-500 uppercase tracking-wider mb-4">Configuration Email</h4>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label for="MAIL_HOST" class="block text-sm font-medium text-gray-700 mb-1">Serveur SMTP</label>
                    <input type="text" name="MAIL_HOST" id="MAIL_HOST"
                        value="<?= e(old('MAIL_HOST', $settings['MAIL_HOST'] ?? '')) ?>"
                        class="w-full border border-gray-300 rounded-lg px-4 py-2.5 text-sm focus:ring-2 focus:ring-primary focus:border-primary outline-none"
                        placeholder="smtp.exemple.com">
                </div>
                <div>
                    <label for="MAIL_PORT" class="block text-sm font-medium text-gray-700 mb-1">Port SMTP</label>
                    <input type="number" name="MAIL_PORT" id="MAIL_PORT"
                        value="<?= e(old('MAIL_PORT', $settings['MAIL_PORT'] ?? '587')) ?>"
                        class="w-full border border-gray-300 rounded-lg px-4 py-2.5 text-sm focus:ring-2 focus:ring-primary focus:border-primary outline-none">
                </div>
                <div>
                    <label for="MAIL_USERNAME" class="block text-sm font-medium text-gray-700 mb-1">Nom d'utilisateur SMTP</label>
                    <input type="text" name="MAIL_USERNAME" id="MAIL_USERNAME"
                        value="<?= e(old('MAIL_USERNAME', $settings['MAIL_USERNAME'] ?? '')) ?>"
                        class="w-full border border-gray-300 rounded-lg px-4 py-2.5 text-sm focus:ring-2 focus:ring-primary focus:border-primary outline-none"
                        placeholder="user@exemple.com">
                </div>
                <div>
                    <label for="MAIL_PASSWORD" class="block text-sm font-medium text-gray-700 mb-1">Mot de passe SMTP</label>
                    <input type="password" name="MAIL_PASSWORD" id="MAIL_PASSWORD"
                        value="<?= e(old('MAIL_PASSWORD', $settings['MAIL_PASSWORD'] ?? '')) ?>"
                        class="w-full border border-gray-300 rounded-lg px-4 py-2.5 text-sm focus:ring-2 focus:ring-primary focus:border-primary outline-none"
                        placeholder="••••••••">
                </div>
                <div>
                    <label for="MAIL_ENCRYPTION" class="block text-sm font-medium text-gray-700 mb-1">Chiffrement</label>
                    <select name="MAIL_ENCRYPTION" id="MAIL_ENCRYPTION"
                        class="w-full border border-gray-300 rounded-lg px-4 py-2.5 text-sm focus:ring-2 focus:ring-primary focus:border-primary outline-none bg-white">
                        <?php $enc = old('MAIL_ENCRYPTION', $settings['MAIL_ENCRYPTION'] ?? 'tls'); ?>
                        <option value="tls" <?= $enc === 'tls' ? 'selected' : '' ?>>TLS</option>
                        <option value="ssl" <?= $enc === 'ssl' ? 'selected' : '' ?>>SSL</option>
                        <option value="" <?= $enc === '' ? 'selected' : '' ?>>Aucun</option>
                    </select>
                </div>
                <div>
                    <label for="MAIL_FROM_NAME" class="block text-sm font-medium text-gray-700 mb-1">Nom d'expéditeur</label>
                    <input type="text" name="MAIL_FROM_NAME" id="MAIL_FROM_NAME"
                        value="<?= e(old('MAIL_FROM_NAME', $settings['MAIL_FROM_NAME'] ?? 'DIGI ERP')) ?>"
                        class="w-full border border-gray-300 rounded-lg px-4 py-2.5 text-sm focus:ring-2 focus:ring-primary focus:border-primary outline-none">
                </div>
                <div class="md:col-span-2">
                    <label for="MAIL_FROM_ADDRESS" class="block text-sm font-medium text-gray-700 mb-1">Adresse d'expéditeur</label>
                    <input type="email" name="MAIL_FROM_ADDRESS" id="MAIL_FROM_ADDRESS"
                        value="<?= e(old('MAIL_FROM_ADDRESS', $settings['MAIL_FROM_ADDRESS'] ?? '')) ?>"
                        class="w-full border border-gray-300 rounded-lg px-4 py-2.5 text-sm focus:ring-2 focus:ring-primary focus:border-primary outline-none"
                        placeholder="noreply@exemple.com">
                </div>
            </div>
        </div>

        <div class="flex items-center justify-end pt-4 border-t border-gray-100">
            <button type="submit" class="px-6 py-2.5 bg-primary text-white text-sm font-medium rounded-lg hover:bg-blue-700 transition">
                <i class="fas fa-save mr-2"></i> Enregistrer les paramètres
            </button>
        </div>
    </form>

    <!-- Sauvegarde -->
    <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-4">
            <div>
                <h4 class="text-sm font-semibold text-gray-500 uppercase tracking-wider">Sauvegarde de la base de données</h4>
                <p class="text-xs text-gray-400 mt-1">Créez une sauvegarde complète de la base de données</p>
            </div>
            <form action="/admin/backup" method="POST">
                <?= csrfField() ?>
                <button type="submit"
                    class="inline-flex items-center px-4 py-2.5 bg-yellow-500 text-white text-sm font-medium rounded-lg hover:bg-yellow-600 transition">
                    <i class="fas fa-database mr-2"></i> Créer sauvegarde
                </button>
            </form>
        </div>
        <div class="border-t border-gray-100 pt-4">
            <a href="/admin/backups" class="text-sm text-primary hover:underline">
                <i class="fas fa-history mr-1"></i> Voir l'historique des sauvegardes
            </a>
        </div>
    </div>
</div>
