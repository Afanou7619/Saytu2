<div class="max-w-4xl mx-auto">
    <div class="mb-6 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
            <h3 class="text-xl font-semibold text-gray-800">Sauvegardes</h3>
            <p class="text-sm text-gray-500 mt-1">Historique des sauvegardes de la base de données</p>
        </div>
        <form action="/admin/backup" method="POST">
            <?= csrfField() ?>
            <button type="submit"
                class="inline-flex items-center px-4 py-2.5 bg-primary text-white text-sm font-medium rounded-lg hover:bg-blue-700 transition">
                <i class="fas fa-plus mr-2"></i> Nouvelle sauvegarde
            </button>
        </form>
    </div>

    <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
        <?php if (empty($backups)): ?>
        <div class="p-12 text-center text-gray-400">
            <i class="fas fa-database text-4xl mb-3"></i>
            <p class="text-sm">Aucune sauvegarde disponible.</p>
            <p class="text-xs text-gray-300 mt-1">Créez votre première sauvegarde avec le bouton ci-dessus.</p>
        </div>
        <?php else: ?>
        <div class="overflow-x-auto">
            <table class="w-full text-sm">
                <thead>
                    <tr class="bg-gray-50 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">
                        <th class="px-6 py-3">Fichier</th>
                        <th class="px-6 py-3">Taille</th>
                        <th class="px-6 py-3">Date</th>
                        <th class="px-6 py-3 w-40">Actions</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-100">
                    <?php foreach ($backups as $backup): ?>
                    <tr class="hover:bg-gray-50 transition">
                        <td class="px-6 py-4">
                            <div class="flex items-center gap-2">
                                <span class="w-8 h-8 bg-yellow-50 text-yellow-600 rounded-lg flex items-center justify-center">
                                    <i class="fas fa-file-archive text-sm"></i>
                                </span>
                                <span class="font-medium text-gray-800"><?= e($backup['filename']) ?></span>
                            </div>
                        </td>
                        <td class="px-6 py-4 text-gray-600">
                            <?php
                            $size = (int)($backup['size'] ?? 0);
                            if ($size >= 1_048_576) {
                                echo number_format($size / 1_048_576, 2) . ' Mo';
                            } elseif ($size >= 1024) {
                                echo number_format($size / 1024, 0) . ' Ko';
                            } else {
                                echo $size . ' o';
                            }
                            ?>
                        </td>
                        <td class="px-6 py-4 text-gray-500"><?= formatDateTime($backup['created_at']) ?></td>
                        <td class="px-6 py-4">
                            <div class="flex items-center gap-3">
                                <a href="/admin/backups/<?= e($backup['filename']) ?>/download"
                                    class="text-primary hover:text-blue-700 text-sm font-medium transition">
                                    <i class="fas fa-download mr-1"></i> Télécharger
                                </a>
                                <form action="/admin/backups/<?= e($backup['filename']) ?>/delete" method="POST"
                                    onsubmit="return confirm('Supprimer cette sauvegarde définitivement ?')">
                                    <?= csrfField() ?>
                                    <button class="text-red-400 hover:text-red-600 transition">
                                        <i class="fas fa-trash text-sm"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>
    </div>
</div>
