<?php
/**
 * @var array $budgets Array of budget data (department, allocated, spent, remaining)
 */
?>

<div class="space-y-6">
    <!-- Header -->
    <div>
        <h1 class="text-2xl font-bold text-gray-900">Suivi budgétaire</h1>
        <p class="mt-1 text-sm text-gray-500">Gérez et suivez les budgets par département</p>
    </div>

    <!-- Budget Table -->
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Département
                        </th>
                        <th scope="col" class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Alloué
                        </th>
                        <th scope="col" class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Dépensé
                        </th>
                        <th scope="col" class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Restant
                        </th>
                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Progression
                        </th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    <?php if (!empty($budgets)): ?>
                        <?php foreach ($budgets as $budget): ?>
                            <?php
                            $allocated = floatval($budget['allocated'] ?? 0);
                            $spent     = floatval($budget['spent'] ?? 0);
                            $remaining = floatval($budget['remaining'] ?? ($allocated - $spent));
                            $percentage = $allocated > 0 ? min(($spent / $allocated) * 100, 100) : 0;

                            // Color logic
                            if ($percentage >= 90) {
                                $barColor = 'bg-red-500';
                                $textColor = 'text-red-700';
                            } elseif ($percentage >= 70) {
                                $barColor = 'bg-yellow-500';
                                $textColor = 'text-yellow-700';
                            } else {
                                $barColor = 'bg-green-500';
                                $textColor = 'text-green-700';
                            }
                            ?>
                            <tr class="hover:bg-gray-50 transition-colors">
                                <td class="whitespace-nowrap px-6 py-4 text-sm font-medium text-gray-900">
                                    <?= e($budget['department'] ?? '—') ?>
                                </td>
                                <td class="whitespace-nowrap px-6 py-4 text-sm text-right text-gray-700">
                                    <?= e(formatCurrency($allocated)) ?>
                                </td>
                                <td class="whitespace-nowrap px-6 py-4 text-sm text-right text-gray-700">
                                    <?= e(formatCurrency($spent)) ?>
                                </td>
                                <td class="whitespace-nowrap px-6 py-4 text-sm text-right font-semibold <?= $remaining < 0 ? 'text-red-600' : 'text-green-600' ?>">
                                    <?= e(formatCurrency($remaining)) ?>
                                </td>
                                <td class="px-6 py-4 text-sm min-w-[200px]">
                                    <div class="flex items-center gap-3">
                                        <div class="flex-1 h-2 bg-gray-200 rounded-full overflow-hidden">
                                            <div class="h-full rounded-full transition-all duration-500 <?= $barColor ?>"
                                                 style="width: <?= $percentage ?>%">
                                            </div>
                                        </div>
                                        <span class="text-xs font-medium <?= $textColor ?> w-10 text-right">
                                            <?= round($percentage) ?>%
                                        </span>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="5" class="px-6 py-12 text-center text-sm text-gray-500">
                                Aucun budget défini.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Add / Update Budget Form -->
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
        <h2 class="text-lg font-semibold text-gray-900 mb-4">
            <?= isset($editBudget) ? 'Modifier le budget' : 'Ajouter un budget' ?>
        </h2>

        <form action="/finance/budgets/<?= isset($editBudget) ? 'update/' . e($editBudget['id']) : 'store' ?>" method="POST" class="space-y-4">
            <?= csrfField() ?>

            <?php if (isset($editBudget)): ?>
                <input type="hidden" name="_method" value="PUT">
            <?php endif; ?>

            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <!-- Department -->
                <div>
                    <label for="department" class="block text-sm font-medium text-gray-700 mb-1">
                        Département <span class="text-red-500">*</span>
                    </label>
                    <input type="text" name="department" id="department" required
                           value="<?= e($editBudget['department'] ?? '') ?>"
                           placeholder="Nom du département"
                           class="block w-full rounded-lg border border-gray-300 px-3 py-2.5 text-sm text-gray-700 shadow-sm placeholder-gray-400 focus:border-blue-500 focus:ring-2 focus:ring-blue-100 transition-colors">
                </div>

                <!-- Allocated Amount -->
                <div>
                    <label for="allocated" class="block text-sm font-medium text-gray-700 mb-1">
                        Montant alloué <span class="text-red-500">*</span>
                    </label>
                    <div class="relative">
                        <div class="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                            <span class="text-gray-500 text-sm">DH</span>
                        </div>
                        <input type="number" name="allocated" id="allocated" required min="0" step="0.01"
                               value="<?= e($editBudget['allocated'] ?? '') ?>"
                               placeholder="0.00"
                               class="block w-full rounded-lg border border-gray-300 pl-10 pr-3 py-2.5 text-sm text-gray-700 shadow-sm placeholder-gray-400 focus:border-blue-500 focus:ring-2 focus:ring-blue-100 transition-colors">
                    </div>
                </div>
            </div>

            <div>
                <button type="submit"
                        class="inline-flex items-center gap-2 rounded-lg bg-blue-600 px-5 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-blue-700 transition-colors">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
                    </svg>
                    <?= isset($editBudget) ? 'Mettre à jour' : 'Ajouter' ?>
                </button>
            </div>
        </form>
    </div>
</div>
