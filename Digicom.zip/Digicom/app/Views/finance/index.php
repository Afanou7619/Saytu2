<div class="space-y-6">
    <div class="flex items-center justify-between">
        <h1 class="text-xl font-bold text-gray-900">Comptabilité & Finances</h1>
        <div class="flex gap-2">
            <a href="/finance/transactions/create" class="px-4 py-2 text-sm bg-blue-600 text-white rounded-lg hover:bg-blue-700">
                <i class="fas fa-plus mr-1"></i> Transaction
            </a>
        </div>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div class="bg-white rounded-xl shadow-sm p-5 border border-gray-100">
            <p class="text-sm text-gray-500">Revenus du mois</p>
            <p class="text-2xl font-bold text-green-600"><?= formatCurrency($summary['income'] ?? 0) ?></p>
        </div>
        <div class="bg-white rounded-xl shadow-sm p-5 border border-gray-100">
            <p class="text-sm text-gray-500">Dépenses du mois</p>
            <p class="text-2xl font-bold text-red-600"><?= formatCurrency($summary['expense'] ?? 0) ?></p>
        </div>
        <div class="bg-white rounded-xl shadow-sm p-5 border border-gray-100">
            <p class="text-sm text-gray-500">Solde</p>
            <p class="text-2xl font-bold <?= (($summary['income'] ?? 0) - ($summary['expense'] ?? 0)) >= 0 ? 'text-green-600' : 'text-red-600' ?>">
                <?= formatCurrency(($summary['income'] ?? 0) - ($summary['expense'] ?? 0)) ?>
            </p>
        </div>
    </div>

    <!-- Transactions récentes -->
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <div class="px-6 py-4 border-b border-gray-100">
            <h3 class="text-sm font-semibold text-gray-700">Dernières transactions</h3>
        </div>
        <table class="w-full">
            <thead class="bg-gray-50">
                <tr>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Date</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Description</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Catégorie</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Type</th>
                    <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">Montant</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-100">
                <?php foreach ($recentTransactions as $t): ?>
                <tr class="hover:bg-gray-50">
                    <td class="px-6 py-4 text-sm text-gray-500"><?= formatDate($t['transaction_date']) ?></td>
                    <td class="px-6 py-4 text-sm"><?= e($t['description']) ?></td>
                    <td class="px-6 py-4 text-sm"><?= e($t['category']) ?></td>
                    <td class="px-6 py-4"><?= statusBadge($t['type']) ?></td>
                    <td class="px-6 py-4 text-sm text-right font-medium <?= $t['type'] === 'income' ? 'text-green-600' : 'text-red-600' ?>">
                        <?= $t['type'] === 'expense' ? '-' : '+' ?><?= formatCurrency($t['amount']) ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <div class="px-6 py-3 border-t">
            <a href="/finance/transactions" class="text-sm text-blue-600 hover:underline">Voir toutes les transactions →</a>
        </div>
    </div>
</div>
