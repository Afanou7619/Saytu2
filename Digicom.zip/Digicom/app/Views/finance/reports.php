<?php
/**
 * @var array  $yearlyData Array of monthly data: month, income, expense, balance
 * @var int    $selectedYear Currently selected year
 * @var array  $availableYears Years available for selection
 */
$selectedYear = $selectedYear ?? intval(date('Y'));
$availableYears = $availableYears ?? range($selectedYear - 3, $selectedYear);
?>

<div class="space-y-6">
    <!-- Header -->
    <div>
        <h1 class="text-2xl font-bold text-gray-900">Rapports financiers</h1>
        <p class="mt-1 text-sm text-gray-500">Consultez les résumés financiers annuels</p>
    </div>

    <!-- Year Selector -->
    <div class="flex items-center gap-4">
        <label for="yearSelector" class="text-sm font-medium text-gray-700">Année :</label>
        <select id="yearSelector" name="year"
                onchange="window.location.href = '?year=' + this.value"
                class="rounded-lg border border-gray-300 px-3 py-2 text-sm text-gray-700 shadow-sm focus:border-blue-500 focus:ring-2 focus:ring-blue-100 transition-colors">
            <?php foreach ($availableYears as $year): ?>
                <option value="<?= e($year) ?>" <?= intval($year) === $selectedYear ? 'selected' : '' ?>>
                    <?= e($year) ?>
                </option>
            <?php endforeach; ?>
        </select>
    </div>

    <!-- Summary Cards -->
    <?php
    $totalIncome  = 0;
    $totalExpense = 0;
    $totalBalance = 0;
    if (!empty($yearlyData)) {
        foreach ($yearlyData as $row) {
            $totalIncome  += floatval($row['income'] ?? 0);
            $totalExpense += floatval($row['expense'] ?? 0);
        }
        $totalBalance = $totalIncome - $totalExpense;
    }
    ?>
    <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-5">
            <div class="flex items-center gap-3">
                <div class="flex h-10 w-10 items-center justify-center rounded-lg bg-green-100">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M2.25 18 9 11.25l4.306 4.306a11.95 11.95 0 0 1 5.814-5.518l2.74-1.22m0 0-5.94-2.281m5.94 2.28-2.28 5.941" />
                    </svg>
                </div>
                <div>
                    <p class="text-xs font-medium text-gray-500 uppercase">Revenus totaux</p>
                    <p class="text-xl font-bold text-green-600"><?= e(formatCurrency($totalIncome)) ?></p>
                </div>
            </div>
        </div>

        <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-5">
            <div class="flex items-center gap-3">
                <div class="flex h-10 w-10 items-center justify-center rounded-lg bg-red-100">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-red-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M2.25 6 9 12.75l4.286-4.286a11.95 11.95 0 0 1 4.306 6.43l.776 2.898m0 0 3.182-5.511m-3.182 5.51-5.511-3.181" />
                    </svg>
                </div>
                <div>
                    <p class="text-xs font-medium text-gray-500 uppercase">Dépenses totales</p>
                    <p class="text-xl font-bold text-red-600"><?= e(formatCurrency($totalExpense)) ?></p>
                </div>
            </div>
        </div>

        <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-5">
            <div class="flex items-center gap-3">
                <div class="flex h-10 w-10 items-center justify-center rounded-lg <?= $totalBalance >= 0 ? 'bg-blue-100' : 'bg-orange-100' ?>">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 <?= $totalBalance >= 0 ? 'text-blue-600' : 'text-orange-600' ?>" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M12 6v12m-3-2.818.879.659c1.171.879 3.07.879 4.242 0 1.172-.879 1.172-2.303 0-3.182C13.536 12.219 12.768 12 12 12c-.725 0-1.45-.22-2.003-.659-1.106-.879-1.106-2.303 0-3.182s2.9-.879 4.006 0l.415.33M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
                    </svg>
                </div>
                <div>
                    <p class="text-xs font-medium text-gray-500 uppercase">Solde net</p>
                    <p class="text-xl font-bold <?= $totalBalance >= 0 ? 'text-blue-600' : 'text-orange-600' ?>">
                        <?= e(formatCurrency($totalBalance)) ?>
                    </p>
                </div>
            </div>
        </div>
    </div>

    <!-- Monthly Breakdown Table -->
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <div class="px-6 py-4 border-b border-gray-100">
            <h2 class="text-lg font-semibold text-gray-900">Détail mensuel</h2>
        </div>
        <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Mois
                        </th>
                        <th scope="col" class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Revenus
                        </th>
                        <th scope="col" class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Dépenses
                        </th>
                        <th scope="col" class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Solde
                        </th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    <?php
                    $months = [
                        1 => 'Janvier', 2 => 'Février', 3 => 'Mars', 4 => 'Avril',
                        5 => 'Mai', 6 => 'Juin', 7 => 'Juillet', 8 => 'Août',
                        9 => 'Septembre', 10 => 'Octobre', 11 => 'Novembre', 12 => 'Décembre',
                    ];
                    ?>
                    <?php if (!empty($yearlyData)): ?>
                        <?php
                        // Index data by month number for consistent display
                        $dataByMonth = [];
                        foreach ($yearlyData as $row) {
                            $m = intval($row['month'] ?? 0);
                            $dataByMonth[$m] = $row;
                        }
                        ?>
                        <?php foreach ($months as $num => $name): ?>
                            <?php
                            $row         = $dataByMonth[$num] ?? null;
                            $incomeVal   = floatval($row['income'] ?? 0);
                            $expenseVal  = floatval($row['expense'] ?? 0);
                            $balanceVal  = $incomeVal - $expenseVal;
                            $hasData     = $row !== null;
                            ?>
                            <tr class="hover:bg-gray-50 transition-colors <?= !$hasData ? 'text-gray-400' : '' ?>">
                                <td class="whitespace-nowrap px-6 py-3 text-sm font-medium">
                                    <?= e($name) ?>
                                </td>
                                <td class="whitespace-nowrap px-6 py-3 text-sm text-right font-medium <?= $incomeVal > 0 ? 'text-green-600' : 'text-gray-400' ?>">
                                    <?= e(formatCurrency($incomeVal)) ?>
                                </td>
                                <td class="whitespace-nowrap px-6 py-3 text-sm text-right font-medium <?= $expenseVal > 0 ? 'text-red-600' : 'text-gray-400' ?>">
                                    <?= e(formatCurrency($expenseVal)) ?>
                                </td>
                                <td class="whitespace-nowrap px-6 py-3 text-sm text-right font-semibold <?= $balanceVal >= 0 ? 'text-blue-600' : 'text-orange-600' ?>">
                                    <?= e(formatCurrency($balanceVal)) ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="4" class="px-6 py-12 text-center text-sm text-gray-500">
                                Aucune donnée disponible pour l'année <?= e($selectedYear) ?>.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
                <tfoot class="bg-gray-50">
                    <tr>
                        <th scope="row" class="whitespace-nowrap px-6 py-3 text-left text-sm font-semibold text-gray-900">
                            Total
                        </th>
                        <td class="whitespace-nowrap px-6 py-3 text-right text-sm font-bold text-green-600">
                            <?= e(formatCurrency($totalIncome)) ?>
                        </td>
                        <td class="whitespace-nowrap px-6 py-3 text-right text-sm font-bold text-red-600">
                            <?= e(formatCurrency($totalExpense)) ?>
                        </td>
                        <td class="whitespace-nowrap px-6 py-3 text-right text-sm font-bold <?= $totalBalance >= 0 ? 'text-blue-600' : 'text-orange-600' ?>">
                            <?= e(formatCurrency($totalBalance)) ?>
                        </td>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>
</div>
