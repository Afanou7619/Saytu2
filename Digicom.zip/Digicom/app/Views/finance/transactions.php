<?php
/**
 * @var array $transactions Paginated transaction data
 * @var string $currentStatus Active status filter (all, pending, completed, cancelled)
 */
?>

<div class="space-y-6">
    <!-- Header -->
    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
            <h1 class="text-2xl font-bold text-gray-900">Transactions</h1>
            <p class="mt-1 text-sm text-gray-500">Gérez toutes les transactions financières</p>
        </div>
        <a href="/finance/transactions/create"
           class="inline-flex items-center gap-2 rounded-lg bg-blue-600 px-4 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-blue-700 transition-colors">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                <path stroke-linecap="round" stroke-linejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
            </svg>
            Nouvelle transaction
        </a>
    </div>

    <!-- Status Filter Tabs -->
    <div class="border-b border-gray-200">
        <nav class="-mb-px flex space-x-6" aria-label="Tabs">
            <?php
            $statuses = [
                'all'       => 'Toutes',
                'pending'   => 'En attente',
                'completed' => 'Complétée',
                'cancelled' => 'Annulée',
            ];
            $active = $currentStatus ?? 'all';
            ?>
            <?php foreach ($statuses as $key => $label): ?>
                <a href="?status=<?= e($key) ?>"
                   class="<?= $active === $key
                       ? 'border-blue-500 text-blue-600 font-semibold'
                       : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300' ?> whitespace-nowrap border-b-2 px-1 py-3 text-sm transition-colors">
                    <?= e($label) ?>
                </a>
            <?php endforeach; ?>
        </nav>
    </div>

    <!-- Transactions Table -->
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Date
                        </th>
                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Description
                        </th>
                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Catégorie
                        </th>
                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Type
                        </th>
                        <th scope="col" class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Montant
                        </th>
                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Statut
                        </th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    <?php if (!empty($transactions)): ?>
                        <?php foreach ($transactions as $tx): ?>
                            <tr class="hover:bg-gray-50 transition-colors">
                                <td class="whitespace-nowrap px-6 py-4 text-sm text-gray-700">
                                    <?= e(formatDate($tx['transaction_date'] ?? $tx['date'] ?? '')) ?>
                                </td>
                                <td class="px-6 py-4 text-sm text-gray-900 max-w-xs truncate">
                                    <?= e($tx['description'] ?? '') ?>
                                </td>
                                <td class="whitespace-nowrap px-6 py-4 text-sm text-gray-600">
                                    <?= e($tx['category'] ?? '—') ?>
                                </td>
                                <td class="whitespace-nowrap px-6 py-4 text-sm">
                                    <?php
                                    $type = strtolower($tx['type'] ?? '');
                                    $typeBadge = match ($type) {
                                        'income'  => 'bg-green-100 text-green-800',
                                        'expense' => 'bg-red-100 text-red-800',
                                        'transfer' => 'bg-blue-100 text-blue-800',
                                        default   => 'bg-gray-100 text-gray-700',
                                    };
                                    $typeLabel = match ($type) {
                                        'income'  => 'Revenu',
                                        'expense' => 'Dépense',
                                        'transfer' => 'Transfert',
                                        default   => ucfirst($type),
                                    };
                                    ?>
                                    <span class="inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium <?= $typeBadge ?>">
                                        <?= e($typeLabel) ?>
                                    </span>
                                </td>
                                <td class="whitespace-nowrap px-6 py-4 text-sm text-right font-semibold <?= $type === 'income' ? 'text-green-600' : ($type === 'expense' ? 'text-red-600' : 'text-gray-900') ?>">
                                    <?= e(formatCurrency($tx['amount'] ?? 0)) ?>
                                </td>
                                <td class="whitespace-nowrap px-6 py-4 text-sm">
                                    <?= statusBadge($tx['status'] ?? 'pending') ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="6" class="px-6 py-12 text-center text-sm text-gray-500">
                                <svg xmlns="http://www.w3.org/2000/svg" class="mx-auto h-10 w-10 text-gray-300 mb-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M12 6v6h4.5m4.5 0a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
                                </svg>
                                Aucune transaction trouvée.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- Pagination -->
        <?php if (isset($pager)): ?>
            <div class="border-t border-gray-200 px-6 py-3">
                <?= $pager->links() ?>
            </div>
        <?php endif; ?>
    </div>
</div>
