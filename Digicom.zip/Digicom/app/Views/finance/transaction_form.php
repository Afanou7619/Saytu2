<?php
/**
 * @var array|null $transaction Existing transaction data (for edit mode)
 * @var bool     $isEdit     Whether this is an edit form
 */
$isEdit = !empty($transaction);
$action = $isEdit ? '/finance/transactions/' . e($transaction['id']) . '/update' : '/finance/transactions/create';
?>

<div class="max-w-2xl mx-auto space-y-6">
    <!-- Header -->
    <div class="flex items-center gap-4">
        <a href="/finance/transactions"
           class="inline-flex items-center gap-1 rounded-lg p-2 text-gray-500 hover:text-gray-700 hover:bg-gray-100 transition-colors">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                <path stroke-linecap="round" stroke-linejoin="round" d="M10.5 19.5 3 12m0 0 7.5-7.5M3 12h18" />
            </svg>
        </a>
        <div>
            <h1 class="text-2xl font-bold text-gray-900">
                <?= $isEdit ? 'Modifier la transaction' : 'Nouvelle transaction' ?>
            </h1>
            <p class="mt-1 text-sm text-gray-500">
                <?= $isEdit ? 'Mettez à jour les informations de la transaction' : 'Enregistrez une nouvelle transaction financière' ?>
            </p>
        </div>
    </div>

    <!-- Form -->
    <form action="<?= e($action) ?>" method="POST" class="bg-white rounded-xl shadow-sm border border-gray-100 p-6 space-y-5">
        <?= csrfField() ?>

        <?php if ($isEdit): ?>
            <input type="hidden" name="_method" value="PUT">
        <?php endif; ?>

        <!-- Type -->
        <div>
            <label for="type" class="block text-sm font-medium text-gray-700 mb-1">
                Type <span class="text-red-500">*</span>
            </label>
            <select name="type" id="type" required
                    class="block w-full rounded-lg border border-gray-300 px-3 py-2.5 text-sm text-gray-700 shadow-sm focus:border-blue-500 focus:ring-2 focus:ring-blue-100 transition-colors">
                <option value="">— Sélectionnez un type —</option>
                <option value="income" <?= isset($transaction['type']) && $transaction['type'] === 'income' ? 'selected' : '' ?>>Revenu</option>
                <option value="expense" <?= isset($transaction['type']) && $transaction['type'] === 'expense' ? 'selected' : '' ?>>Dépense</option>
                <option value="transfer" <?= isset($transaction['type']) && $transaction['type'] === 'transfer' ? 'selected' : '' ?>>Transfert</option>
            </select>
        </div>

        <!-- Category -->
        <div>
            <label for="category" class="block text-sm font-medium text-gray-700 mb-1">
                Catégorie <span class="text-red-500">*</span>
            </label>
            <input type="text" name="category" id="category" required
                   value="<?= e($transaction['category'] ?? '') ?>"
                   placeholder="Ex: Fournitures, Honoraires, Loyer..."
                   class="block w-full rounded-lg border border-gray-300 px-3 py-2.5 text-sm text-gray-700 shadow-sm placeholder-gray-400 focus:border-blue-500 focus:ring-2 focus:ring-blue-100 transition-colors">
        </div>

        <!-- Amount -->
        <div>
            <label for="amount" class="block text-sm font-medium text-gray-700 mb-1">
                Montant <span class="text-red-500">*</span>
            </label>
            <div class="relative">
                <div class="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                    <span class="text-gray-500 text-sm">DH</span>
                </div>
                <input type="number" name="amount" id="amount" required min="0" step="0.01"
                       value="<?= e($transaction['amount'] ?? '') ?>"
                       placeholder="0.00"
                       class="block w-full rounded-lg border border-gray-300 pl-10 pr-3 py-2.5 text-sm text-gray-700 shadow-sm placeholder-gray-400 focus:border-blue-500 focus:ring-2 focus:ring-blue-100 transition-colors">
            </div>
        </div>

        <!-- Description -->
        <div>
            <label for="description" class="block text-sm font-medium text-gray-700 mb-1">
                Description
            </label>
            <textarea name="description" id="description" rows="3"
                      placeholder="Description de la transaction..."
                      class="block w-full rounded-lg border border-gray-300 px-3 py-2.5 text-sm text-gray-700 shadow-sm placeholder-gray-400 focus:border-blue-500 focus:ring-2 focus:ring-blue-100 transition-colors resize-y"><?= e($transaction['description'] ?? '') ?></textarea>
        </div>

        <!-- Reference -->
        <div>
            <label for="reference" class="block text-sm font-medium text-gray-700 mb-1">
                Référence
            </label>
            <input type="text" name="reference" id="reference"
                   value="<?= e($transaction['reference'] ?? '') ?>"
                   placeholder="Numéro de facture, référence..."
                   class="block w-full rounded-lg border border-gray-300 px-3 py-2.5 text-sm text-gray-700 shadow-sm placeholder-gray-400 focus:border-blue-500 focus:ring-2 focus:ring-blue-100 transition-colors">
        </div>

        <!-- Account -->
        <div>
            <label for="account" class="block text-sm font-medium text-gray-700 mb-1">
                Compte
            </label>
            <input type="text" name="account" id="account"
                   value="<?= e($transaction['account'] ?? '') ?>"
                   placeholder="Ex: Compte principal, Caisse..."
                   class="block w-full rounded-lg border border-gray-300 px-3 py-2.5 text-sm text-gray-700 shadow-sm placeholder-gray-400 focus:border-blue-500 focus:ring-2 focus:ring-blue-100 transition-colors">
        </div>

        <!-- Transaction Date -->
        <div>
            <label for="transaction_date" class="block text-sm font-medium text-gray-700 mb-1">
                Date de la transaction <span class="text-red-500">*</span>
            </label>
            <input type="date" name="transaction_date" id="transaction_date" required
                   value="<?= e($transaction['transaction_date'] ?? date('Y-m-d')) ?>"
                   class="block w-full rounded-lg border border-gray-300 px-3 py-2.5 text-sm text-gray-700 shadow-sm focus:border-blue-500 focus:ring-2 focus:ring-blue-100 transition-colors">
        </div>

        <!-- Actions -->
        <div class="flex items-center gap-3 pt-2">
            <button type="submit"
                    class="inline-flex items-center gap-2 rounded-lg bg-blue-600 px-5 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-blue-700 transition-colors">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                    <path stroke-linecap="round" stroke-linejoin="round" d="m4.5 12.75 6 6 9-13.5" />
                </svg>
                <?= $isEdit ? 'Mettre à jour' : 'Enregistrer' ?>
            </button>
            <a href="/finance/transactions"
               class="rounded-lg border border-gray-300 px-5 py-2.5 text-sm font-medium text-gray-700 hover:bg-gray-50 transition-colors">
                Annuler
            </a>
        </div>
    </form>
</div>
