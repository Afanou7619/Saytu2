<div class="space-y-6">
    <!-- KPIs -->
    <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        <div class="bg-white rounded-xl shadow-sm p-5 border border-gray-100">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm text-gray-500">Clients actifs</p>
                    <p class="text-2xl font-bold text-gray-900"><?= number_format($stats['clients'] ?? 0) ?></p>
                </div>
                <div class="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                    <i class="fas fa-building text-blue-600"></i>
                </div>
            </div>
        </div>

        <div class="bg-white rounded-xl shadow-sm p-5 border border-gray-100">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm text-gray-500">Projets actifs</p>
                    <p class="text-2xl font-bold text-gray-900"><?= number_format($stats['active_projects'] ?? 0) ?></p>
                </div>
                <div class="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
                    <i class="fas fa-diagram-project text-purple-600"></i>
                </div>
            </div>
        </div>

        <div class="bg-white rounded-xl shadow-sm p-5 border border-gray-100">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm text-gray-500">CA du mois</p>
                    <p class="text-2xl font-bold text-gray-900"><?= formatCurrency($stats['monthly_income'] ?? 0) ?></p>
                </div>
                <div class="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                    <i class="fas fa-coins text-green-600"></i>
                </div>
            </div>
        </div>

        <div class="bg-white rounded-xl shadow-sm p-5 border border-gray-100">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm text-gray-500">Tâches en retard</p>
                    <p class="text-2xl font-bold text-red-600"><?= number_format($stats['tasks_overdue'] ?? 0) ?></p>
                </div>
                <div class="w-10 h-10 bg-red-100 rounded-lg flex items-center justify-center">
                    <i class="fas fa-exclamation-triangle text-red-600"></i>
                </div>
            </div>
        </div>

        <div class="bg-white rounded-xl shadow-sm p-5 border border-gray-100">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm text-gray-500">Devis en attente</p>
                    <p class="text-2xl font-bold text-gray-900"><?= number_format($stats['pending_quotes'] ?? 0) ?></p>
                </div>
                <div class="w-10 h-10 bg-yellow-100 rounded-lg flex items-center justify-center">
                    <i class="fas fa-file-invoice text-yellow-600"></i>
                </div>
            </div>
        </div>

        <div class="bg-white rounded-xl shadow-sm p-5 border border-gray-100">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm text-gray-500">Factures impayées</p>
                    <p class="text-2xl font-bold <?= ($stats['overdue_invoices'] ?? 0) > 0 ? 'text-red-600' : 'text-gray-900' ?>"><?= number_format($stats['overdue_invoices'] ?? 0) ?></p>
                </div>
                <div class="w-10 h-10 bg-red-100 rounded-lg flex items-center justify-center">
                    <i class="fas fa-file-invoice-dollar text-red-600"></i>
                </div>
            </div>
        </div>

        <div class="bg-white rounded-xl shadow-sm p-5 border border-gray-100">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm text-gray-500">Congés en attente</p>
                    <p class="text-2xl font-bold text-gray-900"><?= number_format($stats['pending_leaves'] ?? 0) ?></p>
                </div>
                <div class="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center">
                    <i class="fas fa-calendar-check text-orange-600"></i>
                </div>
            </div>
        </div>

        <div class="bg-white rounded-xl shadow-sm p-5 border border-gray-100">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm text-gray-500">Solde du mois</p>
                    <p class="text-2xl font-bold <?= ($stats['monthly_balance'] ?? 0) >= 0 ? 'text-green-600' : 'text-red-600' ?>">
                        <?= formatCurrency($stats['monthly_balance'] ?? 0) ?>
                    </p>
                </div>
                <div class="w-10 h-10 bg-indigo-100 rounded-lg flex items-center justify-center">
                    <i class="fas fa-chart-line text-indigo-600"></i>
                </div>
            </div>
        </div>
    </div>

    <!-- Graphiques -->
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div class="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
            <h3 class="text-sm font-semibold text-gray-700 mb-4">Revenus & Dépenses – <?= date('Y') ?></h3>
            <canvas id="revenueChart" height="250"></canvas>
        </div>
        <div class="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
            <h3 class="text-sm font-semibold text-gray-700 mb-4">Avancement des projets</h3>
            <canvas id="projectsChart" height="250"></canvas>
        </div>
    </div>

    <!-- Tâches récentes + Actions rapides -->
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div class="lg:col-span-2 bg-white rounded-xl shadow-sm p-6 border border-gray-100">
            <div class="flex items-center justify-between mb-4">
                <h3 class="text-sm font-semibold text-gray-700">Mes tâches</h3>
                <a href="/tasks" class="text-xs text-blue-600 hover:underline">Voir tout</a>
            </div>
            <?php if (empty($recentTasks)): ?>
                <p class="text-gray-400 text-sm text-center py-4">Aucune tâche assignée</p>
            <?php else: ?>
            <div class="space-y-3">
                <?php foreach ($recentTasks as $task): ?>
                <a href="/tasks/<?= $task['id'] ?>" class="flex items-center justify-between py-2 px-3 rounded-lg hover:bg-gray-50 transition">
                    <div class="flex items-center gap-3">
                        <span class="w-2 h-2 rounded-full <?= $task['priority'] === 'urgent' ? 'bg-red-500' : ($task['priority'] === 'high' ? 'bg-orange-500' : 'bg-blue-500') ?>"></span>
                        <div>
                            <p class="text-sm font-medium text-gray-800"><?= e($task['title']) ?></p>
                            <p class="text-xs text-gray-400"><?= e($task['project_title'] ?? '') ?></p>
                        </div>
                    </div>
                    <div class="flex items-center gap-2">
                        <?= statusBadge($task['status']) ?>
                        <?php if ($task['due_date']): ?>
                        <span class="text-xs text-gray-400"><?= formatDate($task['due_date']) ?></span>
                        <?php endif; ?>
                    </div>
                </a>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
        </div>

        <div class="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
            <h3 class="text-sm font-semibold text-gray-700 mb-4">Actions rapides</h3>
            <div class="space-y-2">
                <a href="/crm/clients/create" class="flex items-center gap-3 p-3 rounded-lg bg-blue-50 text-blue-700 hover:bg-blue-100 transition text-sm">
                    <i class="fas fa-plus-circle"></i> Nouveau client
                </a>
                <a href="/commercial/quotes/create" class="flex items-center gap-3 p-3 rounded-lg bg-purple-50 text-purple-700 hover:bg-purple-100 transition text-sm">
                    <i class="fas fa-file-invoice"></i> Nouveau devis
                </a>
                <a href="/projects/create" class="flex items-center gap-3 p-3 rounded-lg bg-green-50 text-green-700 hover:bg-green-100 transition text-sm">
                    <i class="fas fa-diagram-project"></i> Nouveau projet
                </a>
                <a href="/tasks/create" class="flex items-center gap-3 p-3 rounded-lg bg-orange-50 text-orange-700 hover:bg-orange-100 transition text-sm">
                    <i class="fas fa-tasks"></i> Nouvelle tâche
                </a>
                <a href="/hr/leaves/create" class="flex items-center gap-3 p-3 rounded-lg bg-indigo-50 text-indigo-700 hover:bg-indigo-100 transition text-sm">
                    <i class="fas fa-calendar-plus"></i> Demander un congé
                </a>
            </div>
        </div>
    </div>
</div>

<!-- Charts -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Graphique Revenus/Dépenses
    const revenueData = <?= json_encode($stats['chart_revenue'] ?? []) ?>;
    const ctx1 = document.getElementById('revenueChart')?.getContext('2d');
    if (ctx1) {
        new Chart(ctx1, {
            type: 'bar',
            data: {
                labels: ['Jan','Fév','Mar','Avr','Mai','Juin','Juil','Août','Sep','Oct','Nov','Déc'].slice(0, revenueData.length),
                datasets: [
                    {
                        label: 'Revenus',
                        data: revenueData.map(d => d.income),
                        backgroundColor: '#059669',
                        borderRadius: 4,
                    },
                    {
                        label: 'Dépenses',
                        data: revenueData.map(d => d.expense),
                        backgroundColor: '#dc2626',
                        borderRadius: 4,
                    }
                ]
            },
            options: {
                responsive: true,
                plugins: { legend: { position: 'bottom' } },
                scales: { y: { beginAtZero: true } }
            }
        });
    }

    // Graphique Projets
    const projectsData = <?= json_encode($stats['chart_projects'] ?? []) ?>;
    const ctx2 = document.getElementById('projectsChart')?.getContext('2d');
    if (ctx2) {
        new Chart(ctx2, {
            type: 'bar',
            data: {
                labels: projectsData.map(p => p.title.length > 20 ? p.title.substring(0, 18) + '...' : p.title),
                datasets: [{
                    label: 'Progression (%)',
                    data: projectsData.map(p => p.progress),
                    backgroundColor: projectsData.map(p => p.progress >= 80 ? '#059669' : p.progress >= 50 ? '#d97706' : '#1a56db'),
                    borderRadius: 4,
                }]
            },
            options: {
                indexAxis: 'y',
                responsive: true,
                plugins: { legend: { display: false } },
                scales: { x: { max: 100, beginAtZero: true } }
            }
        });
    }
});
</script>
