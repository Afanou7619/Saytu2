<div class="space-y-6">
    <div class="flex items-center justify-between">
        <h1 class="text-xl font-bold text-gray-900">Innovation Lab</h1>
        <a href="/innovation/projects/create" class="px-4 py-2 text-sm bg-blue-600 text-white rounded-lg hover:bg-blue-700">
            <i class="fas fa-plus mr-1"></i> Nouveau projet
        </a>
    </div>

    <?php if (!empty($projects)): ?>
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        <?php foreach ($projects as $p): ?>
        <a href="/innovation/projects/<?= $p['id'] ?>" class="bg-white rounded-xl shadow-sm border border-gray-100 p-5 hover:shadow-md hover:border-blue-200 transition">
            <div class="flex items-start justify-between mb-3">
                <h3 class="text-sm font-semibold text-gray-800"><?= e($p['title']) ?></h3>
                <?= statusBadge($p['status']) ?>
            </div>
            <p class="text-xs text-gray-500 mb-2"><?= e($p['domain']) ?></p>
            <p class="text-sm text-gray-600 line-clamp-2"><?= e(truncate($p['description'] ?? '', 80)) ?></p>
            <?php if ($p['lead_name']): ?>
            <p class="text-xs text-gray-400 mt-3"><i class="fas fa-user mr-1"></i><?= e($p['lead_name']) ?></p>
            <?php endif; ?>
        </a>
        <?php endforeach; ?>
    </div>
    <?php else: ?>
    <div class="text-center py-12 text-gray-400">Aucun projet d'innovation pour le moment</div>
    <?php endif; ?>
</div>
