<div class="max-w-4xl mx-auto">
    <!-- En-tête -->
    <div class="mb-6 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div class="flex items-center gap-3">
            <a href="/innovation/projects" class="text-gray-400 hover:text-gray-600">
                <i class="fas fa-arrow-left"></i>
            </a>
            <div>
                <h3 class="text-xl font-semibold text-gray-800"><?= e($project['title']) ?></h3>
                <p class="text-sm text-gray-500 mt-1">
                    <?= e($project['domain']) ?: 'Domaine non spécifié' ?>
                    &middot; <?= statusBadge($project['status']) ?>
                </p>
            </div>
        </div>
        <div class="flex items-center gap-3">
            <a href="/innovation/projects/<?= e($project['id']) ?>/edit"
                class="px-4 py-2 text-sm bg-primary text-white rounded-lg hover:bg-blue-700 transition">
                <i class="fas fa-edit mr-2"></i> Modifier
            </a>
            <form action="/innovation/projects/<?= e($project['id']) ?>/delete" method="POST"
                onsubmit="return confirm('Supprimer ce projet d\'innovation ?')">
                <?= csrfField() ?>
                <button type="submit"
                    class="px-4 py-2 text-sm bg-red-50 text-red-600 border border-red-200 rounded-lg hover:bg-red-100 transition">
                    <i class="fas fa-trash mr-2"></i> Supprimer
                </button>
            </form>
        </div>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <!-- Contenu principal -->
        <div class="lg:col-span-2 space-y-6">
            <!-- Description -->
            <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                <h4 class="text-sm font-semibold text-gray-500 uppercase tracking-wider mb-4">Description</h4>
                <div class="text-sm text-gray-700 whitespace-pre-wrap leading-relaxed">
                    <?= e($project['description']) ?: '<span class="text-gray-400 italic">Aucune description</span>' ?>
                </div>
            </div>

            <!-- Documentation -->
            <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                <h4 class="text-sm font-semibold text-gray-500 uppercase tracking-wider mb-4">Documentation</h4>
                <?php if (!empty($project['documentation'])): ?>
                <div class="text-sm text-gray-700 whitespace-pre-wrap leading-relaxed">
                    <?= nl2br(e($project['documentation'])) ?>
                </div>
                <?php else: ?>
                <p class="text-sm text-gray-400 italic">Aucune documentation ajoutée pour le moment.</p>
                <?php endif; ?>
            </div>
        </div>

        <!-- Sidebar -->
        <div class="space-y-6">
            <!-- Infos -->
            <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-5">
                <h4 class="text-sm font-semibold text-gray-500 uppercase tracking-wider mb-4">Informations</h4>
                <dl class="space-y-3">
                    <div>
                        <dt class="text-xs text-gray-500">Domaine</dt>
                        <dd class="text-sm font-medium text-gray-800"><?= e($project['domain']) ?: '—' ?></dd>
                    </div>
                    <div>
                        <dt class="text-xs text-gray-500">Responsable</dt>
                        <dd class="text-sm font-medium text-gray-800"><?= e($project['lead_name'] ?? '—') ?></dd>
                    </div>
                    <div>
                        <dt class="text-xs text-gray-500">Date de début</dt>
                        <dd class="text-sm font-medium text-gray-800"><?= formatDate($project['start_date']) ?></dd>
                    </div>
                    <div>
                        <dt class="text-xs text-gray-500">Statut</dt>
                        <dd class="text-sm"><?= statusBadge($project['status']) ?></dd>
                    </div>
                    <div>
                        <dt class="text-xs text-gray-500">Créé le</dt>
                        <dd class="text-sm text-gray-500"><?= formatDate($project['created_at']) ?></dd>
                    </div>
                </dl>
            </div>
        </div>
    </div>
</div>
