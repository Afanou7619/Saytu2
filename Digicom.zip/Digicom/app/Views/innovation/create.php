<div class="max-w-2xl mx-auto">
    <div class="mb-6 flex items-center justify-between">
        <div>
            <h3 class="text-xl font-semibold text-gray-800">Nouveau projet d'innovation</h3>
            <p class="text-sm text-gray-500 mt-1">Proposez une nouvelle idée ou initiative</p>
        </div>
        <a href="/innovation/projects" class="text-sm text-primary hover:underline">
            <i class="fas fa-arrow-left mr-1"></i> Retour
        </a>
    </div>

    <form action="/innovation/projects/create" method="POST" class="bg-white rounded-xl shadow-sm border border-gray-200 p-6 space-y-6">
        <?= csrfField() ?>

        <!-- Titre -->
        <div>
            <label for="title" class="block text-sm font-medium text-gray-700 mb-1">Titre <span class="text-red-500">*</span></label>
            <input type="text" name="title" id="title" value="<?= e(old('title')) ?>" required
                class="w-full border border-gray-300 rounded-lg px-4 py-2.5 text-sm focus:ring-2 focus:ring-primary focus:border-primary outline-none"
                placeholder="Titre du projet">
        </div>

        <!-- Domaine -->
        <div>
            <label for="domain" class="block text-sm font-medium text-gray-700 mb-1">Domaine</label>
            <input type="text" name="domain" id="domain" value="<?= e(old('domain')) ?>"
                class="w-full border border-gray-300 rounded-lg px-4 py-2.5 text-sm focus:ring-2 focus:ring-primary focus:border-primary outline-none"
                placeholder="Ex: Intelligence Artificielle, IoT, Mobile...">
        </div>

        <!-- Description -->
        <div>
            <label for="description" class="block text-sm font-medium text-gray-700 mb-1">Description <span class="text-red-500">*</span></label>
            <textarea name="description" id="description" rows="6" required
                class="w-full border border-gray-300 rounded-lg px-4 py-2.5 text-sm focus:ring-2 focus:ring-primary focus:border-primary outline-none"
                placeholder="Décrivez votre projet d'innovation..."><?= e(old('description')) ?></textarea>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <!-- Responsable -->
            <div>
                <label for="lead_id" class="block text-sm font-medium text-gray-700 mb-1">Responsable</label>
                <select name="lead_id" id="lead_id"
                    class="w-full border border-gray-300 rounded-lg px-4 py-2.5 text-sm focus:ring-2 focus:ring-primary focus:border-primary outline-none bg-white">
                    <option value="">-- Sélectionner --</option>
                    <?php foreach ($users as $user): ?>
                    <option value="<?= e($user['id']) ?>" <?= old('lead_id') == $user['id'] ? 'selected' : '' ?>>
                        <?= e($user['name']) ?>
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <!-- Date de début -->
            <div>
                <label for="start_date" class="block text-sm font-medium text-gray-700 mb-1">Date de début</label>
                <input type="date" name="start_date" id="start_date" value="<?= e(old('start_date')) ?>"
                    class="w-full border border-gray-300 rounded-lg px-4 py-2.5 text-sm focus:ring-2 focus:ring-primary focus:border-primary outline-none">
            </div>
        </div>

        <div class="flex items-center justify-end gap-3 pt-4 border-t border-gray-100">
            <a href="/innovation/projects" class="px-4 py-2.5 text-sm text-gray-600 hover:text-gray-800 border border-gray-300 rounded-lg hover:bg-gray-50 transition">
                Annuler
            </a>
            <button type="submit" class="px-6 py-2.5 bg-primary text-white text-sm font-medium rounded-lg hover:bg-blue-700 transition">
                <i class="fas fa-save mr-2"></i> Créer le projet
            </button>
        </div>
    </form>
</div>
