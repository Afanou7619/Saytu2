<div class="max-w-6xl mx-auto">
    <div class="mb-6">
        <h3 class="text-xl font-semibold text-gray-800">Bibliothèque de ressources</h3>
        <p class="text-sm text-gray-500 mt-1">Documents et ressources d'innovation</p>
    </div>

    <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
        <?php if (empty($resources)): ?>
        <div class="p-12 text-center text-gray-400">
            <i class="fas fa-book-open text-4xl mb-3"></i>
            <p class="text-sm">Aucune ressource disponible pour le moment.</p>
        </div>
        <?php else: ?>
        <div class="overflow-x-auto">
            <table class="w-full text-sm">
                <thead>
                    <tr class="bg-gray-50 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">
                        <th class="px-6 py-3">Titre</th>
                        <th class="px-6 py-3">Type</th>
                        <th class="px-6 py-3">Date</th>
                        <th class="px-6 py-3 w-24">Télécharger</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-100">
                    <?php foreach ($resources as $resource): ?>
                    <tr class="hover:bg-gray-50 transition">
                        <td class="px-6 py-4 font-medium text-gray-800"><?= e($resource['title']) ?></td>
                        <td class="px-6 py-4">
                            <span class="px-2 py-1 text-xs font-medium bg-blue-50 text-blue-700 rounded-full">
                                <?= e($resource['type'] ?? 'Document') ?>
                            </span>
                        </td>
                        <td class="px-6 py-4 text-gray-500"><?= formatDate($resource['created_at']) ?></td>
                        <td class="px-6 py-4">
                            <?php if (!empty($resource['file_path'])): ?>
                            <a href="<?= e($resource['file_path']) ?>" download
                                class="inline-flex items-center gap-1 text-primary hover:text-blue-700 text-xs font-medium transition">
                                <i class="fas fa-download"></i> Télécharger
                            </a>
                            <?php else: ?>
                            <span class="text-gray-300 text-xs">—</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>
    </div>
</div>
