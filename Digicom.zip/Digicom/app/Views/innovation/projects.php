<div class="max-w-6xl mx-auto">
    <div class="mb-6 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
            <h3 class="text-xl font-semibold text-gray-800">Projets d'innovation</h3>
            <p class="text-sm text-gray-500 mt-1"><?= count($projects) ?> projet(s)</p>
        </div>
        <a href="/innovation/projects/create" class="inline-flex items-center px-4 py-2.5 bg-primary text-white text-sm font-medium rounded-lg hover:bg-blue-700 transition">
            <i class="fas fa-plus mr-2"></i> Nouveau projet
        </a>
    </div>

    <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
        <?php if (empty($projects)): ?>
        <div class="p-12 text-center text-gray-400">
            <i class="fas fa-lightbulb text-4xl mb-3"></i>
            <p class="text-sm">Aucun projet d'innovation pour le moment.</p>
            <a href="/innovation/projects/create" class="inline-block mt-3 text-primary text-sm hover:underline">Créer le premier</a>
        </div>
        <?php else: ?>
        <div class="overflow-x-auto">
            <table class="w-full text-sm">
                <thead>
                    <tr class="bg-gray-50 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">
                        <th class="px-6 py-3">Titre</th>
                        <th class="px-6 py-3">Domaine</th>
                        <th class="px-6 py-3">Statut</th>
                        <th class="px-6 py-3">Responsable</th>
                        <th class="px-6 py-3">Date</th>
                        <th class="px-6 py-3 w-16"></th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-100">
                    <?php foreach ($projects as $project): ?>
                    <tr class="hover:bg-gray-50 transition">
                        <td class="px-6 py-4">
                            <a href="/innovation/projects/<?= e($project['id']) ?>" class="font-medium text-gray-800 hover:text-primary transition">
                                <?= e($project['title']) ?>
                            </a>
                        </td>
                        <td class="px-6 py-4 text-gray-600"><?= e($project['domain']) ?: '—' ?></td>
                        <td class="px-6 py-4"><?= statusBadge($project['status']) ?></td>
                        <td class="px-6 py-4 text-gray-600"><?= e($project['lead_name'] ?? '—') ?></td>
                        <td class="px-6 py-4 text-gray-500"><?= formatDate($project['start_date'] ?? $project['created_at']) ?></td>
                        <td class="px-6 py-4">
                            <a href="/innovation/projects/<?= e($project['id']) ?>" class="text-gray-400 hover:text-primary">
                                <i class="fas fa-chevron-right"></i>
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>
    </div>
</div>
