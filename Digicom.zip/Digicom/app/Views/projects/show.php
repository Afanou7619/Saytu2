<div class="space-y-6">
    <div class="flex items-center justify-between">
        <div class="flex items-center gap-3">
            <h1 class="text-xl font-bold text-gray-900"><?= e($project['title']) ?></h1>
            <?= statusBadge($project['status']) ?>
        </div>
        <div class="flex gap-2">
            <a href="/projects/<?= $project['id'] ?>/tasks/create" class="px-4 py-2 text-sm bg-blue-600 text-white rounded-lg hover:bg-blue-700">
                <i class="fas fa-plus mr-1"></i> Ajouter une tâche
            </a>
            <a href="/projects/<?= $project['id'] ?>/edit" class="px-4 py-2 text-sm bg-gray-100 text-gray-600 rounded-lg hover:bg-gray-200">
                <i class="fas fa-edit mr-1"></i> Modifier
            </a>
        </div>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div class="md:col-span-2 space-y-6">
            <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                <h3 class="text-sm font-semibold text-gray-700 mb-4">Progression</h3>
                <div class="flex items-center gap-4 mb-3">
                    <div class="flex-1 bg-gray-200 rounded-full h-3">
                        <div class="bg-blue-600 h-3 rounded-full transition-all" style="width: <?= $project['progress'] ?>%"></div>
                    </div>
                    <span class="text-sm font-semibold text-gray-700"><?= $project['progress'] ?>%</span>
                </div>
            </div>

            <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                <h3 class="text-sm font-semibold text-gray-700 mb-4">Description</h3>
                <p class="text-sm text-gray-600 leading-relaxed"><?= e($project['description'] ?: 'Aucune description.') ?></p>
            </div>

            <?php if (!empty($tasks)): ?>
            <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                <h3 class="text-sm font-semibold text-gray-700 mb-4">Tâches</h3>
                <?php
                $statusGroups = ['todo' => [], 'in_progress' => [], 'review' => [], 'done' => []];
                foreach ($tasks as $task) {
                    $s = $task['status'] ?? 'todo';
                    $statusGroups[$s][] = $task;
                }
                $statusLabels = ['todo' => 'À faire', 'in_progress' => 'En cours', 'review' => 'Révision', 'done' => 'Terminé'];
                ?>
                <?php foreach ($statusGroups as $status => $groupTasks): ?>
                    <?php if (!empty($groupTasks)): ?>
                    <div class="mb-6 last:mb-0">
                        <h4 class="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-3"><?= $statusLabels[$status] ?> (<?= count($groupTasks) ?>)</h4>
                        <div class="overflow-x-auto">
                            <table class="w-full text-sm">
                                <thead>
                                    <tr class="border-b border-gray-100 text-left text-xs text-gray-500 uppercase">
                                        <th class="pb-2 font-medium">Titre</th>
                                        <th class="pb-2 font-medium">Assigné à</th>
                                        <th class="pb-2 font-medium">Priorité</th>
                                        <th class="pb-2 font-medium">Statut</th>
                                        <th class="pb-2 font-medium">Échéance</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($groupTasks as $task): ?>
                                    <tr class="border-b border-gray-50 hover:bg-gray-50/50">
                                        <td class="py-2 pr-4">
                                            <a href="/tasks/<?= $task['id'] ?>" class="text-blue-600 hover:underline font-medium"><?= e($task['title']) ?></a>
                                        </td>
                                        <td class="py-2 pr-4 text-gray-600"><?= e($task['assigned_name'] ?? '—') ?></td>
                                        <td class="py-2 pr-4">
                                            <?php
                                            $priorityColors = [
                                                'high' => 'text-red-600 bg-red-50',
                                                'medium' => 'text-yellow-600 bg-yellow-50',
                                                'low' => 'text-gray-600 bg-gray-100',
                                            ];
                                            $priority = $task['priority'] ?? 'medium';
                                            $priorityClass = $priorityColors[$priority] ?? $priorityColors['medium'];
                                            ?>
                                            <span class="px-2 py-0.5 text-xs rounded-full <?= $priorityClass ?>"><?= ucfirst($priority) ?></span>
                                        </td>
                                        <td class="py-2 pr-4"><?= statusBadge($task['status']) ?></td>
                                        <td class="py-2 text-gray-500"><?= formatDate($task['due_date'] ?? null) ?></td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <?php endif; ?>
                <?php endforeach; ?>
                <?php if (empty(array_filter($statusGroups))) : ?>
                <p class="text-sm text-gray-400 py-4 text-center">Aucune tâche pour ce projet.</p>
                <?php endif; ?>
            </div>
            <?php endif; ?>
        </div>

        <div class="space-y-4">
            <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-5">
                <h3 class="text-sm font-semibold text-gray-700 mb-3">Détails</h3>
                <dl class="space-y-3 text-sm">
                    <div class="flex justify-between">
                        <dt class="text-gray-500">Début</dt>
                        <dd class="text-gray-800 font-medium"><?= formatDate($project['start_date']) ?></dd>
                    </div>
                    <div class="flex justify-between">
                        <dt class="text-gray-500">Fin prévue</dt>
                        <dd class="text-gray-800 font-medium"><?= formatDate($project['end_date']) ?></dd>
                    </div>
                    <div class="flex justify-between">
                        <dt class="text-gray-500">Budget</dt>
                        <dd class="text-gray-800 font-medium"><?= formatCurrency($project['budget'] ?? 0) ?></dd>
                    </div>
                    <div class="flex justify-between">
                        <dt class="text-gray-500">Dépensé</dt>
                        <dd class="text-red-600 font-medium"><?= formatCurrency($project['spent'] ?? 0) ?></dd>
                    </div>
                    <div class="flex justify-between">
                        <dt class="text-gray-500">Client</dt>
                        <dd class="text-gray-800 font-medium">
                            <?php if (!empty($project['client_name'])): ?>
                            <a href="/crm/clients/<?= $project['client_id'] ?>" class="text-blue-600 hover:underline"><?= e($project['client_name']) ?></a>
                            <?php else: ?>
                            —
                            <?php endif; ?>
                        </dd>
                    </div>
                    <div class="flex justify-between">
                        <dt class="text-gray-500">Chef de projet</dt>
                        <dd class="text-gray-800 font-medium"><?= e($project['manager_name'] ?? '—') ?></dd>
                    </div>
                </dl>
            </div>
        </div>
    </div>
</div>
