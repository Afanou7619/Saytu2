<div class="space-y-6">
    <div class="flex items-center justify-between">
        <h1 class="text-xl font-bold text-gray-900">Projets</h1>
        <div class="flex gap-2">
            <a href="/projects/create" class="px-4 py-2 text-sm bg-blue-600 text-white rounded-lg hover:bg-blue-700">
                <i class="fas fa-plus mr-1"></i> Nouveau projet
            </a>
        </div>
    </div>

    <!-- Filtres -->
    <div class="flex gap-2">
        <a href="/projects" class="px-4 py-2 text-sm rounded-lg <?= empty($filterStatus) ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200' ?>">Tous</a>
        <a href="/projects?status=active" class="px-4 py-2 text-sm rounded-lg <?= ($filterStatus ?? '') === 'active' ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200' ?>">Actifs</a>
        <a href="/projects?status=completed" class="px-4 py-2 text-sm rounded-lg <?= ($filterStatus ?? '') === 'completed' ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200' ?>">Terminés</a>
        <a href="/projects?status=on_hold" class="px-4 py-2 text-sm rounded-lg <?= ($filterStatus ?? '') === 'on_hold' ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200' ?>">En pause</a>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        <?php foreach ($projects['items'] as $project): ?>
        <a href="/projects/<?= $project['id'] ?>" class="bg-white rounded-xl shadow-sm border border-gray-100 p-5 hover:shadow-md hover:border-blue-200 transition">
            <div class="flex items-start justify-between mb-3">
                <h3 class="text-sm font-semibold text-gray-800 truncate"><?= e($project['title']) ?></h3>
                <?= statusBadge($project['status']) ?>
            </div>
            <div class="space-y-2">
                <div class="flex items-center justify-between text-xs text-gray-500">
                    <span>Progression</span>
                    <span class="font-medium"><?= $project['progress'] ?>%</span>
                </div>
                <div class="w-full bg-gray-200 rounded-full h-1.5">
                    <div class="bg-blue-600 h-1.5 rounded-full" style="width: <?= $project['progress'] ?>%"></div>
                </div>
                <div class="flex items-center justify-between text-xs text-gray-400 mt-2">
                    <span><i class="far fa-calendar mr-1"></i><?= formatDate($project['start_date']) ?></span>
                    <span><i class="far fa-calendar-check mr-1"></i><?= formatDate($project['end_date']) ?></span>
                </div>
                <?php if ($project['budget']): ?>
                <div class="text-xs text-gray-500">
                    Budget: <?= formatCurrency($project['budget']) ?>
                    <?php if ($project['spent'] > 0): ?>
                    <span class="text-red-500"> | Dépensé: <?= formatCurrency($project['spent']) ?></span>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
            </div>
        </a>
        <?php endforeach; ?>
        <?php if (empty($projects['items'])): ?>
        <div class="col-span-full text-center py-12 text-gray-400">Aucun projet trouvé</div>
        <?php endif; ?>
    </div>
</div>
