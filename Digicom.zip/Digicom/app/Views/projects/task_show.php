<div class="space-y-6">
    <div class="flex items-center justify-between">
        <div class="flex items-center gap-3">
            <a href="/projects/<?= $task['project_id'] ?>" class="text-sm text-gray-500 hover:text-gray-700">
                <i class="fas fa-arrow-left mr-1"></i> Projet
            </a>
            <h1 class="text-xl font-bold text-gray-900"><?= e($task['title']) ?></h1>
        </div>
        <div class="flex gap-2">
            <a href="/tasks/<?= $task['id'] ?>/edit" class="px-4 py-2 text-sm bg-gray-100 text-gray-600 rounded-lg hover:bg-gray-200">
                <i class="fas fa-edit mr-1"></i> Modifier
            </a>
        </div>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div class="md:col-span-2 space-y-6">
            <!-- Détails de la tâche -->
            <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                <h3 class="text-sm font-semibold text-gray-700 mb-4">Informations</h3>
                <dl class="grid grid-cols-2 gap-4 text-sm">
                    <div>
                        <dt class="text-gray-500 mb-1">Statut</dt>
                        <dd><?= statusBadge($task['status']) ?></dd>
                    </div>
                    <div>
                        <dt class="text-gray-500 mb-1">Priorité</dt>
                        <dd>
                            <?php
                            $priorityColors = [
                                'high' => 'text-red-600 bg-red-50',
                                'medium' => 'text-yellow-600 bg-yellow-50',
                                'low' => 'text-gray-600 bg-gray-100',
                            ];
                            $priority = $task['priority'] ?? 'medium';
                            ?>
                            <span class="px-2 py-0.5 text-xs rounded-full <?= $priorityColors[$priority] ?>"><?= ucfirst($priority) ?></span>
                        </dd>
                    </div>
                    <div>
                        <dt class="text-gray-500 mb-1">Assigné à</dt>
                        <dd class="text-gray-800 font-medium"><?= e($task['assigned_name'] ?? '—') ?></dd>
                    </div>
                    <div>
                        <dt class="text-gray-500 mb-1">Échéance</dt>
                        <dd class="text-gray-800">
                            <?= formatDate($task['due_date'] ?? null) ?>
                            <?php if (!empty($task['due_time'])): ?>
                            <span class="text-gray-500"> à <?= e($task['due_time']) ?></span>
                            <?php endif; ?>
                        </dd>
                    </div>
                    <div class="col-span-2">
                        <dt class="text-gray-500 mb-1">Projet</dt>
                        <dd>
                            <a href="/projects/<?= $task['project_id'] ?>" class="text-blue-600 hover:underline"><?= e($task['project_title'] ?? 'Projet #' . $task['project_id']) ?></a>
                        </dd>
                    </div>
                </dl>
            </div>

            <!-- Description -->
            <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                <h3 class="text-sm font-semibold text-gray-700 mb-3">Description</h3>
                <p class="text-sm text-gray-600 leading-relaxed"><?= nl2br(e($task['description'] ?: 'Aucune description.')) ?></p>
            </div>

            <!-- Boutons de changement de statut -->
            <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                <h3 class="text-sm font-semibold text-gray-700 mb-3">Changer le statut</h3>
                <div class="flex flex-wrap gap-2">
                    <?php
                    $statusActions = [
                        'todo'        => ['label' => 'À faire',   'class' => 'bg-gray-100 text-gray-700 hover:bg-gray-200'],
                        'in_progress' => ['label' => 'En cours',  'class' => 'bg-blue-100 text-blue-700 hover:bg-blue-200'],
                        'review'      => ['label' => 'Révision',  'class' => 'bg-purple-100 text-purple-700 hover:bg-purple-200'],
                        'done'        => ['label' => 'Terminé',   'class' => 'bg-green-100 text-green-700 hover:bg-green-200'],
                    ];
                    ?>
                    <?php foreach ($statusActions as $status => $action): ?>
                    <?php if (($task['status'] ?? '') !== $status): ?>
                    <form method="POST" action="/tasks/<?= $task['id'] ?>/status">
                        <?= csrfField() ?>
                        <input type="hidden" name="status" value="<?= $status ?>">
                        <button type="submit" class="px-3 py-1.5 text-sm rounded-lg font-medium <?= $action['class'] ?> transition">
                            <i class="fas fa-arrow-right mr-1"></i> <?= $action['label'] ?>
                        </button>
                    </form>
                    <?php endif; ?>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- Commentaires -->
            <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                <h3 class="text-sm font-semibold text-gray-700 mb-4">Commentaires (<?= count($comments) ?>)</h3>

                <?php if (!empty($comments)): ?>
                <div class="space-y-4 mb-6">
                    <?php foreach ($comments as $comment): ?>
                    <div class="flex gap-3">
                        <div class="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 text-xs font-bold shrink-0">
                            <?= e(strtoupper(substr($comment['author_name'] ?? 'U', 0, 1))) ?>
                        </div>
                        <div class="flex-1">
                            <div class="flex items-center gap-2 mb-1">
                                <span class="text-sm font-medium text-gray-800"><?= e($comment['author_name'] ?? 'Utilisateur') ?></span>
                                <span class="text-xs text-gray-400"><?= formatDateTime($comment['created_at'] ?? '') ?></span>
                            </div>
                            <p class="text-sm text-gray-600"><?= nl2br(e($comment['content'])) ?></p>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
                <?php else: ?>
                <p class="text-sm text-gray-400 mb-6">Aucun commentaire.</p>
                <?php endif; ?>

                <form method="POST" action="/tasks/<?= $task['id'] ?>/comments" class="space-y-3">
                    <?= csrfField() ?>
                    <textarea name="content" rows="3" placeholder="Ajouter un commentaire..." class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500"></textarea>
                    <button type="submit" class="px-4 py-2 text-sm bg-blue-600 text-white rounded-lg hover:bg-blue-700">
                        <i class="fas fa-paper-plane mr-1"></i> Envoyer
                    </button>
                </form>
            </div>
        </div>

        <!-- Sidebar -->
        <div class="space-y-4">
            <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-5">
                <h3 class="text-sm font-semibold text-gray-700 mb-3">Méta-données</h3>
                <dl class="space-y-3 text-sm">
                    <div class="flex justify-between">
                        <dt class="text-gray-500">Créé le</dt>
                        <dd class="text-gray-800"><?= formatDateTime($task['created_at'] ?? '') ?></dd>
                    </div>
                    <div class="flex justify-between">
                        <dt class="text-gray-500">Mis à jour</dt>
                        <dd class="text-gray-800"><?= formatDateTime($task['updated_at'] ?? '') ?></dd>
                    </div>
                    <div class="flex justify-between">
                        <dt class="text-gray-500">Créé par</dt>
                        <dd class="text-gray-800"><?= e($task['created_by_name'] ?? '—') ?></dd>
                    </div>
                </dl>
            </div>
        </div>
    </div>
</div>
