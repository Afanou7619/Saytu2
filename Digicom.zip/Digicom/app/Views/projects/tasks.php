<div class="space-y-6">
    <div class="flex items-center justify-between">
        <h1 class="text-xl font-bold text-gray-900">Tâches</h1>
        <a href="/projects/<?= $projectId ?? '' ?>/tasks/create" class="px-4 py-2 text-sm bg-blue-600 text-white rounded-lg hover:bg-blue-700">
            <i class="fas fa-plus mr-1"></i> Nouvelle tâche
        </a>
    </div>

    <!-- Filtres -->
    <form method="GET" action="/tasks" class="flex flex-wrap gap-3 items-end bg-white rounded-xl shadow-sm border border-gray-100 p-4">
        <div>
            <label class="block text-xs font-medium text-gray-500 mb-1">Statut</label>
            <select name="status" class="px-3 py-2 border border-gray-300 rounded-lg text-sm">
                <option value="">Tous</option>
                <option value="todo" <?= ($filterStatus ?? '') === 'todo' ? 'selected' : '' ?>>À faire</option>
                <option value="in_progress" <?= ($filterStatus ?? '') === 'in_progress' ? 'selected' : '' ?>>En cours</option>
                <option value="review" <?= ($filterStatus ?? '') === 'review' ? 'selected' : '' ?>>Révision</option>
                <option value="done" <?= ($filterStatus ?? '') === 'done' ? 'selected' : '' ?>>Terminé</option>
            </select>
        </div>
        <div>
            <label class="block text-xs font-medium text-gray-500 mb-1">Assigné à</label>
            <select name="user_id" class="px-3 py-2 border border-gray-300 rounded-lg text-sm">
                <option value="">Tous</option>
                <?php foreach ($users as $user): ?>
                <option value="<?= $user['id'] ?>" <?= ($filterUserId ?? '') == $user['id'] ? 'selected' : '' ?>><?= e($user['name'] ?? $user['first_name'] . ' ' . $user['last_name']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <button type="submit" class="px-4 py-2 text-sm bg-gray-100 text-gray-600 rounded-lg hover:bg-gray-200">
            <i class="fas fa-filter mr-1"></i> Filtrer
        </button>
        <?php if (!empty($filterStatus) || !empty($filterUserId)): ?>
        <a href="/tasks" class="px-4 py-2 text-sm text-gray-500 hover:text-gray-700">
            <i class="fas fa-times mr-1"></i> Effacer
        </a>
        <?php endif; ?>
    </form>

    <!-- Tableau -->
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <div class="overflow-x-auto">
            <table class="w-full text-sm">
                <thead>
                    <tr class="bg-gray-50 text-left text-xs text-gray-500 uppercase tracking-wider">
                        <th class="px-4 py-3 font-medium">Titre</th>
                        <th class="px-4 py-3 font-medium">Projet</th>
                        <th class="px-4 py-3 font-medium">Assigné à</th>
                        <th class="px-4 py-3 font-medium">Priorité</th>
                        <th class="px-4 py-3 font-medium">Statut</th>
                        <th class="px-4 py-3 font-medium">Échéance</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($tasks)): ?>
                    <?php foreach ($tasks as $task): ?>
                    <tr class="border-b border-gray-100 hover:bg-gray-50/50">
                        <td class="px-4 py-3">
                            <a href="/tasks/<?= $task['id'] ?>" class="text-blue-600 hover:underline font-medium"><?= e($task['title']) ?></a>
                        </td>
                        <td class="px-4 py-3 text-gray-600">
                            <?php if (!empty($task['project_title'])): ?>
                            <a href="/projects/<?= $task['project_id'] ?>" class="text-blue-600 hover:underline"><?= e($task['project_title']) ?></a>
                            <?php else: ?>
                            —
                            <?php endif; ?>
                        </td>
                        <td class="px-4 py-3 text-gray-600"><?= e($task['assigned_name'] ?? '—') ?></td>
                        <td class="px-4 py-3">
                            <?php
                            $priorityColors = [
                                'high' => 'text-red-600 bg-red-50',
                                'medium' => 'text-yellow-600 bg-yellow-50',
                                'low' => 'text-gray-600 bg-gray-100',
                            ];
                            $priority = $task['priority'] ?? 'medium';
                            $priorityClass = $priorityColors[$priority] ?? $priorityColors['medium'];
                            ?>
                            <span class="px-2 py-0.5 text-xs rounded-full <?= $priorityClass ?>"><?= ucfirst($priority) ?></span>
                        </td>
                        <td class="px-4 py-3"><?= statusBadge($task['status']) ?></td>
                        <td class="px-4 py-3 text-gray-500"><?= formatDate($task['due_date'] ?? null) ?></td>
                    </tr>
                    <?php endforeach; ?>
                    <?php else: ?>
                    <tr>
                        <td colspan="6" class="px-4 py-12 text-center text-gray-400">Aucune tâche trouvée</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
