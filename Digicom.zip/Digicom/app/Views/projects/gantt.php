<div class="space-y-6">
    <div class="flex items-center justify-between">
        <div>
            <h1 class="text-xl font-bold text-gray-900">Diagramme de Gantt</h1>
            <p class="text-sm text-gray-500"><?= e($project['title']) ?></p>
        </div>
        <a href="/projects/<?= $project['id'] ?>" class="px-4 py-2 text-sm bg-gray-100 text-gray-600 rounded-lg hover:bg-gray-200">
            <i class="fas fa-arrow-left mr-1"></i> Retour au projet
        </a>
    </div>

    <?php
    // Calculate date range
    $minDate = null;
    $maxDate = null;
    foreach ($tasks as $task) {
        if (!empty($task['start_date'])) {
            $d = new DateTimeImmutable($task['start_date']);
            if ($minDate === null || $d < $minDate) $minDate = $d;
        }
        if (!empty($task['due_date'])) {
            $d = new DateTimeImmutable($task['due_date']);
            if ($maxDate === null || $d > $maxDate) $maxDate = $d;
        }
    }
    // Defaults
    if ($minDate === null) $minDate = new DateTimeImmutable();
    if ($maxDate === null) $maxDate = (new DateTimeImmutable())->modify('+30 days');
    // Ensure at least some range
    if ($minDate >= $maxDate) $maxDate = $minDate->modify('+30 days');

    $totalDays = max(1, (int) $minDate->diff($maxDate)->days);

    // Generate month headers
    $interval = new DateInterval('P1M');
    $period = new DatePeriod($minDate, $interval, $maxDate->modify('+1 month'));
    $months = [];
    foreach ($period as $dt) {
        $months[] = $dt;
    }
    ?>

    <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <!-- Month header -->
        <div class="flex border-b border-gray-200">
            <div class="w-64 shrink-0 px-4 py-2 text-xs font-semibold text-gray-500 uppercase bg-gray-50 border-r border-gray-200">
                Tâche
            </div>
            <div class="flex-1 flex bg-gray-50">
                <?php foreach ($months as $month): ?>
                <div class="flex-1 px-2 py-2 text-xs font-semibold text-gray-500 text-center border-r border-gray-200 last:border-r-0">
                    <?= $month->format('M Y') ?>
                </div>
                <?php endforeach; ?>
            </div>
        </div>

        <?php if (empty($tasks)): ?>
        <div class="px-4 py-12 text-center text-gray-400 text-sm">Aucune tâche à afficher</div>
        <?php else: ?>
        <?php foreach ($tasks as $task): ?>
        <div class="flex border-b border-gray-100 hover:bg-gray-50/50 transition">
            <div class="w-64 shrink-0 px-4 py-3 border-r border-gray-100">
                <div class="flex items-center gap-2">
                    <?= statusBadge($task['status']) ?>
                    <a href="/tasks/<?= $task['id'] ?>" class="text-sm text-blue-600 hover:underline truncate"><?= e($task['title']) ?></a>
                </div>
            </div>
            <div class="flex-1 flex py-3 relative">
                <?php
                $taskStart = !empty($task['start_date']) ? new DateTimeImmutable($task['start_date']) : $minDate;
                $taskEnd   = !empty($task['due_date'])   ? new DateTimeImmutable($task['due_date'])   : (new DateTimeImmutable())->modify('+7 days');

                // Calculate left offset and width as percentages
                $offsetDays = max(0, (int) $minDate->diff($taskStart)->days);
                $taskDays   = max(1, (int) $taskStart->diff($taskEnd)->days);

                $leftPercent  = ($offsetDays / $totalDays) * 100;
                $widthPercent = max(2, ($taskDays / $totalDays) * 100);

                // Color by status
                $barColors = [
                    'todo'        => 'bg-gray-400',
                    'in_progress' => 'bg-blue-500',
                    'review'      => 'bg-purple-500',
                    'done'        => 'bg-green-500',
                ];
                $barColor = $barColors[$task['status'] ?? 'todo'] ?? 'bg-gray-400';
                ?>
                <div class="absolute top-1/2 -translate-y-1/2 h-5 rounded-full <?= $barColor ?>" style="left: <?= $leftPercent ?>%; width: <?= $widthPercent ?>%;">
                    <span class="absolute inset-0 flex items-center px-2 text-xs text-white font-medium truncate">
                        <?= e($task['title']) ?>
                    </span>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <!-- Legend -->
    <div class="flex gap-4 text-xs text-gray-500">
        <span class="flex items-center gap-1"><span class="w-3 h-3 rounded-full bg-gray-400 inline-block"></span> À faire</span>
        <span class="flex items-center gap-1"><span class="w-3 h-3 rounded-full bg-blue-500 inline-block"></span> En cours</span>
        <span class="flex items-center gap-1"><span class="w-3 h-3 rounded-full bg-purple-500 inline-block"></span> Révision</span>
        <span class="flex items-center gap-1"><span class="w-3 h-3 rounded-full bg-green-500 inline-block"></span> Terminé</span>
    </div>
</div>
