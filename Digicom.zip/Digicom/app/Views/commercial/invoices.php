<div class="space-y-6">
    <div class="flex items-center justify-between">
        <h1 class="text-xl font-bold text-gray-900">Factures</h1>
        <a href="/commercial/invoices/create" class="px-4 py-2 text-sm bg-blue-600 text-white rounded-lg hover:bg-blue-700">
            <i class="fas fa-plus mr-1"></i> Nouvelle facture
        </a>
    </div>

    <!-- Filtres -->
    <div class="flex gap-2">
        <a href="/commercial/invoices" class="px-4 py-2 text-sm rounded-lg <?= ($filterStatus ?? 'all') === 'all' ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200' ?>">Toutes</a>
        <a href="/commercial/invoices?status=draft" class="px-4 py-2 text-sm rounded-lg <?= ($filterStatus ?? '') === 'draft' ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200' ?>">Brouillon</a>
        <a href="/commercial/invoices?status=sent" class="px-4 py-2 text-sm rounded-lg <?= ($filterStatus ?? '') === 'sent' ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200' ?>">Envoyée</a>
        <a href="/commercial/invoices?status=paid" class="px-4 py-2 text-sm rounded-lg <?= ($filterStatus ?? '') === 'paid' ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200' ?>">Payée</a>
        <a href="/commercial/invoices?status=overdue" class="px-4 py-2 text-sm rounded-lg <?= ($filterStatus ?? '') === 'overdue' ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200' ?>">En retard</a>
        <a href="/commercial/invoices?status=cancelled" class="px-4 py-2 text-sm rounded-lg <?= ($filterStatus ?? '') === 'cancelled' ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200' ?>">Annulée</a>
    </div>

    <!-- Liste des factures -->
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <table class="w-full">
            <thead class="bg-gray-50">
                <tr>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Référence</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Client</th>
                    <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">Montant TTC</th>
                    <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">Payé</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Statut</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Date</th>
                    <th class="px-6 py-3"></th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-100">
                <?php foreach ($invoices as $invoice): ?>
                <tr class="hover:bg-gray-50 transition">
                    <td class="px-6 py-4">
                        <a href="/commercial/invoices/<?= $invoice['id'] ?>" class="text-sm font-medium text-blue-600 hover:underline">
                            <?= e($invoice['reference']) ?>
                        </a>
                    </td>
                    <td class="px-6 py-4 text-sm text-gray-700"><?= e($invoice['client_name'] ?? '—') ?></td>
                    <td class="px-6 py-4 text-sm text-right font-medium"><?= formatCurrency($invoice['total_ttc'] ?? 0) ?></td>
                    <td class="px-6 py-4 text-sm text-right text-green-600"><?= formatCurrency($invoice['paid_amount'] ?? 0) ?></td>
                    <td class="px-6 py-4"><?= statusBadge($invoice['status']) ?></td>
                    <td class="px-6 py-4 text-sm text-gray-500"><?= formatDate($invoice['created_at'] ?? null) ?></td>
                    <td class="px-6 py-4 text-right">
                        <a href="/commercial/invoices/<?= $invoice['id'] ?>/edit" class="text-gray-400 hover:text-blue-600">
                            <i class="fas fa-edit"></i>
                        </a>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php if (empty($invoices)): ?>
                <tr><td colspan="7" class="px-6 py-8 text-center text-gray-400">Aucune facture trouvée</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
