<div class="space-y-6">
    <div class="flex items-center justify-between">
        <h1 class="text-xl font-bold text-gray-900">Gestion Commerciale</h1>
    </div>

    <!-- KPIs -->
    <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div class="bg-white rounded-xl shadow-sm p-5 border border-gray-100">
            <p class="text-sm text-gray-500">Devis en cours</p>
            <p class="text-2xl font-bold text-gray-900"><?= count($quotes ?? []) ?></p>
        </div>
        <div class="bg-white rounded-xl shadow-sm p-5 border border-gray-100">
            <p class="text-sm text-gray-500">Factures impayées</p>
            <p class="text-2xl font-bold text-red-600"><?= count($overdueInvoices ?? []) ?></p>
        </div>
        <div class="bg-white rounded-xl shadow-sm p-5 border border-gray-100">
            <p class="text-sm text-gray-500">Créances en retard</p>
            <p class="text-2xl font-bold text-orange-600"><?= count($overdueInvoices ?? []) ?></p>
        </div>
        <div class="bg-white rounded-xl shadow-sm p-5 border border-gray-100">
            <p class="text-sm text-gray-500">Actions rapides</p>
            <div class="flex gap-2 mt-1">
                <a href="/commercial/quotes/create" class="text-xs px-3 py-1.5 bg-blue-600 text-white rounded-lg">Nouveau devis</a>
                <a href="/commercial/invoices/create" class="text-xs px-3 py-1.5 bg-green-600 text-white rounded-lg">Nouvelle facture</a>
            </div>
        </div>
    </div>

    <!-- Devis en attente -->
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <div class="px-6 py-4 border-b border-gray-100">
            <h3 class="text-sm font-semibold text-gray-700">Devis en attente</h3>
        </div>
        <table class="w-full">
            <thead class="bg-gray-50">
                <tr>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Référence</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Client</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Montant TTC</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Échéance</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Statut</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-100">
                <?php foreach ($quotes as $quote): ?>
                <tr class="hover:bg-gray-50 transition">
                    <td class="px-6 py-4">
                        <a href="/commercial/quotes/<?= $quote['id'] ?>" class="text-sm font-medium text-blue-600"><?= e($quote['reference']) ?></a>
                    </td>
                    <td class="px-6 py-4 text-sm"><?= e($quote['client_name'] ?? '—') ?></td>
                    <td class="px-6 py-4 text-sm font-medium"><?= formatCurrency($quote['total_ttc'] ?? 0) ?></td>
                    <td class="px-6 py-4 text-sm text-gray-500"><?= formatDate($quote['valid_until'] ?? null) ?></td>
                    <td class="px-6 py-4"><?= statusBadge($quote['status']) ?></td>
                </tr>
                <?php endforeach; ?>
                <?php if (empty($quotes)): ?>
                <tr><td colspan="5" class="px-6 py-6 text-center text-gray-400">Aucun devis en attente</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Factures en retard -->
    <?php if (!empty($overdueInvoices)): ?>
    <div class="bg-white rounded-xl shadow-sm border border-red-200 overflow-hidden">
        <div class="px-6 py-4 border-b border-red-100 bg-red-50">
            <h3 class="text-sm font-semibold text-red-700">
                <i class="fas fa-exclamation-triangle mr-2"></i>Factures en retard
            </h3>
        </div>
        <table class="w-full">
            <thead class="bg-red-50/50">
                <tr>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Référence</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Client</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Montant</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Échéance</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-100">
                <?php foreach ($overdueInvoices as $inv): ?>
                <tr class="hover:bg-gray-50">
                    <td class="px-6 py-4"><a href="/commercial/invoices/<?= $inv['id'] ?>" class="text-sm font-medium text-red-600"><?= e($inv['reference']) ?></a></td>
                    <td class="px-6 py-4 text-sm"><?= e($inv['client_name'] ?? '—') ?></td>
                    <td class="px-6 py-4 text-sm font-medium"><?= formatCurrency(($inv['total_ttc'] ?? 0) - ($inv['paid_amount'] ?? 0)) ?></td>
                    <td class="px-6 py-4 text-sm text-red-600"><?= formatDate($inv['due_date']) ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
</div>
