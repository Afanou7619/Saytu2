<div class="space-y-6">
    <div class="flex items-center justify-between">
        <div>
            <h1 class="text-xl font-bold text-gray-900">Facture <?= e($invoice['reference']) ?></h1>
            <p class="text-sm text-gray-500">Créée le <?= formatDate($invoice['created_at'] ?? null) ?></p>
        </div>
        <div class="flex gap-2">
            <a href="/commercial/invoices/<?= $invoice['id'] ?>/edit" class="px-4 py-2 text-sm bg-blue-600 text-white rounded-lg hover:bg-blue-700">
                <i class="fas fa-edit mr-1"></i> Modifier
            </a>
            <a href="/commercial/invoices/<?= $invoice['id'] ?>/pdf" class="px-4 py-2 text-sm bg-gray-100 text-gray-600 rounded-lg hover:bg-gray-200">
                <i class="fas fa-download mr-1"></i> PDF
            </a>
        </div>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
        <!-- Détails facture -->
        <div class="md:col-span-2 space-y-6">
            <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
                <div class="px-6 py-4 border-b border-gray-100">
                    <h3 class="text-sm font-semibold text-gray-700">Articles</h3>
                </div>
                <table class="w-full">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Description</th>
                            <th class="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase">Quantité</th>
                            <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">Prix unitaire</th>
                            <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">Total</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-100">
                        <?php foreach ($items as $item): ?>
                        <tr>
                            <td class="px-6 py-4 text-sm text-gray-700"><?= e($item['description']) ?></td>
                            <td class="px-6 py-4 text-sm text-center"><?= (int)$item['quantity'] ?></td>
                            <td class="px-6 py-4 text-sm text-right"><?= formatCurrency($item['unit_price'] ?? 0) ?></td>
                            <td class="px-6 py-4 text-sm text-right font-medium"><?= formatCurrency($item['total'] ?? 0) ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <!-- Historique des paiements -->
            <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
                <div class="px-6 py-4 border-b border-gray-100">
                    <h3 class="text-sm font-semibold text-gray-700">Paiements</h3>
                </div>
                <?php if (!empty($payments)): ?>
                <table class="w-full">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Date</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Mode</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Référence</th>
                            <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">Montant</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-100">
                        <?php foreach ($payments as $payment): ?>
                        <tr>
                            <td class="px-6 py-4 text-sm text-gray-500"><?= formatDate($payment['payment_date'] ?? $payment['created_at'] ?? null) ?></td>
                            <td class="px-6 py-4 text-sm"><?= e($payment['payment_method'] ?? '—') ?></td>
                            <td class="px-6 py-4 text-sm text-gray-500"><?= e($payment['reference'] ?? '—') ?></td>
                            <td class="px-6 py-4 text-sm text-right font-medium text-green-600"><?= formatCurrency($payment['amount'] ?? 0) ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <?php else: ?>
                <div class="px-6 py-6 text-center text-gray-400 text-sm">Aucun paiement enregistré</div>
                <?php endif; ?>
            </div>

            <?php if (!empty($invoice['notes'])): ?>
            <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                <h3 class="text-sm font-semibold text-gray-700 mb-2">Notes</h3>
                <p class="text-sm text-gray-600"><?= nl2br(e($invoice['notes'])) ?></p>
            </div>
            <?php endif; ?>
        </div>

        <!-- Infos latérales -->
        <div class="space-y-6">
            <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                <h3 class="text-sm font-semibold text-gray-700 mb-3">Statut</h3>
                <div class="mb-3"><?= statusBadge($invoice['status']) ?></div>
                <p class="text-sm text-gray-500">Échéance : <?= formatDate($invoice['due_date'] ?? null) ?></p>
            </div>

            <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                <h3 class="text-sm font-semibold text-gray-700 mb-3">Client</h3>
                <?php if ($client): ?>
                <p class="text-sm font-medium text-gray-800"><?= e($client['company_name'] ?? $client['contact_name'] ?? '—') ?></p>
                <?php if (!empty($client['contact_name'])): ?>
                <p class="text-sm text-gray-500"><?= e($client['contact_name']) ?></p>
                <?php endif; ?>
                <?php if (!empty($client['email'])): ?>
                <p class="text-sm text-gray-500"><?= e($client['email']) ?></p>
                <?php endif; ?>
                <?php if (!empty($client['phone'])): ?>
                <p class="text-sm text-gray-500"><?= e($client['phone']) ?></p>
                <?php endif; ?>
                <?php if (!empty($client['address'])): ?>
                <p class="text-sm text-gray-500 mt-1"><?= e($client['address']) ?></p>
                <?php endif; ?>
                <?php else: ?>
                <p class="text-sm text-gray-400">Client inconnu</p>
                <?php endif; ?>
            </div>

            <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                <h3 class="text-sm font-semibold text-gray-700 mb-3">Totaux</h3>
                <dl class="space-y-2 text-sm">
                    <div class="flex justify-between">
                        <dt class="text-gray-500">Total HT</dt>
                        <dd class="font-medium"><?= formatCurrency($invoice['total_ht'] ?? 0) ?></dd>
                    </div>
                    <div class="flex justify-between">
                        <dt class="text-gray-500">TVA (<?= e($invoice['tax_rate'] ?? 18) ?>%)</dt>
                        <dd class="font-medium"><?= formatCurrency(($invoice['total_ttc'] ?? 0) - ($invoice['total_ht'] ?? 0)) ?></dd>
                    </div>
                    <div class="flex justify-between">
                        <dt class="text-gray-500">Payé</dt>
                        <dd class="font-medium text-green-600"><?= formatCurrency($invoice['paid_amount'] ?? 0) ?></dd>
                    </div>
                    <div class="flex justify-between border-t border-gray-200 pt-2">
                        <dt class="font-semibold text-gray-700">Reste à payer</dt>
                        <dd class="font-bold <?= (($invoice['total_ttc'] ?? 0) - ($invoice['paid_amount'] ?? 0)) > 0 ? 'text-red-600' : 'text-green-600' ?>">
                            <?= formatCurrency(($invoice['total_ttc'] ?? 0) - ($invoice['paid_amount'] ?? 0)) ?>
                        </dd>
                    </div>
                </dl>
            </div>
        </div>
    </div>

    <!-- Formulaire d'ajout de paiement -->
    <?php if (($invoice['total_ttc'] ?? 0) - ($invoice['paid_amount'] ?? 0) > 0): ?>
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
        <h3 class="text-sm font-semibold text-gray-700 mb-4">Enregistrer un paiement</h3>
        <form method="POST" action="/commercial/invoices/<?= $invoice['id'] ?>/payments/create" class="space-y-4">
            <?= csrfField() ?>
            <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Montant</label>
                    <input type="number" name="amount" step="0.01" min="0.01" max="<?= ($invoice['total_ttc'] ?? 0) - ($invoice['paid_amount'] ?? 0) ?>" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm" required>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Mode de paiement</label>
                    <select name="payment_method" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm" required>
                        <option value="">— Sélectionner —</option>
                        <option value="cash">Espèces</option>
                        <option value="bank_transfer">Virement</option>
                        <option value="check">Chèque</option>
                        <option value="mobile_money">Mobile Money</option>
                        <option value="credit_card">Carte bancaire</option>
                    </select>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Date</label>
                    <input type="date" name="payment_date" value="<?= date('Y-m-d') ?>" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm" required>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Référence</label>
                    <input type="text" name="reference" placeholder="N° de transaction" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm">
                </div>
            </div>
            <div class="flex gap-3">
                <button type="submit" class="px-6 py-2.5 bg-green-600 text-white text-sm rounded-lg hover:bg-green-700">
                    <i class="fas fa-check mr-1"></i> Enregistrer le paiement
                </button>
            </div>
        </form>
    </div>
    <?php endif; ?>
</div>
