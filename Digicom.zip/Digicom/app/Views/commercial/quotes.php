<div class="space-y-6">
    <div class="flex items-center justify-between">
        <h1 class="text-xl font-bold text-gray-900">Devis</h1>
        <a href="/commercial/quotes/create" class="px-4 py-2 text-sm bg-blue-600 text-white rounded-lg hover:bg-blue-700">
            <i class="fas fa-plus mr-1"></i> Nouveau devis
        </a>
    </div>

    <!-- Filtres -->
    <div class="flex gap-2">
        <a href="/commercial/quotes" class="px-4 py-2 text-sm rounded-lg <?= ($filterStatus ?? 'all') === 'all' ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200' ?>">Tous</a>
        <a href="/commercial/quotes?status=draft" class="px-4 py-2 text-sm rounded-lg <?= ($filterStatus ?? '') === 'draft' ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200' ?>">Brouillon</a>
        <a href="/commercial/quotes?status=sent" class="px-4 py-2 text-sm rounded-lg <?= ($filterStatus ?? '') === 'sent' ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200' ?>">Envoyé</a>
        <a href="/commercial/quotes?status=accepted" class="px-4 py-2 text-sm rounded-lg <?= ($filterStatus ?? '') === 'accepted' ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200' ?>">Accepté</a>
        <a href="/commercial/quotes?status=rejected" class="px-4 py-2 text-sm rounded-lg <?= ($filterStatus ?? '') === 'rejected' ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200' ?>">Refusé</a>
        <a href="/commercial/quotes?status=expired" class="px-4 py-2 text-sm rounded-lg <?= ($filterStatus ?? '') === 'expired' ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200' ?>">Expiré</a>
    </div>

    <!-- Liste des devis -->
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <table class="w-full">
            <thead class="bg-gray-50">
                <tr>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Référence</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Client</th>
                    <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">Montant TTC</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Statut</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Date</th>
                    <th class="px-6 py-3"></th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-100">
                <?php foreach ($quotes as $quote): ?>
                <tr class="hover:bg-gray-50 transition">
                    <td class="px-6 py-4">
                        <a href="/commercial/quotes/<?= $quote['id'] ?>" class="text-sm font-medium text-blue-600 hover:underline">
                            <?= e($quote['reference']) ?>
                        </a>
                    </td>
                    <td class="px-6 py-4 text-sm text-gray-700"><?= e($quote['client_name'] ?? '—') ?></td>
                    <td class="px-6 py-4 text-sm text-right font-medium"><?= formatCurrency($quote['total_ttc'] ?? 0) ?></td>
                    <td class="px-6 py-4"><?= statusBadge($quote['status']) ?></td>
                    <td class="px-6 py-4 text-sm text-gray-500"><?= formatDate($quote['created_at'] ?? null) ?></td>
                    <td class="px-6 py-4 text-right">
                        <a href="/commercial/quotes/<?= $quote['id'] ?>/edit" class="text-gray-400 hover:text-blue-600">
                            <i class="fas fa-edit"></i>
                        </a>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php if (empty($quotes)): ?>
                <tr><td colspan="6" class="px-6 py-8 text-center text-gray-400">Aucun devis trouvé</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
