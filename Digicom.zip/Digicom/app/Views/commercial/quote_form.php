<div class="max-w-4xl mx-auto space-y-6">
    <h1 class="text-xl font-bold text-gray-900"><?= $quote ? 'Modifier le devis' : 'Nouveau devis' ?></h1>

    <form method="POST" action="<?= $quote ? '/commercial/quotes/' . $quote['id'] . '/edit' : '/commercial/quotes/create' ?>" class="bg-white rounded-xl shadow-sm border border-gray-100 p-6 space-y-6">
        <?= csrfField() ?>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Client</label>
                <select name="client_id" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm" required>
                    <option value="">— Sélectionner —</option>
                    <?php foreach ($clients as $client): ?>
                    <option value="<?= $client['id'] ?>" <?= ($quote['client_id'] ?? '') == $client['id'] ? 'selected' : '' ?>>
                        <?= e($client['company_name'] ?: $client['contact_name'] ?: 'Client #' . $client['id']) ?>
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Taux TVA (%)</label>
                <input type="number" name="tax_rate" value="<?= e($quote['tax_rate'] ?? 18) ?>" step="0.01" min="0" max="100" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm">
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Valide jusqu'au</label>
                <input type="date" name="valid_until" value="<?= e($quote['valid_until'] ?? '') ?>" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm">
            </div>
        </div>

        <!-- Lignes d'articles -->
        <div>
            <div class="flex items-center justify-between mb-3">
                <h3 class="text-sm font-semibold text-gray-700">Articles</h3>
                <button type="button" onclick="addItemRow()" class="px-3 py-1.5 text-xs bg-gray-100 text-gray-600 rounded-lg hover:bg-gray-200">
                    <i class="fas fa-plus mr-1"></i> Ajouter une ligne
                </button>
            </div>

            <div class="border border-gray-200 rounded-lg overflow-hidden">
                <table class="w-full" id="items-table">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase w-2/5">Description</th>
                            <th class="px-4 py-3 text-center text-xs font-medium text-gray-500 uppercase">Quantité</th>
                            <th class="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase">Prix unitaire</th>
                            <th class="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase">Total</th>
                            <th class="px-4 py-3 w-10"></th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-100">
                        <?php if (!empty($items)): ?>
                            <?php foreach ($items as $i => $item): ?>
                            <tr class="item-row">
                                <td class="px-4 py-2">
                                    <input type="text" name="items[<?= $i ?>][description]" value="<?= e($item['description']) ?>" placeholder="Description de l'article" class="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm" required>
                                </td>
                                <td class="px-4 py-2">
                                    <input type="number" name="items[<?= $i ?>][quantity]" value="<?= e($item['quantity']) ?>" min="1" step="1" class="w-20 text-center px-3 py-2 border border-gray-200 rounded-lg text-sm" onchange="recalcRow(this)" required>
                                </td>
                                <td class="px-4 py-2">
                                    <input type="number" name="items[<?= $i ?>][unit_price]" value="<?= e($item['unit_price'] ?? 0) ?>" min="0" step="0.01" class="w-28 text-right px-3 py-2 border border-gray-200 rounded-lg text-sm" onchange="recalcRow(this)" required>
                                </td>
                                <td class="px-4 py-2 text-right text-sm font-medium text-gray-700 row-total">
                                    <?= formatCurrency(($item['quantity'] ?? 0) * ($item['unit_price'] ?? 0)) ?>
                                </td>
                                <td class="px-4 py-2 text-center">
                                    <button type="button" onclick="removeItemRow(this)" class="text-red-400 hover:text-red-600">
                                        <i class="fas fa-times"></i>
                                    </button>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                        <tr class="item-row">
                            <td class="px-4 py-2">
                                <input type="text" name="items[0][description]" placeholder="Description de l'article" class="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm" required>
                            </td>
                            <td class="px-4 py-2">
                                <input type="number" name="items[0][quantity]" value="1" min="1" step="1" class="w-20 text-center px-3 py-2 border border-gray-200 rounded-lg text-sm" onchange="recalcRow(this)" required>
                            </td>
                            <td class="px-4 py-2">
                                <input type="number" name="items[0][unit_price]" value="0" min="0" step="0.01" class="w-28 text-right px-3 py-2 border border-gray-200 rounded-lg text-sm" onchange="recalcRow(this)" required>
                            </td>
                            <td class="px-4 py-2 text-right text-sm font-medium text-gray-700 row-total">0,00 €</td>
                            <td class="px-4 py-2 text-center">
                                <button type="button" onclick="removeItemRow(this)" class="text-red-400 hover:text-red-600">
                                    <i class="fas fa-times"></i>
                                </button>
                            </td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Notes</label>
            <textarea name="notes" rows="3" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"><?= e($quote['notes'] ?? '') ?></textarea>
        </div>

        <div class="flex gap-3">
            <button type="submit" class="px-6 py-2.5 bg-blue-600 text-white text-sm rounded-lg hover:bg-blue-700">
                <i class="fas fa-save mr-1"></i> <?= $quote ? 'Mettre à jour' : 'Enregistrer' ?>
            </button>
            <a href="/commercial/quotes" class="px-6 py-2.5 bg-gray-100 text-gray-600 text-sm rounded-lg hover:bg-gray-200">Annuler</a>
        </div>
    </form>
</div>

<script>
function recalcRow(el) {
    const row = el.closest('.item-row');
    const qty = parseFloat(row.querySelector('[name$="[quantity]"]').value) || 0;
    const price = parseFloat(row.querySelector('[name$="[unit_price]"]').value) || 0;
    const total = (qty * price).toFixed(2);
    row.querySelector('.row-total').textContent = total.replace('.', ',') + ' €';
}

function addItemRow() {
    const tbody = document.querySelector('#items-table tbody');
    const rows = tbody.querySelectorAll('.item-row');
    const idx = rows.length;
    const tr = document.createElement('tr');
    tr.className = 'item-row';
    tr.innerHTML = `
        <td class="px-4 py-2">
            <input type="text" name="items[${idx}][description]" placeholder="Description de l'article" class="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm" required>
        </td>
        <td class="px-4 py-2">
            <input type="number" name="items[${idx}][quantity]" value="1" min="1" step="1" class="w-20 text-center px-3 py-2 border border-gray-200 rounded-lg text-sm" onchange="recalcRow(this)" required>
        </td>
        <td class="px-4 py-2">
            <input type="number" name="items[${idx}][unit_price]" value="0" min="0" step="0.01" class="w-28 text-right px-3 py-2 border border-gray-200 rounded-lg text-sm" onchange="recalcRow(this)" required>
        </td>
        <td class="px-4 py-2 text-right text-sm font-medium text-gray-700 row-total">0,00 €</td>
        <td class="px-4 py-2 text-center">
            <button type="button" onclick="removeItemRow(this)" class="text-red-400 hover:text-red-600">
                <i class="fas fa-times"></i>
            </button>
        </td>
    `;
    tbody.appendChild(tr);
}

function removeItemRow(btn) {
    const row = btn.closest('.item-row');
    if (document.querySelectorAll('.item-row').length > 1) {
        row.remove();
        reindexItems();
    }
}

function reindexItems() {
    document.querySelectorAll('.item-row').forEach((row, i) => {
        row.querySelectorAll('[name]').forEach(input => {
            input.name = input.name.replace(/items\[\d+\]/, `items[${i}]`);
        });
    });
}
</script>
