<div class="space-y-6">
    <div class="flex items-center justify-between">
        <h1 class="text-xl font-bold text-gray-900">Créances clients</h1>
        <div class="flex gap-2">
            <a href="/commercial/receivables?export=1" class="px-4 py-2 text-sm bg-green-600 text-white rounded-lg hover:bg-green-700">
                <i class="fas fa-download mr-1"></i> Export
            </a>
        </div>
    </div>

    <!-- Résumé -->
    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div class="bg-white rounded-xl shadow-sm p-5 border border-gray-100">
            <p class="text-sm text-gray-500">Nombre de créances</p>
            <p class="text-2xl font-bold text-gray-900"><?= count($receivables ?? []) ?></p>
        </div>
        <div class="bg-white rounded-xl shadow-sm p-5 border border-gray-100">
            <p class="text-sm text-gray-500">Montant total dû</p>
            <?php
            $totalDue = 0;
            if (!empty($receivables)) {
                foreach ($receivables as $r) {
                    $totalDue += ($r['total_ttc'] ?? 0) - ($r['paid_amount'] ?? 0);
                }
            }
            ?>
            <p class="text-2xl font-bold text-red-600"><?= formatCurrency($totalDue) ?></p>
        </div>
        <div class="bg-white rounded-xl shadow-sm p-5 border border-gray-100">
            <p class="text-sm text-gray-500">Créances en retard</p>
            <?php
            $overdueCount = 0;
            $today = date('Y-m-d');
            if (!empty($receivables)) {
                foreach ($receivables as $r) {
                    if (!empty($r['due_date']) && $r['due_date'] < $today && ($r['status'] ?? '') !== 'paid') {
                        $overdueCount++;
                    }
                }
            }
            ?>
            <p class="text-2xl font-bold text-orange-600"><?= $overdueCount ?></p>
        </div>
    </div>

    <!-- Tableau des créances -->
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <table class="w-full">
            <thead class="bg-gray-50">
                <tr>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Référence</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Client</th>
                    <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">Montant TTC</th>
                    <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">Payé</th>
                    <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">Reste dû</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Échéance</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Statut</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-100">
                <?php foreach ($receivables as $receivable): ?>
                <?php
                $remaining = ($receivable['total_ttc'] ?? 0) - ($receivable['paid_amount'] ?? 0);
                $isOverdue = !empty($receivable['due_date']) && $receivable['due_date'] < date('Y-m-d') && ($receivable['status'] ?? '') !== 'paid';
                ?>
                <tr class="hover:bg-gray-50 transition <?= $isOverdue ? 'bg-red-50/30' : '' ?>">
                    <td class="px-6 py-4">
                        <a href="/commercial/invoices/<?= $receivable['id'] ?>" class="text-sm font-medium text-blue-600 hover:underline">
                            <?= e($receivable['reference']) ?>
                        </a>
                    </td>
                    <td class="px-6 py-4 text-sm text-gray-700"><?= e($receivable['client_name'] ?? '—') ?></td>
                    <td class="px-6 py-4 text-sm text-right"><?= formatCurrency($receivable['total_ttc'] ?? 0) ?></td>
                    <td class="px-6 py-4 text-sm text-right text-green-600"><?= formatCurrency($receivable['paid_amount'] ?? 0) ?></td>
                    <td class="px-6 py-4 text-sm text-right font-medium <?= $remaining > 0 ? 'text-red-600' : 'text-green-600' ?>">
                        <?= formatCurrency($remaining) ?>
                    </td>
                    <td class="px-6 py-4 text-sm <?= $isOverdue ? 'text-red-600 font-medium' : 'text-gray-500' ?>">
                        <?= formatDate($receivable['due_date'] ?? null) ?>
                        <?php if ($isOverdue): ?>
                        <span class="text-xs ml-1">(en retard)</span>
                        <?php endif; ?>
                    </td>
                    <td class="px-6 py-4">
                        <?= statusBadge($receivable['status']) ?>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php if (empty($receivables)): ?>
                <tr><td colspan="7" class="px-6 py-8 text-center text-gray-400">Aucune créance en cours</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
