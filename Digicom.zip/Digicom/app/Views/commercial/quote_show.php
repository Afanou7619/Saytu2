<div class="space-y-6">
    <div class="flex items-center justify-between">
        <div>
            <h1 class="text-xl font-bold text-gray-900">Devis <?= e($quote['reference']) ?></h1>
            <p class="text-sm text-gray-500">Créé le <?= formatDate($quote['created_at'] ?? null) ?></p>
        </div>
        <div class="flex gap-2">
            <a href="/commercial/quotes/<?= $quote['id'] ?>/edit" class="px-4 py-2 text-sm bg-blue-600 text-white rounded-lg hover:bg-blue-700">
                <i class="fas fa-edit mr-1"></i> Modifier
            </a>
            <a href="/commercial/quotes/<?= $quote['id'] ?>/convert" class="px-4 py-2 text-sm bg-green-600 text-white rounded-lg hover:bg-green-700">
                <i class="fas fa-file-invoice mr-1"></i> Convertir en facture
            </a>
            <a href="/commercial/quotes/<?= $quote['id'] ?>/pdf" class="px-4 py-2 text-sm bg-gray-100 text-gray-600 rounded-lg hover:bg-gray-200">
                <i class="fas fa-download mr-1"></i> PDF
            </a>
        </div>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
        <!-- Détails devis -->
        <div class="md:col-span-2 space-y-6">
            <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
                <div class="px-6 py-4 border-b border-gray-100">
                    <h3 class="text-sm font-semibold text-gray-700">Articles</h3>
                </div>
                <table class="w-full">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Description</th>
                            <th class="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase">Quantité</th>
                            <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">Prix unitaire</th>
                            <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">Total</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-100">
                        <?php foreach ($items as $item): ?>
                        <tr>
                            <td class="px-6 py-4 text-sm text-gray-700"><?= e($item['description']) ?></td>
                            <td class="px-6 py-4 text-sm text-center"><?= (int)$item['quantity'] ?></td>
                            <td class="px-6 py-4 text-sm text-right"><?= formatCurrency($item['unit_price'] ?? 0) ?></td>
                            <td class="px-6 py-4 text-sm text-right font-medium"><?= formatCurrency($item['total'] ?? 0) ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <?php if (!empty($quote['notes'])): ?>
            <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                <h3 class="text-sm font-semibold text-gray-700 mb-2">Notes</h3>
                <p class="text-sm text-gray-600"><?= nl2br(e($quote['notes'])) ?></p>
            </div>
            <?php endif; ?>
        </div>

        <!-- Infos latérales -->
        <div class="space-y-6">
            <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                <h3 class="text-sm font-semibold text-gray-700 mb-3">Statut</h3>
                <div class="mb-3"><?= statusBadge($quote['status']) ?></div>
                <p class="text-sm text-gray-500">Valide jusqu'au <?= formatDate($quote['valid_until'] ?? null) ?></p>
            </div>

            <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                <h3 class="text-sm font-semibold text-gray-700 mb-3">Client</h3>
                <?php if ($client): ?>
                <p class="text-sm font-medium text-gray-800"><?= e($client['company_name'] ?? $client['contact_name'] ?? '—') ?></p>
                <?php if (!empty($client['contact_name'])): ?>
                <p class="text-sm text-gray-500"><?= e($client['contact_name']) ?></p>
                <?php endif; ?>
                <?php if (!empty($client['email'])): ?>
                <p class="text-sm text-gray-500"><?= e($client['email']) ?></p>
                <?php endif; ?>
                <?php if (!empty($client['phone'])): ?>
                <p class="text-sm text-gray-500"><?= e($client['phone']) ?></p>
                <?php endif; ?>
                <?php if (!empty($client['address'])): ?>
                <p class="text-sm text-gray-500 mt-1"><?= e($client['address']) ?></p>
                <?php endif; ?>
                <?php else: ?>
                <p class="text-sm text-gray-400">Client inconnu</p>
                <?php endif; ?>
            </div>

            <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                <h3 class="text-sm font-semibold text-gray-700 mb-3">Totaux</h3>
                <dl class="space-y-2 text-sm">
                    <div class="flex justify-between">
                        <dt class="text-gray-500">Total HT</dt>
                        <dd class="font-medium"><?= formatCurrency($quote['total_ht'] ?? 0) ?></dd>
                    </div>
                    <div class="flex justify-between">
                        <dt class="text-gray-500">TVA (<?= e($quote['tax_rate'] ?? 18) ?>%)</dt>
                        <dd class="font-medium"><?= formatCurrency(($quote['total_ttc'] ?? 0) - ($quote['total_ht'] ?? 0)) ?></dd>
                    </div>
                    <div class="flex justify-between border-t border-gray-200 pt-2">
                        <dt class="font-semibold text-gray-700">Total TTC</dt>
                        <dd class="font-bold text-gray-900"><?= formatCurrency($quote['total_ttc'] ?? 0) ?></dd>
                    </div>
                </dl>
            </div>
        </div>
    </div>
</div>
