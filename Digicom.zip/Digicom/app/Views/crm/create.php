<div class="max-w-3xl mx-auto space-y-6">
    <h1 class="text-xl font-bold text-gray-900"><?= e($title) ?></h1>

    <form method="POST" action="<?= $client ? '/crm/clients/' . $client['id'] . '/edit' : '/crm/clients/create' ?>" class="bg-white rounded-xl shadow-sm border border-gray-100 p-6 space-y-4">
        <?= csrfField() ?>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Type</label>
                <select name="type" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm">
                    <option value="prospect" <?= ($client['type'] ?? '') === 'prospect' ? 'selected' : '' ?>>Prospect</option>
                    <option value="client" <?= ($client['type'] ?? '') === 'client' ? 'selected' : '' ?>>Client</option>
                    <option value="partenaire" <?= ($client['type'] ?? '') === 'partenaire' ? 'selected' : '' ?>>Partenaire</option>
                </select>
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Nom entreprise</label>
                <input type="text" name="company_name" value="<?= e($client['company_name'] ?? '') ?>" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm">
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Nom contact</label>
                <input type="text" name="contact_name" value="<?= e($client['contact_name'] ?? '') ?>" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm">
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Email</label>
                <input type="email" name="email" value="<?= e($client['email'] ?? '') ?>" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm">
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Téléphone</label>
                <input type="text" name="phone" value="<?= e($client['phone'] ?? '') ?>" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm">
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Segment</label>
                <select name="segment" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm">
                    <option value="">—</option>
                    <option value="PME" <?= ($client['segment'] ?? '') === 'PME' ? 'selected' : '' ?>>PME</option>
                    <option value="Grand compte" <?= ($client['segment'] ?? '') === 'Grand compte' ? 'selected' : '' ?>>Grand compte</option>
                    <option value="Startup" <?= ($client['segment'] ?? '') === 'Startup' ? 'selected' : '' ?>>Startup</option>
                    <option value="ONG" <?= ($client['segment'] ?? '') === 'ONG' ? 'selected' : '' ?>>ONG</option>
                    <option value="Public" <?= ($client['segment'] ?? '') === 'Public' ? 'selected' : '' ?>>Public</option>
                </select>
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Source</label>
                <input type="text" name="source" value="<?= e($client['source'] ?? '') ?>" placeholder="Recommandation, Site web..." class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm">
            </div>
            <?php if ($client): ?>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Pipeline</label>
                <select name="pipeline_stage" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm">
                    <?php foreach (['nouveau','contacte','devis_envoye','negociation','gagne','perdu'] as $s): ?>
                    <option value="<?= $s ?>" <?= ($client['pipeline_stage'] ?? '') === $s ? 'selected' : '' ?>><?= ucfirst(str_replace('_', ' ', $s)) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <?php endif; ?>
        </div>

        <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Adresse</label>
            <textarea name="address" rows="2" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"><?= e($client['address'] ?? '') ?></textarea>
        </div>

        <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Notes</label>
            <textarea name="notes" rows="3" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"><?= e($client['notes'] ?? '') ?></textarea>
        </div>

        <div class="flex gap-3">
            <button type="submit" class="px-6 py-2.5 bg-blue-600 text-white text-sm rounded-lg hover:bg-blue-700">
                <i class="fas fa-save mr-1"></i> Enregistrer
            </button>
            <a href="/crm/clients" class="px-6 py-2.5 bg-gray-100 text-gray-600 text-sm rounded-lg hover:bg-gray-200">Annuler</a>
        </div>
    </form>
</div>
