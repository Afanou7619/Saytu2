<div class="space-y-6">
    <div class="flex items-center justify-between">
        <h1 class="text-xl font-bold text-gray-900">CRM – Pipeline</h1>
        <div class="flex gap-2">
            <a href="/crm/clients" class="px-4 py-2 text-sm bg-gray-100 text-gray-600 rounded-lg hover:bg-gray-200">
                <i class="fas fa-list mr-1"></i> Liste
            </a>
            <a href="/crm/kanban" class="px-4 py-2 text-sm bg-blue-600 text-white rounded-lg">
                <i class="fas fa-columns mr-1"></i> Kanban
            </a>
            <a href="/crm/clients/create" class="px-4 py-2 text-sm bg-green-600 text-white rounded-lg hover:bg-green-700">
                <i class="fas fa-plus mr-1"></i> Nouveau
            </a>
        </div>
    </div>
    <div class="text-center py-12 text-gray-400">
        <p>Accédez à la <a href="/crm/clients" class="text-blue-600 hover:underline">liste des clients</a> ou au <a href="/crm/kanban" class="text-blue-600 hover:underline">pipeline Kanban</a></p>
    </div>
</div>
