<div class="space-y-6">
    <div class="flex items-center justify-between">
        <h1 class="text-xl font-bold text-gray-900">Pipeline CRM</h1>
        <a href="/crm/clients/create" class="px-4 py-2 text-sm bg-blue-600 text-white rounded-lg hover:bg-blue-700">
            <i class="fas fa-plus mr-1"></i> Nouveau prospect
        </a>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-4">
        <?php
        $stages = [
            'nouveau' => ['label' => 'Nouveau', 'color' => 'bg-gray-100'],
            'contacte' => ['label' => 'Contacté', 'color' => 'bg-blue-100'],
            'devis_envoye' => ['label' => 'Devis envoyé', 'color' => 'bg-yellow-100'],
            'negociation' => ['label' => 'Négociation', 'color' => 'bg-purple-100'],
            'gagne' => ['label' => 'Gagné', 'color' => 'bg-green-100'],
            'perdu' => ['label' => 'Perdu', 'color' => 'bg-red-100'],
        ];
        foreach ($stages as $stage => $config):
        ?>
        <div class="<?= $config['color'] ?> rounded-xl p-4 min-h-[200px]">
            <div class="flex items-center justify-between mb-3">
                <h3 class="text-sm font-semibold text-gray-700"><?= $config['label'] ?></h3>
                <span class="text-xs px-2 py-0.5 rounded-full bg-white/80 text-gray-600"><?= count($kanban[$stage] ?? []) ?></span>
            </div>
            <div class="space-y-2">
                <?php foreach ($kanban[$stage] ?? [] as $item): ?>
                <a href="/crm/clients/<?= $item['id'] ?>"
                   class="block bg-white p-3 rounded-lg shadow-sm border border-gray-200 hover:border-blue-300 transition text-sm">
                    <p class="font-medium text-gray-800"><?= e($item['company_name'] ?: $item['contact_name'] ?: 'Sans nom') ?></p>
                    <p class="text-gray-500 text-xs mt-1"><?= e($item['contact_name']) ?></p>
                    <?php if ($item['assigned_name']): ?>
                    <p class="text-gray-400 text-xs mt-1"><i class="fas fa-user mr-1"></i><?= e($item['assigned_name']) ?></p>
                    <?php endif; ?>
                </a>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</div>
