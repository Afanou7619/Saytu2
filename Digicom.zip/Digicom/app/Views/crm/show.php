<div class="space-y-6">
    <div class="flex items-center justify-between">
        <div>
            <h1 class="text-xl font-bold text-gray-900"><?= e($client['company_name'] ?: $client['contact_name'] ?: 'Client #' . $client['id']) ?></h1>
            <p class="text-sm text-gray-500"><?= e($client['type']) ?> · <?= e($client['segment'] ?? '') ?></p>
        </div>
        <div class="flex gap-2">
            <a href="/crm/clients/<?= $client['id'] ?>/edit" class="px-4 py-2 text-sm bg-blue-600 text-white rounded-lg hover:bg-blue-700">
                <i class="fas fa-edit mr-1"></i> Modifier
            </a>
            <form method="POST" action="/crm/clients/<?= $client['id'] ?>/delete" onsubmit="return confirm('Confirmer la suppression ?')">
                <?= csrfField() ?>
                <button type="submit" class="px-4 py-2 text-sm bg-red-600 text-white rounded-lg hover:bg-red-700">
                    <i class="fas fa-trash mr-1"></i> Supprimer
                </button>
            </form>
        </div>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div class="md:col-span-2 space-y-6">
            <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                <h3 class="text-sm font-semibold text-gray-700 mb-3">Informations</h3>
                <dl class="grid grid-cols-2 gap-3 text-sm">
                    <dt class="text-gray-500">Contact</dt><dd class="text-gray-800"><?= e($client['contact_name'] ?: '—') ?></dd>
                    <dt class="text-gray-500">Email</dt><dd class="text-gray-800"><?= e($client['email'] ?: '—') ?></dd>
                    <dt class="text-gray-500">Téléphone</dt><dd class="text-gray-800"><?= e($client['phone'] ?: '—') ?></dd>
                    <dt class="text-gray-500">Adresse</dt><dd class="text-gray-800"><?= e($client['address'] ?: '—') ?></dd>
                    <dt class="text-gray-500">Source</dt><dd class="text-gray-800"><?= e($client['source'] ?: '—') ?></dd>
                    <dt class="text-gray-500">Statut</dt><dd><?= statusBadge($client['pipeline_stage'] ?? $client['status']) ?></dd>
                </dl>
            </div>

            <?php if (!empty($projects)): ?>
            <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                <h3 class="text-sm font-semibold text-gray-700 mb-3">Projets (<?= count($projects) ?>)</h3>
                <div class="space-y-2">
                    <?php foreach ($projects as $p): ?>
                    <a href="/projects/<?= $p['id'] ?>" class="flex items-center justify-between py-2 px-3 rounded-lg hover:bg-gray-50 text-sm">
                        <span class="text-blue-600"><?= e($p['title']) ?></span>
                        <?= statusBadge($p['status']) ?>
                    </a>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>
        </div>

        <div class="space-y-6">
            <?php if (!empty($quotes)): ?>
            <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                <h3 class="text-sm font-semibold text-gray-700 mb-3">Devis (<?= count($quotes) ?>)</h3>
                <div class="space-y-2">
                    <?php foreach (array_slice($quotes, 0, 5) as $q): ?>
                    <a href="/commercial/quotes/<?= $q['id'] ?>" class="block text-sm text-blue-600 hover:underline">
                        <?= e($q['reference']) ?> – <?= formatCurrency($q['total_ttc'] ?? 0) ?>
                    </a>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>

            <?php if (!empty($invoices)): ?>
            <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                <h3 class="text-sm font-semibold text-gray-700 mb-3">Factures (<?= count($invoices) ?>)</h3>
                <div class="space-y-2">
                    <?php foreach (array_slice($invoices, 0, 5) as $inv): ?>
                    <a href="/commercial/invoices/<?= $inv['id'] ?>" class="block text-sm">
                        <span class="text-blue-600"><?= e($inv['reference']) ?></span>
                        <span class="text-gray-500 ml-2"><?= formatCurrency($inv['total_ttc'] ?? 0) ?></span>
                        <?= statusBadge($inv['status']) ?>
                    </a>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>
