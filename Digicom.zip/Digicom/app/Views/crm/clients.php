<div class="space-y-6">
    <div class="flex items-center justify-between">
        <div class="flex gap-2">
            <a href="/crm/clients" class="px-4 py-2 text-sm rounded-lg <?= ($filterType ?? 'all') === 'all' ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200' ?>">Tous</a>
            <a href="/crm/clients?type=client" class="px-4 py-2 text-sm rounded-lg <?= ($filterType ?? '') === 'client' ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200' ?>">Clients</a>
            <a href="/crm/clients?type=prospect" class="px-4 py-2 text-sm rounded-lg <?= ($filterType ?? '') === 'prospect' ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200' ?>">Prospects</a>
            <a href="/crm/kanban" class="px-4 py-2 text-sm rounded-lg bg-gray-100 text-gray-600 hover:bg-gray-200">
                <i class="fas fa-columns mr-1"></i> Kanban
            </a>
        </div>
        <div class="flex gap-2">
            <a href="/crm/export" class="px-4 py-2 text-sm bg-green-600 text-white rounded-lg hover:bg-green-700">
                <i class="fas fa-download mr-1"></i> Export
            </a>
            <a href="/crm/clients/create" class="px-4 py-2 text-sm bg-blue-600 text-white rounded-lg hover:bg-blue-700">
                <i class="fas fa-plus mr-1"></i> Nouveau
            </a>
        </div>
    </div>

    <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <table class="w-full">
            <thead class="bg-gray-50">
                <tr>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Entreprise</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Contact</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Email</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Type</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Statut</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Créé le</th>
                    <th class="px-6 py-3"></th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-100">
                <?php foreach ($clients['items'] as $client): ?>
                <tr class="hover:bg-gray-50 transition">
                    <td class="px-6 py-4">
                        <a href="/crm/clients/<?= $client['id'] ?>" class="text-sm font-medium text-blue-600 hover:underline">
                            <?= e($client['company_name'] ?: 'Sans entreprise') ?>
                        </a>
                    </td>
                    <td class="px-6 py-4 text-sm text-gray-700"><?= e($client['contact_name']) ?></td>
                    <td class="px-6 py-4 text-sm text-gray-500"><?= e($client['email']) ?></td>
                    <td class="px-6 py-4"><?= statusBadge($client['type']) ?></td>
                    <td class="px-6 py-4"><?= statusBadge($client['pipeline_stage'] ?? $client['status']) ?></td>
                    <td class="px-6 py-4 text-sm text-gray-500"><?= formatDate($client['created_at']) ?></td>
                    <td class="px-6 py-4 text-right">
                        <a href="/crm/clients/<?= $client['id'] ?>/edit" class="text-gray-400 hover:text-blue-600">
                            <i class="fas fa-edit"></i>
                        </a>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php if (empty($clients['items'])): ?>
                <tr><td colspan="7" class="px-6 py-8 text-center text-gray-400">Aucun client trouvé</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Pagination -->
    <?php if ($clients['last_page'] > 1): ?>
    <div class="flex items-center justify-center gap-2">
        <?php for ($i = 1; $i <= $clients['last_page']; $i++): ?>
        <a href="?page=<?= $i ?>" class="px-3 py-1.5 text-sm rounded-lg <?= $clients['page'] === $i ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200' ?>">
            <?= $i ?>
        </a>
        <?php endfor; ?>
    </div>
    <?php endif; ?>
</div>
