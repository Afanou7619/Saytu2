<div class="max-w-2xl mx-auto">
    <div class="mb-6 flex items-center justify-between">
        <div>
            <h3 class="text-xl font-semibold text-gray-800">Téléverser un document</h3>
            <p class="text-sm text-gray-500 mt-1">Ajoutez un nouveau document à la bibliothèque</p>
        </div>
        <a href="/documents" class="text-sm text-primary hover:underline">
            <i class="fas fa-arrow-left mr-1"></i> Retour
        </a>
    </div>

    <form action="/documents/upload" method="POST" enctype="multipart/form-data"
        class="bg-white rounded-xl shadow-sm border border-gray-200 p-6 space-y-6">
        <?= csrfField() ?>

        <!-- Titre -->
        <div>
            <label for="title" class="block text-sm font-medium text-gray-700 mb-1">Titre <span class="text-red-500">*</span></label>
            <input type="text" name="title" id="title" value="<?= e(old('title')) ?>" required
                class="w-full border border-gray-300 rounded-lg px-4 py-2.5 text-sm focus:ring-2 focus:ring-primary focus:border-primary outline-none"
                placeholder="Titre du document">
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <!-- Catégorie -->
            <div>
                <label for="category" class="block text-sm font-medium text-gray-700 mb-1">Catégorie <span class="text-red-500">*</span></label>
                <select name="category" id="category" required
                    class="w-full border border-gray-300 rounded-lg px-4 py-2.5 text-sm focus:ring-2 focus:ring-primary focus:border-primary outline-none bg-white">
                    <option value="">-- Sélectionner --</option>
                    <?php
                    $categories = [
                        'contract'   => 'Contrat',
                        'procedure'  => 'Procédure',
                        'policy'     => 'Politique',
                        'template'   => 'Modèle',
                        'report'     => 'Rapport',
                        'media'      => 'Média',
                        'other'      => 'Autre',
                    ];
                    foreach ($categories as $val => $label):
                    ?>
                    <option value="<?= $val ?>" <?= old('category') === $val ? 'selected' : '' ?>><?= $label ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <!-- Niveau d'accès -->
            <div>
                <label for="access_level" class="block text-sm font-medium text-gray-700 mb-1">Niveau d'accès <span class="text-red-500">*</span></label>
                <select name="access_level" id="access_level" required
                    class="w-full border border-gray-300 rounded-lg px-4 py-2.5 text-sm focus:ring-2 focus:ring-primary focus:border-primary outline-none bg-white">
                    <option value="">-- Sélectionner --</option>
                    <?php
                    $levels = [
                        'public'        => 'Public',
                        'internal'      => 'Interne',
                        'restricted'    => 'Restreint',
                        'confidential'  => 'Confidentiel',
                    ];
                    foreach ($levels as $val => $label):
                    ?>
                    <option value="<?= $val ?>" <?= old('access_level') === $val ? 'selected' : '' ?>><?= $label ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>

        <!-- Projet lié -->
        <div>
            <label for="project_id" class="block text-sm font-medium text-gray-700 mb-1">Projet lié</label>
            <select name="project_id" id="project_id"
                class="w-full border border-gray-300 rounded-lg px-4 py-2.5 text-sm focus:ring-2 focus:ring-primary focus:border-primary outline-none bg-white">
                <option value="">-- Aucun --</option>
                <?php foreach ($projects as $project): ?>
                <option value="<?= e($project['id']) ?>" <?= old('project_id') == $project['id'] ? 'selected' : '' ?>>
                    <?= e($project['title']) ?>
                </option>
                <?php endforeach; ?>
            </select>
        </div>

        <!-- Fichier -->
        <div>
            <label for="file" class="block text-sm font-medium text-gray-700 mb-1">Fichier <span class="text-red-500">*</span></label>
            <div class="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-primary transition cursor-pointer"
                onclick="document.getElementById('file').click()">
                <input type="file" name="file" id="file" required
                    class="hidden"
                    onchange="document.getElementById('file-name').textContent = this.files[0]?.name || 'Cliquez ou glissez-déposez un fichier'">
                <i class="fas fa-cloud-upload-alt text-3xl text-gray-400 mb-3"></i>
                <p id="file-name" class="text-sm text-gray-500">Cliquez ou glissez-déposez un fichier</p>
                <p class="text-xs text-gray-400 mt-1">PDF, DOCX, XLSX, PPTX, images (max 20 Mo)</p>
            </div>
        </div>

        <div class="flex items-center justify-end gap-3 pt-4 border-t border-gray-100">
            <a href="/documents" class="px-4 py-2.5 text-sm text-gray-600 hover:text-gray-800 border border-gray-300 rounded-lg hover:bg-gray-50 transition">
                Annuler
            </a>
            <button type="submit" class="px-6 py-2.5 bg-primary text-white text-sm font-medium rounded-lg hover:bg-blue-700 transition">
                <i class="fas fa-upload mr-2"></i> Téléverser
            </button>
        </div>
    </form>
</div>
