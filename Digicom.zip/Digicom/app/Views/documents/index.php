<div class="space-y-6">
    <div class="flex items-center justify-between">
        <h1 class="text-xl font-bold text-gray-900">Gestion Documentaire</h1>
        <div class="flex gap-2">
            <form method="GET" class="flex">
                <input type="text" name="search" value="<?= e($search ?? '') ?>" placeholder="Rechercher..."
                       class="px-3 py-2 border border-gray-300 rounded-l-lg text-sm focus:ring-2 focus:ring-blue-500">
                <button type="submit" class="px-4 py-2 bg-blue-600 text-white rounded-r-lg text-sm hover:bg-blue-700">
                    <i class="fas fa-search"></i>
                </button>
            </form>
            <a href="/documents/upload" class="px-4 py-2 text-sm bg-green-600 text-white rounded-lg hover:bg-green-700">
                <i class="fas fa-upload mr-1"></i> Upload
            </a>
        </div>
    </div>

    <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <table class="w-full">
            <thead class="bg-gray-50">
                <tr>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Titre</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Catégorie</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Type</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Taille</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Accès</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Date</th>
                    <th class="px-6 py-3"></th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-100">
                <?php foreach ($documents as $doc): ?>
                <tr class="hover:bg-gray-50">
                    <td class="px-6 py-4">
                        <a href="/documents/<?= $doc['id'] ?>/download" class="text-sm font-medium text-blue-600">
                            <i class="fas fa-file mr-2"></i><?= e($doc['title']) ?>
                        </a>
                    </td>
                    <td class="px-6 py-4 text-sm"><?= e($doc['category']) ?></td>
                    <td class="px-6 py-4 text-sm text-gray-500"><?= e($doc['file_type']) ?></td>
                    <td class="px-6 py-4 text-sm text-gray-500"><?= $doc['file_size'] ? number_format($doc['file_size'] / 1024, 1) . ' KB' : '—' ?></td>
                    <td class="px-6 py-4"><?= statusBadge($doc['access_level']) ?></td>
                    <td class="px-6 py-4 text-sm text-gray-500"><?= formatDate($doc['created_at']) ?></td>
                    <td class="px-6 py-4 text-right">
                        <button onclick="if(confirm('Supprimer ?')){this.closest('form').submit()}" class="text-red-400 hover:text-red-600">
                            <i class="fas fa-trash"></i>
                        </button>
                        <form method="POST" action="/documents/<?= $doc['id'] ?>/delete" class="hidden">
                            <?= csrfField() ?>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php if (empty($documents)): ?>
                <tr><td colspan="7" class="px-6 py-8 text-center text-gray-400">Aucun document trouvé</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
