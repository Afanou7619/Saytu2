<?php
$categories = [
    'contract'   => 'Contrat',
    'procedure'  => 'Procédure',
    'policy'     => 'Politique',
    'template'   => 'Modèle',
    'report'     => 'Rapport',
    'media'      => 'Média',
    'other'      => 'Autre',
];
$levels = [
    'public'        => 'Public',
    'internal'      => 'Interne',
    'restricted'    => 'Restreint',
    'confidential'  => 'Confidentiel',
];
$levelColors = [
    'public'        => 'bg-green-100 text-green-700',
    'internal'      => 'bg-blue-100 text-blue-700',
    'restricted'    => 'bg-yellow-100 text-yellow-700',
    'confidential'  => 'bg-red-100 text-red-700',
];
?>

<div class="max-w-3xl mx-auto">
    <!-- En-tête -->
    <div class="mb-6 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div class="flex items-center gap-3">
            <a href="/documents" class="text-gray-400 hover:text-gray-600">
                <i class="fas fa-arrow-left"></i>
            </a>
            <div>
                <h3 class="text-xl font-semibold text-gray-800"><?= e($document['title']) ?></h3>
                <p class="text-sm text-gray-500 mt-1">
                    <?= $categories[$document['category']] ?? e($document['category']) ?>
                </p>
            </div>
        </div>
        <div class="flex items-center gap-3">
            <a href="/documents/<?= e($document['id']) ?>/download"
                class="px-4 py-2 text-sm bg-primary text-white rounded-lg hover:bg-blue-700 transition">
                <i class="fas fa-download mr-2"></i> Télécharger
            </a>
            <form action="/documents/<?= e($document['id']) ?>/delete" method="POST"
                onsubmit="return confirm('Supprimer définitivement ce document ?')">
                <?= csrfField() ?>
                <button type="submit"
                    class="px-4 py-2 text-sm bg-red-50 text-red-600 border border-red-200 rounded-lg hover:bg-red-100 transition">
                    <i class="fas fa-trash mr-2"></i> Supprimer
                </button>
            </form>
        </div>
    </div>

    <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <!-- Aperçu / Meta -->
        <div class="flex flex-col sm:flex-row gap-6 mb-6">
            <!-- Icône du type -->
            <div class="flex-shrink-0 w-24 h-24 bg-gray-100 rounded-xl flex items-center justify-center">
                <i class="fas fa-file-pdf text-4xl text-gray-400"></i>
            </div>

            <div class="flex-1 grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                    <dt class="text-xs text-gray-500 uppercase">Catégorie</dt>
                    <dd class="text-sm font-medium text-gray-800"><?= $categories[$document['category']] ?? e($document['category']) ?></dd>
                </div>
                <div>
                    <dt class="text-xs text-gray-500 uppercase">Niveau d'accès</dt>
                    <dd>
                        <span class="inline-block px-2 py-0.5 text-xs font-medium rounded-full <?= $levelColors[$document['access_level']] ?? 'bg-gray-100 text-gray-600' ?>">
                            <?= $levels[$document['access_level']] ?? e($document['access_level']) ?>
                        </span>
                    </dd>
                </div>
                <div>
                    <dt class="text-xs text-gray-500 uppercase">Projet lié</dt>
                    <dd class="text-sm font-medium text-gray-800"><?= e($document['project_title'] ?? '—') ?></dd>
                </div>
                <div>
                    <dt class="text-xs text-gray-500 uppercase">Taille</dt>
                    <dd class="text-sm font-medium text-gray-800"><?= e($document['file_size'] ?? '—') ?></dd>
                </div>
                <div>
                    <dt class="text-xs text-gray-500 uppercase">Type MIME</dt>
                    <dd class="text-sm text-gray-600"><?= e($document['mime_type'] ?? '—') ?></dd>
                </div>
                <div>
                    <dt class="text-xs text-gray-500 uppercase">Téléversé par</dt>
                    <dd class="text-sm font-medium text-gray-800"><?= e($document['uploader_name'] ?? '—') ?></dd>
                </div>
                <div>
                    <dt class="text-xs text-gray-500 uppercase">Date de téléversement</dt>
                    <dd class="text-sm text-gray-600"><?= formatDateTime($document['created_at']) ?></dd>
                </div>
                <div>
                    <dt class="text-xs text-gray-500 uppercase">Dernière modification</dt>
                    <dd class="text-sm text-gray-600"><?= formatDateTime($document['updated_at']) ?></dd>
                </div>
            </div>
        </div>

        <?php if (!empty($document['description'])): ?>
        <div class="pt-4 border-t border-gray-100">
            <h5 class="text-xs font-semibold text-gray-500 uppercase mb-2">Description</h5>
            <p class="text-sm text-gray-700"><?= e($document['description']) ?></p>
        </div>
        <?php endif; ?>
    </div>
</div>
