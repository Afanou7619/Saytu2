<?php
$statusFilter = $_GET['status'] ?? '';
$typeLabels = [
    'computer'    => 'Ordinateur',
    'phone'       => 'Téléphone',
    'tablet'      => 'Tablette',
    'printer'     => 'Imprimante',
    'monitor'     => 'Écran',
    'furniture'   => 'Mobilier',
    'tool'        => 'Outil',
    'other'       => 'Autre',
];
?>

<div class="max-w-6xl mx-auto">
    <div class="mb-6 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
            <h3 class="text-xl font-semibold text-gray-800">Équipements</h3>
            <p class="text-sm text-gray-500 mt-1"><?= count($equipments) ?> équipement(s)</p>
        </div>
        <a href="/stock/equipments/create" class="inline-flex items-center px-4 py-2.5 bg-primary text-white text-sm font-medium rounded-lg hover:bg-blue-700 transition">
            <i class="fas fa-plus mr-2"></i> Nouvel équipement
        </a>
    </div>

    <!-- Filtre statut -->
    <div class="mb-4 flex items-center gap-2 flex-wrap">
        <span class="text-xs text-gray-500 mr-2">Filtrer :</span>
        <?php
        $statuses = [
            ''          => 'Tous',
            'available' => 'Disponible',
            'assigned'  => 'Assigné',
            'maintenance' => 'En maintenance',
            'retired'   => 'Retiré',
        ];
        foreach ($statuses as $val => $label):
            $active = $statusFilter === $val ? 'bg-primary text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200';
        ?>
        <a href="?status=<?= $val ?>"
            class="px-3 py-1.5 text-xs font-medium rounded-full <?= $active ?> transition">
            <?= $label ?>
        </a>
        <?php endforeach; ?>
    </div>

    <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
        <?php if (empty($equipments)): ?>
        <div class="p-12 text-center text-gray-400">
            <i class="fas fa-box-open text-4xl mb-3"></i>
            <p class="text-sm">Aucun équipement trouvé.</p>
        </div>
        <?php else: ?>
        <div class="overflow-x-auto">
            <table class="w-full text-sm">
                <thead>
                    <tr class="bg-gray-50 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">
                        <th class="px-6 py-3">Nom</th>
                        <th class="px-6 py-3">Type</th>
                        <th class="px-6 py-3">N° Série</th>
                        <th class="px-6 py-3">Statut</th>
                        <th class="px-6 py-3">Assigné à</th>
                        <th class="px-6 py-3 w-16"></th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-100">
                    <?php foreach ($equipments as $equipment): ?>
                    <tr class="hover:bg-gray-50 transition">
                        <td class="px-6 py-4">
                            <a href="/stock/equipments/<?= e($equipment['id']) ?>" class="font-medium text-gray-800 hover:text-primary transition">
                                <?= e($equipment['name']) ?>
                            </a>
                        </td>
                        <td class="px-6 py-4 text-gray-600"><?= $typeLabels[$equipment['type']] ?? e($equipment['type']) ?></td>
                        <td class="px-6 py-4 text-gray-500 font-mono text-xs"><?= e($equipment['serial_number']) ?: '—' ?></td>
                        <td class="px-6 py-4"><?= statusBadge($equipment['status']) ?></td>
                        <td class="px-6 py-4 text-gray-600"><?= e($equipment['assigned_to_name'] ?? '—') ?></td>
                        <td class="px-6 py-4">
                            <a href="/stock/equipments/<?= e($equipment['id']) ?>" class="text-gray-400 hover:text-primary">
                                <i class="fas fa-chevron-right"></i>
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>
    </div>
</div>
