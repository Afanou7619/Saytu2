<div class="max-w-2xl mx-auto">
    <div class="mb-6 flex items-center justify-between">
        <div>
            <h3 class="text-xl font-semibold text-gray-800">Nouvel équipement</h3>
            <p class="text-sm text-gray-500 mt-1">Ajoutez un équipement à l'inventaire</p>
        </div>
        <a href="/stock/equipments" class="text-sm text-primary hover:underline">
            <i class="fas fa-arrow-left mr-1"></i> Retour
        </a>
    </div>

    <form action="/stock/equipments/create" method="POST" class="bg-white rounded-xl shadow-sm border border-gray-200 p-6 space-y-6">
        <?= csrfField() ?>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <!-- Nom -->
            <div class="md:col-span-2">
                <label for="name" class="block text-sm font-medium text-gray-700 mb-1">Nom <span class="text-red-500">*</span></label>
                <input type="text" name="name" id="name" value="<?= e(old('name')) ?>" required
                    class="w-full border border-gray-300 rounded-lg px-4 py-2.5 text-sm focus:ring-2 focus:ring-primary focus:border-primary outline-none"
                    placeholder="Nom de l'équipement">
            </div>

            <!-- Type -->
            <div>
                <label for="type" class="block text-sm font-medium text-gray-700 mb-1">Type <span class="text-red-500">*</span></label>
                <select name="type" id="type" required
                    class="w-full border border-gray-300 rounded-lg px-4 py-2.5 text-sm focus:ring-2 focus:ring-primary focus:border-primary outline-none bg-white">
                    <option value="">-- Sélectionner --</option>
                    <?php
                    $types = [
                        'computer'   => 'Ordinateur',
                        'phone'      => 'Téléphone',
                        'tablet'     => 'Tablette',
                        'printer'    => 'Imprimante',
                        'monitor'    => 'Écran',
                        'furniture'  => 'Mobilier',
                        'tool'       => 'Outil',
                        'other'      => 'Autre',
                    ];
                    foreach ($types as $val => $label):
                    ?>
                    <option value="<?= $val ?>" <?= old('type') === $val ? 'selected' : '' ?>><?= $label ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <!-- N° série -->
            <div>
                <label for="serial_number" class="block text-sm font-medium text-gray-700 mb-1">N° de série</label>
                <input type="text" name="serial_number" id="serial_number" value="<?= e(old('serial_number')) ?>"
                    class="w-full border border-gray-300 rounded-lg px-4 py-2.5 text-sm focus:ring-2 focus:ring-primary focus:border-primary outline-none font-mono"
                    placeholder="Numéro de série">
            </div>

            <!-- Date d'achat -->
            <div>
                <label for="purchase_date" class="block text-sm font-medium text-gray-700 mb-1">Date d'achat</label>
                <input type="date" name="purchase_date" id="purchase_date" value="<?= e(old('purchase_date')) ?>"
                    class="w-full border border-gray-300 rounded-lg px-4 py-2.5 text-sm focus:ring-2 focus:ring-primary focus:border-primary outline-none">
            </div>

            <!-- Valeur -->
            <div>
                <label for="value" class="block text-sm font-medium text-gray-700 mb-1">Valeur</label>
                <input type="number" name="value" id="value" value="<?= e(old('value')) ?>" min="0" step="0.01"
                    class="w-full border border-gray-300 rounded-lg px-4 py-2.5 text-sm focus:ring-2 focus:ring-primary focus:border-primary outline-none"
                    placeholder="Valeur en FCFA">
            </div>
        </div>

        <!-- Notes -->
        <div>
            <label for="notes" class="block text-sm font-medium text-gray-700 mb-1">Notes</label>
            <textarea name="notes" id="notes" rows="3"
                class="w-full border border-gray-300 rounded-lg px-4 py-2.5 text-sm focus:ring-2 focus:ring-primary focus:border-primary outline-none"
                placeholder="Notes ou observations..."><?= e(old('notes')) ?></textarea>
        </div>

        <div class="flex items-center justify-end gap-3 pt-4 border-t border-gray-100">
            <a href="/stock/equipments" class="px-4 py-2.5 text-sm text-gray-600 hover:text-gray-800 border border-gray-300 rounded-lg hover:bg-gray-50 transition">
                Annuler
            </a>
            <button type="submit" class="px-6 py-2.5 bg-primary text-white text-sm font-medium rounded-lg hover:bg-blue-700 transition">
                <i class="fas fa-save mr-2"></i> Enregistrer
            </button>
        </div>
    </form>
</div>
