<div class="space-y-6">
    <div class="flex items-center justify-between">
        <h1 class="text-xl font-bold text-gray-900">Stock & Équipements</h1>
        <a href="/stock/equipments/create" class="px-4 py-2 text-sm bg-blue-600 text-white rounded-lg hover:bg-blue-700">
            <i class="fas fa-plus mr-1"></i> Nouvel équipement
        </a>
    </div>

    <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div class="bg-white rounded-xl shadow-sm p-5 border border-gray-100 text-center">
            <p class="text-2xl font-bold text-gray-900"><?= $stats['total'] ?? 0 ?></p>
            <p class="text-xs text-gray-500">Total</p>
        </div>
        <div class="bg-white rounded-xl shadow-sm p-5 border border-gray-100 text-center">
            <p class="text-2xl font-bold text-green-600"><?= $stats['available'] ?? 0 ?></p>
            <p class="text-xs text-gray-500">Disponibles</p>
        </div>
        <div class="bg-white rounded-xl shadow-sm p-5 border border-gray-100 text-center">
            <p class="text-2xl font-bold text-blue-600"><?= $stats['assigned'] ?? 0 ?></p>
            <p class="text-xs text-gray-500">Assignés</p>
        </div>
        <div class="bg-white rounded-xl shadow-sm p-5 border border-gray-100 text-center">
            <p class="text-2xl font-bold text-orange-600"><?= $stats['maintenance'] ?? 0 ?></p>
            <p class="text-xs text-gray-500">En maintenance</p>
        </div>
    </div>

    <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <table class="w-full">
            <thead class="bg-gray-50">
                <tr>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Nom</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Type</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">N° Série</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Assigné à</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Statut</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-100">
                <?php foreach ($equipments as $eq): ?>
                <tr class="hover:bg-gray-50">
                    <td class="px-6 py-4">
                        <a href="/stock/equipments/<?= $eq['id'] ?>" class="text-sm font-medium text-blue-600"><?= e($eq['name']) ?></a>
                    </td>
                    <td class="px-6 py-4 text-sm"><?= e($eq['type']) ?></td>
                    <td class="px-6 py-4 text-sm text-gray-500"><?= e($eq['serial_number']) ?></td>
                    <td class="px-6 py-4 text-sm"><?= e($eq['assigned_name'] ?? '—') ?></td>
                    <td class="px-6 py-4"><?= statusBadge($eq['status']) ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
