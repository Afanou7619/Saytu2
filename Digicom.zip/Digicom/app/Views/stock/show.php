<?php
$typeLabels = [
    'computer'    => 'Ordinateur',
    'phone'       => 'Téléphone',
    'tablet'      => 'Tablette',
    'printer'     => 'Imprimante',
    'monitor'     => 'Écran',
    'furniture'   => 'Mobilier',
    'tool'        => 'Outil',
    'other'       => 'Autre',
];
$isAssigned = ($equipment['status'] ?? '') === 'assigned';
?>

<div class="max-w-3xl mx-auto">
    <!-- En-tête -->
    <div class="mb-6 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div class="flex items-center gap-3">
            <a href="/stock/equipments" class="text-gray-400 hover:text-gray-600">
                <i class="fas fa-arrow-left"></i>
            </a>
            <div>
                <h3 class="text-xl font-semibold text-gray-800"><?= e($equipment['name']) ?></h3>
                <p class="text-sm text-gray-500 mt-1">
                    <?= $typeLabels[$equipment['type']] ?? e($equipment['type']) ?>
                    &middot; <?= statusBadge($equipment['status']) ?>
                </p>
            </div>
        </div>
        <a href="/stock/equipments/<?= e($equipment['id']) ?>/edit"
            class="px-4 py-2 text-sm bg-primary text-white rounded-lg hover:bg-blue-700 transition">
            <i class="fas fa-edit mr-2"></i> Modifier
        </a>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
        <!-- Détails équipement -->
        <div class="md:col-span-2 bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <h4 class="text-sm font-semibold text-gray-500 uppercase tracking-wider mb-4">Détails</h4>
            <dl class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                    <dt class="text-xs text-gray-500">Nom</dt>
                    <dd class="text-sm font-medium text-gray-800"><?= e($equipment['name']) ?></dd>
                </div>
                <div>
                    <dt class="text-xs text-gray-500">Type</dt>
                    <dd class="text-sm font-medium text-gray-800"><?= $typeLabels[$equipment['type']] ?? e($equipment['type']) ?></dd>
                </div>
                <div>
                    <dt class="text-xs text-gray-500">N° de série</dt>
                    <dd class="text-sm font-mono text-gray-800"><?= e($equipment['serial_number']) ?: '—' ?></dd>
                </div>
                <div>
                    <dt class="text-xs text-gray-500">Statut</dt>
                    <dd class="text-sm"><?= statusBadge($equipment['status']) ?></dd>
                </div>
                <div>
                    <dt class="text-xs text-gray-500">Date d'achat</dt>
                    <dd class="text-sm text-gray-800"><?= formatDate($equipment['purchase_date']) ?></dd>
                </div>
                <div>
                    <dt class="text-xs text-gray-500">Valeur</dt>
                    <dd class="text-sm font-medium text-gray-800"><?= $equipment['value'] ? formatCurrency((float)$equipment['value']) : '—' ?></dd>
                </div>
                <?php if ($isAssigned): ?>
                <div class="sm:col-span-2">
                    <dt class="text-xs text-gray-500">Assigné à</dt>
                    <dd class="text-sm font-medium text-gray-800"><?= e($equipment['assigned_to_name'] ?? '—') ?></dd>
                </div>
                <?php endif; ?>
            </dl>

            <?php if (!empty($equipment['notes'])): ?>
            <div class="mt-5 pt-4 border-t border-gray-100">
                <h5 class="text-xs font-semibold text-gray-500 uppercase mb-2">Notes</h5>
                <p class="text-sm text-gray-700 whitespace-pre-wrap"><?= e($equipment['notes']) ?></p>
            </div>
            <?php endif; ?>
        </div>

        <!-- Assignation -->
        <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-5">
            <h4 class="text-sm font-semibold text-gray-500 uppercase tracking-wider mb-4">
                <?= $isAssigned ? 'Retour / Réassigner' : 'Assigner' ?>
            </h4>

            <?php if ($isAssigned): ?>
            <!-- Retour -->
            <form action="/stock/equipments/<?= e($equipment['id']) ?>/return" method="POST" class="mb-5">
                <?= csrfField() ?>
                <button type="submit"
                    onclick="return confirm('Confirmer le retour de cet équipement ?')"
                    class="w-full px-4 py-2 text-sm bg-yellow-50 text-yellow-700 border border-yellow-200 rounded-lg hover:bg-yellow-100 transition">
                    <i class="fas fa-undo mr-2"></i> Marquer comme retourné
                </button>
            </form>
            <?php endif; ?>

            <!-- Assigner -->
            <form action="/stock/equipments/<?= e($equipment['id']) ?>/assign" method="POST" class="space-y-3">
                <?= csrfField() ?>
                <div>
                    <label for="user_id" class="block text-xs text-gray-500 mb-1">Utilisateur</label>
                    <select name="user_id" id="user_id" required
                        class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-primary focus:border-primary outline-none bg-white">
                        <option value="">-- Sélectionner --</option>
                        <?php foreach ($users as $user): ?>
                        <option value="<?= e($user['id']) ?>"><?= e($user['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <button type="submit"
                    class="w-full px-4 py-2 text-sm bg-primary text-white rounded-lg hover:bg-blue-700 transition">
                    <i class="fas fa-user-check mr-2"></i> <?= $isAssigned ? 'Réassigner' : 'Assigner' ?>
                </button>
            </form>
        </div>
    </div>
</div>
