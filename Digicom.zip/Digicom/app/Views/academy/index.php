<div class="space-y-6">
    <div class="flex items-center justify-between">
        <h1 class="text-xl font-bold text-gray-900">DIGI COM Academy</h1>
        <a href="/academy/trainings/create" class="px-4 py-2 text-sm bg-blue-600 text-white rounded-lg hover:bg-blue-700">
            <i class="fas fa-plus mr-1"></i> Nouvelle formation
        </a>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div class="bg-white rounded-xl shadow-sm p-5 border border-gray-100">
            <p class="text-sm text-gray-500">Formations</p>
            <p class="text-2xl font-bold text-gray-900"><?= $totalTrainings ?? 0 ?></p>
        </div>
        <div class="bg-white rounded-xl shadow-sm p-5 border border-gray-100">
            <p class="text-sm text-gray-500">À venir</p>
            <p class="text-2xl font-bold text-blue-600"><?= count($upcomingTrainings ?? []) ?></p>
        </div>
        <div class="bg-white rounded-xl shadow-sm p-5 border border-gray-100">
            <p class="text-sm text-gray-500">En cours</p>
            <p class="text-2xl font-bold text-green-600"><?= count($ongoingTrainings ?? []) ?></p>
        </div>
    </div>

    <?php if (!empty($upcomingTrainings)): ?>
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <div class="px-6 py-4 border-b border-gray-100">
            <h3 class="text-sm font-semibold text-gray-700">Formations à venir</h3>
        </div>
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 p-4">
            <?php foreach ($upcomingTrainings as $t): ?>
            <a href="/academy/trainings/<?= $t['id'] ?>" class="block p-4 rounded-lg border border-gray-100 hover:border-blue-200 hover:shadow-sm transition">
                <h4 class="font-medium text-gray-800 mb-1"><?= e($t['title']) ?></h4>
                <p class="text-xs text-gray-500 mb-2"><?= e($t['category']) ?> · <?= $t['duration_hours'] ?>h</p>
                <div class="flex items-center justify-between">
                    <span class="text-sm font-semibold text-blue-600"><?= formatCurrency($t['price'] ?? 0) ?></span>
                    <span class="text-xs text-gray-400"><?= formatDate($t['start_date']) ?></span>
                </div>
            </a>
            <?php endforeach; ?>
        </div>
    </div>
    <?php endif; ?>
</div>
