<?php
/**
 * @var array $training       Training details
 * @var array $registrations  List of registrations for this training
 * @var int   $totalRegistrations Total number of registrations
 * @var string $csrfToken     CSRF token for forms
 */
$training = $training ?? [];
$registrations = $registrations ?? [];
$totalRegistrations = $totalRegistrations ?? count($registrations);
$csrfToken = $csrfToken ?? '';
?>

<div class="space-y-6">
    <!-- Header -->
    <div class="flex items-center gap-4">
        <a href="/academy/trainings"
           class="inline-flex items-center gap-1 rounded-lg p-2 text-gray-500 hover:text-gray-700 hover:bg-gray-100 transition-colors">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                <path stroke-linecap="round" stroke-linejoin="round" d="M10.5 19.5 3 12m0 0 7.5-7.5M3 12h18" />
            </svg>
        </a>
        <div class="flex-1">
            <h1 class="text-2xl font-bold text-gray-900"><?= e($training['title'] ?? 'Détail de la formation') ?></h1>
            <p class="mt-1 text-sm text-gray-500">Détails et inscriptions</p>
        </div>
        <a href="/academy/trainings/<?= e($training['id']) ?>/edit"
           class="inline-flex items-center gap-2 rounded-lg border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50 transition-colors">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                <path stroke-linecap="round" stroke-linejoin="round" d="m16.862 4.487 1.687-1.688a1.875 1.875 0 1 1 2.652 2.652L10.582 16.07a4.5 4.5 0 0 1-1.897 1.13L6 18l.8-2.685a4.5 4.5 0 0 1 1.13-1.897l8.932-8.931Zm0 0L19.5 7.125" />
            </svg>
            Modifier
        </a>
    </div>

    <!-- Training Info Card -->
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            <!-- Category & Status -->
            <div>
                <p class="text-xs font-medium text-gray-500 uppercase mb-1">Catégorie</p>
                <span class="inline-flex items-center rounded-full bg-blue-50 px-2.5 py-0.5 text-sm font-medium text-blue-700">
                    <?= e($training['category'] ?? '—') ?>
                </span>
            </div>

            <div>
                <p class="text-xs font-medium text-gray-500 uppercase mb-1">Statut</p>
                <?= statusBadge($training['status'] ?? 'draft') ?>
            </div>

            <!-- Price -->
            <div>
                <p class="text-xs font-medium text-gray-500 uppercase mb-1">Prix</p>
                <p class="text-lg font-bold text-gray-900"><?= e(formatCurrency($training['price'] ?? 0)) ?></p>
            </div>

            <!-- Duration -->
            <div>
                <p class="text-xs font-medium text-gray-500 uppercase mb-1">Durée</p>
                <p class="text-lg font-bold text-gray-900"><?= e($training['duration_hours'] ?? '—') ?> heures</p>
            </div>

            <!-- Trainer -->
            <div>
                <p class="text-xs font-medium text-gray-500 uppercase mb-1">Formateur</p>
                <p class="text-sm font-medium text-gray-900"><?= e($training['trainer_name'] ?? $training['trainer'] ?? '—') ?></p>
            </div>

            <!-- Max Participants -->
            <div>
                <p class="text-xs font-medium text-gray-500 uppercase mb-1">Capacité</p>
                <p class="text-sm font-medium text-gray-900">
                    <?= e($totalRegistrations) ?> / <?= e($training['max_participants'] ?? '—') ?> inscrits
                </p>
            </div>

            <!-- Start Date -->
            <div>
                <p class="text-xs font-medium text-gray-500 uppercase mb-1">Date de début</p>
                <p class="text-sm font-medium text-gray-900"><?= e(formatDate($training['start_date'] ?? '')) ?></p>
            </div>

            <!-- End Date -->
            <div>
                <p class="text-xs font-medium text-gray-500 uppercase mb-1">Date de fin</p>
                <p class="text-sm font-medium text-gray-900"><?= e(formatDate($training['end_date'] ?? '')) ?></p>
            </div>
        </div>

        <!-- Description -->
        <?php if (!empty($training['description'])): ?>
            <div class="mt-6 pt-6 border-t border-gray-100">
                <h3 class="text-sm font-medium text-gray-700 mb-2">Description</h3>
                <p class="text-sm text-gray-600 leading-relaxed"><?= nl2br(e($training['description'])) ?></p>
            </div>
        <?php endif; ?>
    </div>

    <!-- Registrations List -->
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <div class="px-6 py-4 border-b border-gray-100 flex items-center justify-between">
            <h2 class="text-lg font-semibold text-gray-900">
                Inscriptions
                <span class="ml-2 text-sm font-normal text-gray-500">(<?= e($totalRegistrations) ?>)</span>
            </h2>
        </div>
        <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Apprenant
                        </th>
                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Email
                        </th>
                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Statut
                        </th>
                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Paiement
                        </th>
                        <th scope="col" class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Actions
                        </th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    <?php if (!empty($registrations)): ?>
                        <?php foreach ($registrations as $reg): ?>
                            <tr class="hover:bg-gray-50 transition-colors">
                                <td class="whitespace-nowrap px-6 py-4 text-sm font-medium text-gray-900">
                                    <?= e($reg['learner_name'] ?? '—') ?>
                                </td>
                                <td class="whitespace-nowrap px-6 py-4 text-sm text-gray-600">
                                    <?= e($reg['learner_email'] ?? '—') ?>
                                </td>
                                <td class="whitespace-nowrap px-6 py-4 text-sm">
                                    <?= statusBadge($reg['status'] ?? 'pending') ?>
                                </td>
                                <td class="whitespace-nowrap px-6 py-4 text-sm">
                                    <?php
                                    $paymentStatus = strtolower($reg['payment_status'] ?? 'unpaid');
                                    $payBadge = match ($paymentStatus) {
                                        'paid'    => 'bg-green-100 text-green-800',
                                        'partial' => 'bg-yellow-100 text-yellow-800',
                                        default   => 'bg-red-100 text-red-800',
                                    };
                                    $payLabel = match ($paymentStatus) {
                                        'paid'    => 'Payé',
                                        'partial' => 'Partiel',
                                        default   => 'Impayé',
                                    };
                                    ?>
                                    <span class="inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium <?= $payBadge ?>">
                                        <?= e($payLabel) ?>
                                    </span>
                                </td>
                                <td class="whitespace-nowrap px-6 py-4 text-sm text-right">
                                    <div class="flex items-center justify-end gap-2">
                                        <!-- Confirm registration -->
                                        <form action="/academy/registrations/<?= e($reg['id']) ?>/status" method="POST" class="inline">
                                            <?= csrfField() ?>
                                            <input type="hidden" name="_method" value="PUT">
                                            <input type="hidden" name="status" value="confirmed">
                                            <button type="submit"
                                                    title="Confirmer"
                                                    class="inline-flex items-center rounded-lg p-1.5 text-green-600 hover:bg-green-50 transition-colors">
                                                <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                                    <path stroke-linecap="round" stroke-linejoin="round" d="m4.5 12.75 6 6 9-13.5" />
                                                </svg>
                                            </button>
                                        </form>
                                        <!-- Cancel registration -->
                                        <form action="/academy/registrations/<?= e($reg['id']) ?>/status" method="POST" class="inline">
                                            <?= csrfField() ?>
                                            <input type="hidden" name="_method" value="PUT">
                                            <input type="hidden" name="status" value="cancelled">
                                            <button type="submit"
                                                    title="Annuler"
                                                    class="inline-flex items-center rounded-lg p-1.5 text-red-600 hover:bg-red-50 transition-colors">
                                                <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                                    <path stroke-linecap="round" stroke-linejoin="round" d="M6 18 18 6M6 6l12 12" />
                                                </svg>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="5" class="px-6 py-12 text-center text-sm text-gray-500">
                                Aucune inscription pour cette formation.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Registration Form -->
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
        <h2 class="text-lg font-semibold text-gray-900 mb-4">Nouvelle inscription</h2>
        <form action="/academy/trainings/<?= e($training['id']) ?>/register" method="POST" class="space-y-4">
            <?= csrfField() ?>

            <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <!-- Learner Name -->
                <div>
                    <label for="learner_name" class="block text-sm font-medium text-gray-700 mb-1">
                        Nom complet <span class="text-red-500">*</span>
                    </label>
                    <input type="text" name="learner_name" id="learner_name" required
                           placeholder="Nom de l'apprenant"
                           class="block w-full rounded-lg border border-gray-300 px-3 py-2.5 text-sm text-gray-700 shadow-sm placeholder-gray-400 focus:border-blue-500 focus:ring-2 focus:ring-blue-100 transition-colors">
                </div>

                <!-- Learner Email -->
                <div>
                    <label for="learner_email" class="block text-sm font-medium text-gray-700 mb-1">
                        Email <span class="text-red-500">*</span>
                    </label>
                    <input type="email" name="learner_email" id="learner_email" required
                           placeholder="email@exemple.com"
                           class="block w-full rounded-lg border border-gray-300 px-3 py-2.5 text-sm text-gray-700 shadow-sm placeholder-gray-400 focus:border-blue-500 focus:ring-2 focus:ring-blue-100 transition-colors">
                </div>

                <!-- Learner Phone -->
                <div>
                    <label for="learner_phone" class="block text-sm font-medium text-gray-700 mb-1">
                        Téléphone
                    </label>
                    <input type="tel" name="learner_phone" id="learner_phone"
                           placeholder="+212 6XX XXX XXX"
                           class="block w-full rounded-lg border border-gray-300 px-3 py-2.5 text-sm text-gray-700 shadow-sm placeholder-gray-400 focus:border-blue-500 focus:ring-2 focus:ring-blue-100 transition-colors">
                </div>
            </div>

            <div class="pt-2">
                <button type="submit"
                        class="inline-flex items-center gap-2 rounded-lg bg-blue-600 px-5 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-blue-700 transition-colors">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M18 7.5v3m0 0v3m0-3h3m-3 0h-3m-2.25-4.125a3.375 3.375 0 1 1-6.75 0 3.375 3.375 0 0 1 6.75 0ZM3 19.235v-.11a6.375 6.375 0 0 1 12.75 0v.109A12.318 12.318 0 0 1 9.374 21c-2.331 0-4.512-.645-6.374-1.766Z" />
                    </svg>
                    Inscrire
                </button>
            </div>
        </form>
    </div>
</div>
