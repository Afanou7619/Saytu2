<?php
/**
 * @var array|null $training Existing training data (for edit mode)
 * @var array      $trainers Available trainers for selection
 * @var bool       $isEdit   Whether this is an edit form
 */
$isEdit = !empty($training);
$action = $isEdit ? '/academy/trainings/' . e($training['id']) . '/edit' : '/academy/trainings/create';
$trainers = $trainers ?? [];
?>

<div class="max-w-2xl mx-auto space-y-6">
    <!-- Header -->
    <div class="flex items-center gap-4">
        <a href="/academy/trainings"
           class="inline-flex items-center gap-1 rounded-lg p-2 text-gray-500 hover:text-gray-700 hover:bg-gray-100 transition-colors">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                <path stroke-linecap="round" stroke-linejoin="round" d="M10.5 19.5 3 12m0 0 7.5-7.5M3 12h18" />
            </svg>
        </a>
        <div>
            <h1 class="text-2xl font-bold text-gray-900">
                <?= $isEdit ? 'Modifier la formation' : 'Nouvelle formation' ?>
            </h1>
            <p class="mt-1 text-sm text-gray-500">
                <?= $isEdit ? 'Mettez à jour les informations de la formation' : 'Créez une nouvelle formation' ?>
            </p>
        </div>
    </div>

    <!-- Form -->
    <form action="<?= e($action) ?>" method="POST" class="bg-white rounded-xl shadow-sm border border-gray-100 p-6 space-y-5">
        <?= csrfField() ?>

        <?php if ($isEdit): ?>
            <input type="hidden" name="_method" value="PUT">
        <?php endif; ?>

        <!-- Title -->
        <div>
            <label for="title" class="block text-sm font-medium text-gray-700 mb-1">
                Titre de la formation <span class="text-red-500">*</span>
            </label>
            <input type="text" name="title" id="title" required
                   value="<?= e($training['title'] ?? '') ?>"
                   placeholder="Ex: Développement Web Full Stack"
                   class="block w-full rounded-lg border border-gray-300 px-3 py-2.5 text-sm text-gray-700 shadow-sm placeholder-gray-400 focus:border-blue-500 focus:ring-2 focus:ring-blue-100 transition-colors">
        </div>

        <!-- Category -->
        <div>
            <label for="category" class="block text-sm font-medium text-gray-700 mb-1">
                Catégorie <span class="text-red-500">*</span>
            </label>
            <input type="text" name="category" id="category" required
                   value="<?= e($training['category'] ?? '') ?>"
                   placeholder="Ex: Informatique, Management, Marketing..."
                   class="block w-full rounded-lg border border-gray-300 px-3 py-2.5 text-sm text-gray-700 shadow-sm placeholder-gray-400 focus:border-blue-500 focus:ring-2 focus:ring-blue-100 transition-colors">
        </div>

        <!-- Description -->
        <div>
            <label for="description" class="block text-sm font-medium text-gray-700 mb-1">
                Description
            </label>
            <textarea name="description" id="description" rows="4"
                      placeholder="Décrivez le contenu et les objectifs de la formation..."
                      class="block w-full rounded-lg border border-gray-300 px-3 py-2.5 text-sm text-gray-700 shadow-sm placeholder-gray-400 focus:border-blue-500 focus:ring-2 focus:ring-blue-100 transition-colors resize-y"><?= e($training['description'] ?? '') ?></textarea>
        </div>

        <!-- Price & Duration -->
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <!-- Price -->
            <div>
                <label for="price" class="block text-sm font-medium text-gray-700 mb-1">
                    Prix <span class="text-red-500">*</span>
                </label>
                <div class="relative">
                    <div class="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                        <span class="text-gray-500 text-sm">DH</span>
                    </div>
                    <input type="number" name="price" id="price" required min="0" step="0.01"
                           value="<?= e($training['price'] ?? '') ?>"
                           placeholder="0.00"
                           class="block w-full rounded-lg border border-gray-300 pl-10 pr-3 py-2.5 text-sm text-gray-700 shadow-sm placeholder-gray-400 focus:border-blue-500 focus:ring-2 focus:ring-blue-100 transition-colors">
                </div>
            </div>

            <!-- Duration Hours -->
            <div>
                <label for="duration_hours" class="block text-sm font-medium text-gray-700 mb-1">
                    Durée (heures) <span class="text-red-500">*</span>
                </label>
                <input type="number" name="duration_hours" id="duration_hours" required min="1"
                       value="<?= e($training['duration_hours'] ?? '') ?>"
                       placeholder="Nombre d'heures"
                       class="block w-full rounded-lg border border-gray-300 px-3 py-2.5 text-sm text-gray-700 shadow-sm placeholder-gray-400 focus:border-blue-500 focus:ring-2 focus:ring-blue-100 transition-colors">
            </div>
        </div>

        <!-- Max Participants -->
        <div>
            <label for="max_participants" class="block text-sm font-medium text-gray-700 mb-1">
                Participants maximum <span class="text-red-500">*</span>
            </label>
            <input type="number" name="max_participants" id="max_participants" required min="1"
                   value="<?= e($training['max_participants'] ?? '') ?>"
                   placeholder="Nombre maximum de participants"
                   class="block w-full rounded-lg border border-gray-300 px-3 py-2.5 text-sm text-gray-700 shadow-sm placeholder-gray-400 focus:border-blue-500 focus:ring-2 focus:ring-blue-100 transition-colors">
        </div>

        <!-- Trainer -->
        <div>
            <label for="trainer_id" class="block text-sm font-medium text-gray-700 mb-1">
                Formateur <span class="text-red-500">*</span>
            </label>
            <select name="trainer_id" id="trainer_id" required
                    class="block w-full rounded-lg border border-gray-300 px-3 py-2.5 text-sm text-gray-700 shadow-sm focus:border-blue-500 focus:ring-2 focus:ring-blue-100 transition-colors">
                <option value="">— Sélectionnez un formateur —</option>
                <?php foreach ($trainers as $trainer): ?>
                    <option value="<?= e($trainer['id']) ?>"
                        <?= isset($training['trainer_id']) && $training['trainer_id'] == $trainer['id'] ? 'selected' : '' ?>>
                        <?= e($trainer['name'] ?? $trainer['full_name'] ?? 'Formateur #' . $trainer['id']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <!-- Dates -->
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
                <label for="start_date" class="block text-sm font-medium text-gray-700 mb-1">
                    Date de début <span class="text-red-500">*</span>
                </label>
                <input type="date" name="start_date" id="start_date" required
                       value="<?= e($training['start_date'] ?? '') ?>"
                       class="block w-full rounded-lg border border-gray-300 px-3 py-2.5 text-sm text-gray-700 shadow-sm focus:border-blue-500 focus:ring-2 focus:ring-blue-100 transition-colors">
            </div>
            <div>
                <label for="end_date" class="block text-sm font-medium text-gray-700 mb-1">
                    Date de fin <span class="text-red-500">*</span>
                </label>
                <input type="date" name="end_date" id="end_date" required
                       value="<?= e($training['end_date'] ?? '') ?>"
                       class="block w-full rounded-lg border border-gray-300 px-3 py-2.5 text-sm text-gray-700 shadow-sm focus:border-blue-500 focus:ring-2 focus:ring-blue-100 transition-colors">
            </div>
        </div>

        <!-- Status -->
        <div>
            <label for="status" class="block text-sm font-medium text-gray-700 mb-1">
                Statut <span class="text-red-500">*</span>
            </label>
            <select name="status" id="status" required
                    class="block w-full rounded-lg border border-gray-300 px-3 py-2.5 text-sm text-gray-700 shadow-sm focus:border-blue-500 focus:ring-2 focus:ring-blue-100 transition-colors">
                <option value="draft" <?= isset($training['status']) && $training['status'] === 'draft' ? 'selected' : '' ?>>Brouillon</option>
                <option value="published" <?= isset($training['status']) && $training['status'] === 'published' ? 'selected' : '' ?>>Publiée</option>
                <option value="ongoing" <?= isset($training['status']) && $training['status'] === 'ongoing' ? 'selected' : '' ?>>En cours</option>
                <option value="completed" <?= isset($training['status']) && $training['status'] === 'completed' ? 'selected' : '' ?>>Terminée</option>
                <option value="cancelled" <?= isset($training['status']) && $training['status'] === 'cancelled' ? 'selected' : '' ?>>Annulée</option>
            </select>
        </div>

        <!-- Actions -->
        <div class="flex items-center gap-3 pt-2">
            <button type="submit"
                    class="inline-flex items-center gap-2 rounded-lg bg-blue-600 px-5 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-blue-700 transition-colors">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                    <path stroke-linecap="round" stroke-linejoin="round" d="m4.5 12.75 6 6 9-13.5" />
                </svg>
                <?= $isEdit ? 'Mettre à jour' : 'Enregistrer' ?>
            </button>
            <a href="/academy/trainings"
               class="rounded-lg border border-gray-300 px-5 py-2.5 text-sm font-medium text-gray-700 hover:bg-gray-50 transition-colors">
                Annuler
            </a>
        </div>
    </form>
</div>
