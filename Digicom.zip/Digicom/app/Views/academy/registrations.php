<?php
/**
 * @var array $registrations All registrations across trainings (paginated)
 */
?>

<div class="space-y-6">
    <!-- Header -->
    <div>
        <h1 class="text-2xl font-bold text-gray-900">Inscriptions</h1>
        <p class="mt-1 text-sm text-gray-500">Consultez toutes les inscriptions aux formations</p>
    </div>

    <!-- Registrations Table -->
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Apprenant
                        </th>
                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Email
                        </th>
                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Formation
                        </th>
                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Statut
                        </th>
                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Paiement
                        </th>
                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Date
                        </th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    <?php if (!empty($registrations)): ?>
                        <?php foreach ($registrations as $reg): ?>
                            <tr class="hover:bg-gray-50 transition-colors">
                                <td class="whitespace-nowrap px-6 py-4 text-sm font-medium text-gray-900">
                                    <?= e($reg['learner_name'] ?? '—') ?>
                                </td>
                                <td class="whitespace-nowrap px-6 py-4 text-sm text-gray-600">
                                    <?= e($reg['learner_email'] ?? '—') ?>
                                </td>
                                <td class="px-6 py-4 text-sm text-gray-900">
                                    <a href="/academy/trainings/<?= e($reg['training_id'] ?? '#') ?>"
                                       class="text-blue-600 hover:text-blue-800 hover:underline">
                                        <?= e($reg['training_title'] ?? '—') ?>
                                    </a>
                                </td>
                                <td class="whitespace-nowrap px-6 py-4 text-sm">
                                    <?= statusBadge($reg['status'] ?? 'pending') ?>
                                </td>
                                <td class="whitespace-nowrap px-6 py-4 text-sm">
                                    <?php
                                    $paymentStatus = strtolower($reg['payment_status'] ?? 'unpaid');
                                    $payBadge = match ($paymentStatus) {
                                        'paid'    => 'bg-green-100 text-green-800',
                                        'partial' => 'bg-yellow-100 text-yellow-800',
                                        default   => 'bg-red-100 text-red-800',
                                    };
                                    $payLabel = match ($paymentStatus) {
                                        'paid'    => 'Payé',
                                        'partial' => 'Partiel',
                                        default   => 'Impayé',
                                    };
                                    ?>
                                    <span class="inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium <?= $payBadge ?>">
                                        <?= e($payLabel) ?>
                                    </span>
                                </td>
                                <td class="whitespace-nowrap px-6 py-4 text-sm text-gray-600">
                                    <?= e(formatDate($reg['created_at'] ?? $reg['date'] ?? '')) ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="6" class="px-6 py-12 text-center text-sm text-gray-500">
                                <svg xmlns="http://www.w3.org/2000/svg" class="mx-auto h-10 w-10 text-gray-300 mb-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M15 19.128a9.38 9.38 0 0 0 2.625.372 9.337 9.337 0 0 0 4.121-.952 4.125 4.125 0 0 0-7.533-2.493M15 19.128v-.003c0-1.113-.285-2.16-.786-3.07M15 19.128v.106A12.318 12.318 0 0 1 8.624 21c-2.331 0-4.512-.645-6.374-1.766l-.001-.109a6.375 6.375 0 0 1 11.964-3.07M12 6.375a3.375 3.375 0 1 1-6.75 0 3.375 3.375 0 0 1 6.75 0Zm8.25 2.25a2.625 2.625 0 1 1-5.25 0 2.625 2.625 0 0 1 5.25 0Z" />
                                </svg>
                                Aucune inscription trouvée.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- Pagination -->
        <?php if (isset($pager)): ?>
            <div class="border-t border-gray-200 px-6 py-3">
                <?= $pager->links() ?>
            </div>
        <?php endif; ?>
    </div>
</div>
