<?php
/**
 * @var array  $trainings      Paginated training data
 * @var string $currentCategory Active category filter
 * @var array  $categories      Available categories for filtering
 */
$currentCategory = $currentCategory ?? "all";
$categories = $categories ?? [];
?>

<div class="space-y-6">
    <!-- Header -->
    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
            <h1 class="text-2xl font-bold text-gray-900">Formations</h1>
            <p class="mt-1 text-sm text-gray-500">Liste de toutes les formations disponibles</p>
        </div>
        <a href="/academy/trainings/create"
           class="inline-flex items-center gap-2 rounded-lg bg-blue-600 px-4 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-blue-700 transition-colors">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                <path stroke-linecap="round" stroke-linejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
            </svg>
            Nouvelle formation
        </a>
    </div>

    <!-- Category Filter -->
    <?php if (!empty($categories)): ?>
        <div class="flex flex-wrap items-center gap-2">
            <a href="?category=all"
               class="rounded-full px-3 py-1.5 text-xs font-medium transition-colors <?= $currentCategory ===
               "all"
                   ? "bg-blue-600 text-white"
                   : "bg-gray-100 text-gray-600 hover:bg-gray-200" ?>">
                Toutes
            </a>
            <?php foreach ($categories as $cat): ?>
                <a href="?category=<?= e($cat) ?>"
                   class="rounded-full px-3 py-1.5 text-xs font-medium transition-colors <?= $currentCategory ===
                   $cat
                       ? "bg-blue-600 text-white"
                       : "bg-gray-100 text-gray-600 hover:bg-gray-200" ?>">
                    <?= e($cat) ?>
                </a>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <!-- Trainings Table -->
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Titre
                        </th>
                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Catégorie
                        </th>
                        <th scope="col" class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Prix
                        </th>
                        <th scope="col" class="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Durée
                        </th>
                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Dates
                        </th>
                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Statut
                        </th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    <?php if (!empty($trainings)): ?>
                        <?php foreach ($trainings as $training): ?>
                            <tr class="hover:bg-gray-50 transition-colors cursor-pointer"
                                onclick="window.location.href='<?= url(
                                    "/academy/trainings/" . $training["id"],
                                ) ?>'">
                                <td class="px-6 py-4 text-sm font-medium text-gray-900">
                                    <a href="<?= url(
                                        "/academy/trainings/" . $training["id"],
                                    ) ?>" class="hover:text-blue-600">
                                        <?= e($training["title"] ?? "—") ?>
                                    </a>
                                </td>
                                <td class="whitespace-nowrap px-6 py-4 text-sm">
                                    <span class="inline-flex items-center rounded-full bg-blue-50 px-2.5 py-0.5 text-xs font-medium text-blue-700">
                                        <?= e($training["category"] ?? "—") ?>
                                    </span>
                                </td>
                                <td class="whitespace-nowrap px-6 py-4 text-sm text-right font-semibold text-gray-900">
                                    <?= e(
                                        formatCurrency($training["price"] ?? 0),
                                    ) ?>
                                </td>
                                <td class="whitespace-nowrap px-6 py-4 text-sm text-center text-gray-600">
                                    <?= e(
                                        $training["duration_hours"] ?? "—",
                                    ) ?> h
                                </td>
                                <td class="whitespace-nowrap px-6 py-4 text-sm text-gray-600">
                                    <?php if (
                                        !empty($training["start_date"])
                                    ): ?>
                                        <span class="block"><?= e(
                                            formatDate($training["start_date"]),
                                        ) ?></span>
                                        <span class="block text-xs text-gray-400">
                                            → <?= e(
                                                formatDate(
                                                    $training["end_date"] ?? "",
                                                ),
                                            ) ?>
                                        </span>
                                    <?php else: ?>
                                        <span class="text-gray-400">—</span>
                                    <?php endif; ?>
                                </td>
                                <td class="whitespace-nowrap px-6 py-4 text-sm">
                                    <?= statusBadge(
                                        $training["status"] ?? "draft",
                                    ) ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="6" class="px-6 py-12 text-center text-sm text-gray-500">
                                <svg xmlns="http://www.w3.org/2000/svg" class="mx-auto h-10 w-10 text-gray-300 mb-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M12 6.042A8.967 8.967 0 0 0 6 3.75c-1.052 0-2.062.18-3 .512v14.25A8.987 8.987 0 0 1 6 18c2.305 0 4.408.867 6 2.292m0-14.25a8.966 8.966 0 0 1 6-2.292c1.052 0 2.062.18 3 .512v14.25A8.987 8.987 0 0 0 18 18a8.967 8.967 0 0 0-6 2.292m0-14.25v14.25" />
                                </svg>
                                Aucune formation trouvée.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- Pagination -->
        <?php if (isset($pager)): ?>
            <div class="border-t border-gray-200 px-6 py-3">
                <?= $pager->links() ?>
            </div>
        <?php endif; ?>
    </div>
</div>
