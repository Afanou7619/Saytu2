<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Auth;
use App\Models\Quote;
use App\Models\Invoice;
use App\Models\Client;

class CommercialController extends Controller
{
    public function index(): void
    {
        $quotes = Quote::pending();
        $overdueInvoices = Invoice::overdue();
        $recentInvoices = Invoice::paginate(1, 10, 'created_at');

        $this->view('commercial/index', [
            'title' => 'Gestion Commerciale',
            'quotes' => $quotes,
            'overdueInvoices' => $overdueInvoices,
            'recentInvoices' => $recentInvoices['items'],
        ]);
    }

    // ==================== DEVIS ====================

    public function quotes(): void
    {
        $status = $_GET['status'] ?? '';
        $where = $status ? "status = '" . addslashes($status) . "'" : '';
        $quotes = Quote::paginate(page: (int)($_GET['page'] ?? 1), where: $where, orderBy: 'created_at');

        $this->view('commercial/quotes', ['title' => 'Devis', 'quotes' => $quotes]);
    }

    public function createQuote(): void
    {
        $clients = Client::all('company_name', 'ASC');
        $this->view('commercial/quote_form', ['title' => 'Nouveau devis', 'clients' => $clients, 'quote' => null]);
    }

    public function storeQuote(): void
    {
        $this->validateCsrf();

        $data = [
            'reference' => Quote::generateReference(),
            'client_id' => (int)$_POST['client_id'],
            'project_id' => !empty($_POST['project_id']) ? (int)$_POST['project_id'] : null,
            'created_by' => Auth::id(),
            'tax_rate' => (float)($_POST['tax_rate'] ?? 18),
            'valid_until' => $_POST['valid_until'] ?? null,
            'notes' => $_POST['notes'] ?? '',
            'total_ht' => 0,
            'total_ttc' => 0,
        ];

        $quoteId = Quote::create($data);

        // Ajout des lignes
        if (!empty($_POST['items'])) {
            foreach ($_POST['items']['description'] as $i => $desc) {
                if (empty($desc)) continue;
                Quote::addItem($quoteId, [
                    'description' => $desc,
                    'quantity' => (float)($_POST['items']['quantity'][$i] ?? 1),
                    'unit_price' => (float)($_POST['items']['unit_price'][$i] ?? 0),
                ]);
            }
        }

        Quote::updateTotals($quoteId);
        setFlash('success', 'Devis créé avec succès.');
        $this->redirect('/commercial/quotes/' . $quoteId);
    }

    public function showQuote(int $id): void
    {
        $quote = Quote::find($id);
        if (!$quote) { $this->redirect('/commercial/quotes'); return; }

        $items = Quote::items($id);
        $client = Client::find($quote['client_id']);

        $this->view('commercial/quote_show', [
            'title' => 'Devis ' . $quote['reference'],
            'quote' => $quote,
            'items' => $items,
            'client' => $client,
        ]);
    }

    public function editQuote(int $id): void
    {
        $quote = Quote::find($id);
        if (!$quote) { $this->redirect('/commercial/quotes'); return; }

        $items = Quote::items($id);
        $clients = Client::all('company_name', 'ASC');

        $this->view('commercial/quote_form', [
            'title' => 'Modifier devis',
            'quote' => $quote,
            'items' => $items,
            'clients' => $clients,
        ]);
    }

    public function updateQuote(int $id): void
    {
        $this->validateCsrf();

        Quote::update($id, [
            'client_id' => (int)$_POST['client_id'],
            'tax_rate' => (float)($_POST['tax_rate'] ?? 18),
            'valid_until' => $_POST['valid_until'] ?? null,
            'notes' => $_POST['notes'] ?? '',
            'status' => $_POST['status'] ?? 'draft',
        ]);

        // Supprimer et recréer les lignes
        \App\Core\Database::query("DELETE FROM quote_items WHERE quote_id = ?", [$id]);

        if (!empty($_POST['items'])) {
            foreach ($_POST['items']['description'] as $i => $desc) {
                if (empty($desc)) continue;
                Quote::addItem($id, [
                    'description' => $desc,
                    'quantity' => (float)($_POST['items']['quantity'][$i] ?? 1),
                    'unit_price' => (float)($_POST['items']['unit_price'][$i] ?? 0),
                ]);
            }
        }

        Quote::updateTotals($id);
        setFlash('success', 'Devis mis à jour.');
        $this->redirect('/commercial/quotes/' . $id);
    }

    public function convertToInvoice(int $id): void
    {
        $this->validateCsrf();
        $quote = Quote::find($id);
        if (!$quote) { $this->redirect('/commercial/quotes'); return; }

        $invoiceId = Invoice::create([
            'reference' => Invoice::generateReference(),
            'quote_id' => $id,
            'client_id' => $quote['client_id'],
            'project_id' => $quote['project_id'],
            'total_ht' => $quote['total_ht'],
            'tax_rate' => $quote['tax_rate'],
            'total_ttc' => $quote['total_ttc'],
            'due_date' => date('Y-m-d', strtotime('+30 days')),
            'created_by' => Auth::id(),
            'status' => 'draft',
        ]);

        // Copier les lignes
        $items = Quote::items($id);
        foreach ($items as $item) {
            Invoice::addItem($invoiceId, [
                'description' => $item['description'],
                'quantity' => $item['quantity'],
                'unit_price' => $item['unit_price'],
            ]);
        }

        Invoice::updateTotals($invoiceId);

        // Marquer le devis comme accepté
        Quote::update($id, ['status' => 'accepted']);

        setFlash('success', 'Devis converti en facture.');
        $this->redirect('/commercial/invoices/' . $invoiceId);
    }

    public function quotePdf(int $id): void
    {
        $quote = Quote::find($id);
        if (!$quote) { $this->redirect('/commercial/quotes'); return; }

        $filename = \App\Core\PdfGenerator::generateQuote($quote);
        header('Content-Type: application/pdf');
        header('Content-Disposition: inline; filename="' . $quote['reference'] . '.pdf"');
        readfile($filename);
    }

    // ==================== FACTURES ====================

    public function invoices(): void
    {
        $status = $_GET['status'] ?? '';
        $where = $status ? "status = '" . addslashes($status) . "'" : '';
        $invoices = Invoice::paginate(page: (int)($_GET['page'] ?? 1), where: $where, orderBy: 'created_at');

        $this->view('commercial/invoices', ['title' => 'Factures', 'invoices' => $invoices]);
    }

    public function createInvoice(): void
    {
        $clients = Client::all('company_name', 'ASC');
        $this->view('commercial/invoice_form', ['title' => 'Nouvelle facture', 'clients' => $clients, 'invoice' => null, 'items' => []]);
    }

    public function storeInvoice(): void
    {
        $this->validateCsrf();

        $invoiceId = Invoice::create([
            'reference' => Invoice::generateReference(),
            'client_id' => (int)$_POST['client_id'],
            'project_id' => !empty($_POST['project_id']) ? (int)$_POST['project_id'] : null,
            'created_by' => Auth::id(),
            'tax_rate' => (float)($_POST['tax_rate'] ?? 18),
            'due_date' => $_POST['due_date'] ?? date('Y-m-d', strtotime('+30 days')),
            'total_ht' => 0,
            'total_ttc' => 0,
        ]);

        if (!empty($_POST['items'])) {
            foreach ($_POST['items']['description'] as $i => $desc) {
                if (empty($desc)) continue;
                Invoice::addItem($invoiceId, [
                    'description' => $desc,
                    'quantity' => (float)($_POST['items']['quantity'][$i] ?? 1),
                    'unit_price' => (float)($_POST['items']['unit_price'][$i] ?? 0),
                ]);
            }
        }

        Invoice::updateTotals($invoiceId);
        setFlash('success', 'Facture créée avec succès.');
        $this->redirect('/commercial/invoices/' . $invoiceId);
    }

    public function showInvoice(int $id): void
    {
        $invoice = Invoice::find($id);
        if (!$invoice) { $this->redirect('/commercial/invoices'); return; }

        $items = Invoice::items($id);
        $client = Client::find($invoice['client_id']);
        $payments = Invoice::payments($id);

        $this->view('commercial/invoice_show', [
            'title' => 'Facture ' . $invoice['reference'],
            'invoice' => $invoice,
            'items' => $items,
            'client' => $client,
            'payments' => $payments,
        ]);
    }

    public function addPayment(int $id): void
    {
        $this->validateCsrf();

        Invoice::addPayment([
            'invoice_id' => $id,
            'amount' => (float)$_POST['amount'],
            'payment_method' => $_POST['payment_method'] ?? 'transfer',
            'reference' => $_POST['payment_reference'] ?? '',
            'payment_date' => $_POST['payment_date'] ?? date('Y-m-d'),
            'notes' => $_POST['notes'] ?? '',
            'created_by' => Auth::id(),
        ]);

        setFlash('success', 'Paiement enregistré.');
        $this->redirect('/commercial/invoices/' . $id);
    }

    public function invoicePdf(int $id): void
    {
        $invoice = Invoice::find($id);
        if (!$invoice) { $this->redirect('/commercial/invoices'); return; }

        $filename = \App\Core\PdfGenerator::generateInvoice($invoice);
        header('Content-Type: application/pdf');
        header('Content-Disposition: inline; filename="' . $invoice['reference'] . '.pdf"');
        readfile($filename);
    }

    public function receivables(): void
    {
        $overdue = Invoice::overdue();
        $this->view('commercial/receivables', ['title' => 'Suivi des créances', 'receivables' => $overdue]);
    }
}
