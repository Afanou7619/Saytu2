<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Auth;
use App\Models\Project;
use App\Models\Task;
use App\Models\Client;
use App\Models\User;

class ProjectController extends Controller
{
    public function index(): void
    {
        $status = $_GET['status'] ?? '';
        $where = $status ? "status = '" . addslashes($status) . "'" : '';
        $projects = Project::paginate(page: (int)($_GET['page'] ?? 1), where: $where, orderBy: 'created_at');

        $this->view('projects/index', [
            'title' => 'Projets',
            'projects' => $projects,
            'filterStatus' => $status,
        ]);
    }

    public function create(): void
    {
        $clients = Client::all('company_name', 'ASC');
        $managers = User::getActive();
        $this->view('projects/create', [
            'title' => 'Nouveau projet',
            'clients' => $clients,
            'managers' => $managers,
        ]);
    }

    public function store(): void
    {
        $this->validateCsrf();

        $projectId = Project::create([
            'title' => $_POST['title'] ?? '',
            'client_id' => (int)($_POST['client_id'] ?? 0) ?: null,
            'manager_id' => (int)($_POST['manager_id'] ?? 0) ?: null,
            'start_date' => $_POST['start_date'] ?? null,
            'end_date' => $_POST['end_date'] ?? null,
            'budget' => (float)($_POST['budget'] ?? 0) ?: null,
            'description' => $_POST['description'] ?? '',
            'created_by' => Auth::id(),
        ]);

        setFlash('success', 'Projet créé avec succès.');
        $this->redirect('/projects/' . $projectId);
    }

    public function show(int $id): void
    {
        $project = Project::find($id);
        if (!$project) { $this->redirect('/projects'); return; }

        $tasks = Task::byProject($id);
        $client = $project['client_id'] ? Client::find($project['client_id']) : null;
        $manager = $project['manager_id'] ? User::find($project['manager_id']) : null;

        // Stats des tâches
        $taskStats = [
            'total' => count($tasks),
            'todo' => count(array_filter($tasks, fn($t) => $t['status'] === 'todo')),
            'in_progress' => count(array_filter($tasks, fn($t) => $t['status'] === 'in_progress')),
            'review' => count(array_filter($tasks, fn($t) => $t['status'] === 'review')),
            'done' => count(array_filter($tasks, fn($t) => $t['status'] === 'done')),
        ];

        $this->view('projects/show', [
            'title' => $project['title'],
            'project' => $project,
            'tasks' => $tasks,
            'client' => $client,
            'manager' => $manager,
            'taskStats' => $taskStats,
        ]);
    }

    public function edit(int $id): void
    {
        $project = Project::find($id);
        if (!$project) { $this->redirect('/projects'); return; }

        $clients = Client::all('company_name', 'ASC');
        $managers = User::getActive();

        $this->view('projects/edit', [
            'title' => 'Modifier ' . $project['title'],
            'project' => $project,
            'clients' => $clients,
            'managers' => $managers,
        ]);
    }

    public function update(int $id): void
    {
        $this->validateCsrf();

        Project::update($id, [
            'title' => $_POST['title'] ?? '',
            'client_id' => (int)($_POST['client_id'] ?? 0) ?: null,
            'manager_id' => (int)($_POST['manager_id'] ?? 0) ?: null,
            'start_date' => $_POST['start_date'] ?? null,
            'end_date' => $_POST['end_date'] ?? null,
            'budget' => (float)($_POST['budget'] ?? 0) ?: null,
            'description' => $_POST['description'] ?? '',
            'status' => $_POST['status'] ?? 'active',
        ]);

        setFlash('success', 'Projet mis à jour.');
        $this->redirect('/projects/' . $id);
    }

    public function close(int $id): void
    {
        $this->validateCsrf();
        Project::update($id, ['status' => 'completed']);
        setFlash('success', 'Projet clôturé.');
        $this->redirect('/projects/' . $id);
    }

    public function gantt(int $id): void
    {
        $project = Project::find($id);
        if (!$project) { $this->redirect('/projects'); return; }

        $tasks = Task::byProject($id);
        $this->view('projects/gantt', [
            'title' => 'Gantt - ' . $project['title'],
            'project' => $project,
            'tasks' => $tasks,
        ]);
    }

    // ==================== TÂCHES ====================

    public function tasks(): void
    {
        $status = $_GET['status'] ?? '';
        $userId = $_GET['user_id'] ?? '';

        if ($userId) {
            $tasks = Task::byUser((int)$userId);
        } elseif ($status) {
            $tasks = \App\Core\Database::fetchAll(
                "SELECT t.*, p.title as project_title, u.name as assigned_name
                 FROM tasks t
                 LEFT JOIN projects p ON t.project_id = p.id
                 LEFT JOIN users u ON t.assigned_to = u.id
                 WHERE t.status = ?
                 ORDER BY t.due_date ASC",
                [$status]
            );
        } else {
            $tasks = \App\Core\Database::fetchAll(
                "SELECT t.*, p.title as project_title, u.name as assigned_name
                 FROM tasks t
                 LEFT JOIN projects p ON t.project_id = p.id
                 LEFT JOIN users u ON t.assigned_to = u.id
                 ORDER BY t.created_at DESC
                 LIMIT 100"
            );
        }

        $users = User::getActive();
        $this->view('projects/tasks', [
            'title' => 'Tâches',
            'tasks' => $tasks,
            'users' => $users,
            'filterStatus' => $status,
        ]);
    }

    public function createTask(): void
    {
        $projects = Project::activeProjects();
        $users = User::getActive();
        $this->view('projects/task_form', [
            'title' => 'Nouvelle tâche',
            'projects' => $projects,
            'users' => $users,
            'task' => null,
        ]);
    }

    public function storeTask(): void
    {
        $this->validateCsrf();

        $taskId = Task::create([
            'project_id' => (int)($_POST['project_id'] ?? 0),
            'title' => $_POST['title'] ?? '',
            'description' => $_POST['description'] ?? '',
            'assigned_to' => (int)($_POST['assigned_to'] ?? 0) ?: null,
            'priority' => $_POST['priority'] ?? 'medium',
            'due_date' => $_POST['due_date'] ?? null,
            'due_time' => $_POST['due_time'] ?? null,
            'created_by' => Auth::id(),
        ]);

        Project::updateProgress((int)$_POST['project_id']);

        // Notification à l'assigné
        if (!empty($_POST['assigned_to'])) {
            \App\Models\Notification::notify(
                (int)$_POST['assigned_to'],
                'task_assigned',
                'Nouvelle tâche assignée',
                'Vous avez été assigné à la tâche : ' . $_POST['title'],
                '/tasks/' . $taskId
            );
        }

        setFlash('success', 'Tâche créée.');
        $this->redirect('/tasks/' . $taskId);
    }

    public function showTask(int $id): void
    {
        $task = Task::find($id);
        if (!$task) { $this->redirect('/tasks'); return; }

        $project = Project::find($task['project_id']);
        $comments = Task::comments($id);
        $assignedUser = $task['assigned_to'] ? User::find($task['assigned_to']) : null;

        $this->view('projects/task_show', [
            'title' => $task['title'],
            'task' => $task,
            'project' => $project,
            'comments' => $comments,
            'assignedUser' => $assignedUser,
        ]);
    }

    public function editTask(int $id): void
    {
        $task = Task::find($id);
        if (!$task) { $this->redirect('/tasks'); return; }

        $projects = Project::activeProjects();
        $users = User::getActive();

        $this->view('projects/task_form', [
            'title' => 'Modifier tâche',
            'task' => $task,
            'projects' => $projects,
            'users' => $users,
        ]);
    }

    public function updateTask(int $id): void
    {
        $this->validateCsrf();

        Task::update($id, [
            'project_id' => (int)($_POST['project_id'] ?? 0),
            'title' => $_POST['title'] ?? '',
            'description' => $_POST['description'] ?? '',
            'assigned_to' => (int)($_POST['assigned_to'] ?? 0) ?: null,
            'priority' => $_POST['priority'] ?? 'medium',
            'status' => $_POST['status'] ?? 'todo',
            'due_date' => $_POST['due_date'] ?? null,
            'due_time' => $_POST['due_time'] ?? null,
        ]);

        Project::updateProgress((int)$_POST['project_id']);
        setFlash('success', 'Tâche mise à jour.');
        $this->redirect('/tasks/' . $id);
    }

    public function updateTaskStatus(int $id): void
    {
        $this->validateCsrf();
        $status = $_POST['status'] ?? 'todo';
        Task::update($id, ['status' => $status]);

        $task = Task::find($id);
        Project::updateProgress($task['project_id']);

        $this->json(['success' => true]);
    }

    public function addComment(int $id): void
    {
        $this->validateCsrf();
        $content = trim($_POST['content'] ?? '');

        if (empty($content)) {
            setFlash('error', 'Le commentaire ne peut pas être vide.');
            $this->redirect('/tasks/' . $id);
            return;
        }

        Task::addComment($id, Auth::id(), $content);
        setFlash('success', 'Commentaire ajouté.');
        $this->redirect('/tasks/' . $id);
    }
}
