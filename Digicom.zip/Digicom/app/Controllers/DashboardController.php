<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Auth;
use App\Core\Database;
use App\Models\Client;
use App\Models\Project;
use App\Models\Task;
use App\Models\Invoice;
use App\Models\Transaction;
use App\Models\Leave;
use App\Models\Notification;

class DashboardController extends Controller
{
    public function index(): void
    {
        $role = Auth::role();
        $stats = $this->getStatsByRole($role);

        $unreadNotifications = Notification::forUser(Auth::id(), 5);
        $recentTasks = Task::byUser(Auth::id());

        $this->view('dashboard/index', [
            'title' => 'Tableau de bord',
            'stats' => $stats,
            'unreadNotifications' => $unreadNotifications,
            'recentTasks' => array_slice($recentTasks, 0, 5),
            'role' => $role,
        ]);
    }

    public function stats(): void
    {
        $role = Auth::role();
        $stats = $this->getStatsByRole($role);
        $this->json($stats);
    }

    private function getStatsByRole(string $role): array
    {
        $stats = [
            'clients' => Client::count("type = 'client'"),
            'prospects' => Client::count("type = 'prospect'"),
            'active_projects' => Project::count("status IN ('active', 'on_hold')"),
            'tasks_overdue' => Task::count("due_date < CURDATE() AND status NOT IN ('done', 'review')"),
            'pending_quotes' => \App\Models\Quote::count("status IN ('draft', 'sent')"),
            'unpaid_invoices' => Invoice::count("status IN ('sent', 'partial', 'overdue')"),
            'overdue_invoices' => Invoice::count("due_date < CURDATE() AND status NOT IN ('paid', 'cancelled')"),
            'pending_leaves' => Leave::count("status = 'pending'"),
        ];

        // Stats financières du mois en cours
        $currentMonth = (int)date('m');
        $currentYear = (int)date('Y');
        $financials = Transaction::monthlySummary($currentYear, $currentMonth);
        $stats['monthly_income'] = $financials['income'] ?? 0;
        $stats['monthly_expense'] = $financials['expense'] ?? 0;
        $stats['monthly_balance'] = ($financials['income'] ?? 0) - ($financials['expense'] ?? 0);

        // Données pour graphiques
        $stats['chart_revenue'] = $this->getYearlyRevenue($currentYear);
        $stats['chart_projects'] = $this->getProjectProgress();

        return $stats;
    }

    private function getYearlyRevenue(int $year): array
    {
        $monthlyData = Transaction::yearlySummary($year);
        $months = [];
        for ($i = 1; $i <= 12; $i++) {
            $months[$i] = ['income' => 0, 'expense' => 0];
        }
        foreach ($monthlyData as $row) {
            $m = (int)$row['month'];
            $months[$m] = [
                'income' => (float)$row['income'],
                'expense' => (float)$row['expense'],
            ];
        }
        return array_values($months);
    }

    private function getProjectProgress(): array
    {
        return Database::fetchAll(
            "SELECT title, progress, status
             FROM projects
             WHERE status IN ('active', 'on_hold', 'draft')
             ORDER BY progress DESC
             LIMIT 10"
        );
    }
}
