<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Auth;
use App\Models\Notification;

class NotificationController extends Controller
{
    public function index(): void
    {
        $notifications = Notification::forUser(Auth::id(), 100);
        $unreadCount = Notification::unreadCount(Auth::id());

        $this->view('notifications/index', [
            'title' => 'Notifications',
            'notifications' => $notifications,
            'unreadCount' => $unreadCount,
        ]);
    }

    public function markRead(int $id): void
    {
        $this->validateCsrf();
        Notification::markRead($id);
        $this->json(['success' => true]);
    }

    public function markAllRead(): void
    {
        $this->validateCsrf();
        Notification::markAllRead(Auth::id());
        $this->json(['success' => true]);
    }
}
