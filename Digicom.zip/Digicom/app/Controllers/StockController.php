<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Auth;
use App\Core\Database;
use App\Models\User;

class StockController extends Controller
{
    public function index(): void
    {
        $equipments = Database::fetchAll(
            "SELECT eq.*, u.name as assigned_name
             FROM equipments eq
             LEFT JOIN users u ON eq.assigned_to = u.id
             ORDER BY eq.status, eq.name"
        );

        $stats = [
            'total' => Database::fetch("SELECT COUNT(*) FROM equipments")['COUNT(*)'],
            'available' => Database::fetch("SELECT COUNT(*) FROM equipments WHERE status = 'available'")['COUNT(*)'],
            'assigned' => Database::fetch("SELECT COUNT(*) FROM equipments WHERE status = 'assigned'")['COUNT(*)'],
            'maintenance' => Database::fetch("SELECT COUNT(*) FROM equipments WHERE status = 'maintenance'")['COUNT(*)'],
        ];

        $this->view('stock/index', [
            'title' => 'Stock & Équipements',
            'equipments' => $equipments,
            'stats' => $stats,
        ]);
    }

    public function equipments(): void
    {
        $status = $_GET['status'] ?? '';
        $where = $status ? "status = '" . addslashes($status) . "'" : '';

        $equipments = Database::fetchAll(
            "SELECT eq.*, u.name as assigned_name
             FROM equipments eq
             LEFT JOIN users u ON eq.assigned_to = u.id
             " . ($where ? "WHERE eq.{$where}" : "") . "
             ORDER BY eq.name"
        );

        $this->view('stock/equipments', [
            'title' => 'Équipements',
            'equipments' => $equipments,
            'filterStatus' => $status,
        ]);
    }

    public function create(): void
    {
        $users = User::getActive();
        $this->view('stock/create', [
            'title' => 'Nouvel équipement',
            'users' => $users,
        ]);
    }

    public function store(): void
    {
        $this->validateCsrf();

        Database::insert('equipments', [
            'name' => $_POST['name'] ?? '',
            'type' => $_POST['type'] ?? '',
            'serial_number' => $_POST['serial_number'] ?? '',
            'purchase_date' => $_POST['purchase_date'] ?? null,
            'value' => (float)($_POST['value'] ?? 0),
            'notes' => $_POST['notes'] ?? '',
            'status' => 'available',
        ]);

        setFlash('success', 'Équipement ajouté.');
        $this->redirect('/stock/equipments');
    }

    public function show(int $id): void
    {
        $equipment = Database::fetch(
            "SELECT eq.*, u.name as assigned_name
             FROM equipments eq
             LEFT JOIN users u ON eq.assigned_to = u.id
             WHERE eq.id = ?", [$id]
        );

        if (!$equipment) { $this->redirect('/stock/equipments'); return; }

        $this->view('stock/show', [
            'title' => $equipment['name'],
            'equipment' => $equipment,
        ]);
    }

    public function assign(int $id): void
    {
        $this->validateCsrf();

        $userId = (int)($_POST['user_id'] ?? 0);
        Database::update('equipments', [
            'assigned_to' => $userId ?: null,
            'status' => $userId ? 'assigned' : 'available',
        ], 'id = ?', [$id]);

        setFlash('success', 'Équipement ' . ($userId ? 'assigné' : 'libéré') . '.');
        $this->redirect('/stock/equipments/' . $id);
    }
}
