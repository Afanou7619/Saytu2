<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Database;
use App\Models\Transaction;
use App\Models\Project;
use App\Models\Client;
use App\Models\Invoice;

class ReportController extends Controller
{
    public function index(): void
    {
        $this->view('reports/index', ['title' => 'Rapports & Exports']);
    }

    public function commercial(): void
    {
        $currentYear = (int)date('Y');
        $monthlyRevenue = Transaction::yearlySummary($currentYear);

        $topClients = Database::fetchAll(
            "SELECT c.company_name, SUM(i.total_ttc) as total
             FROM invoices i
             JOIN clients c ON i.client_id = c.id
             WHERE i.status = 'paid' AND YEAR(i.paid_at) = ?
             GROUP BY i.client_id
             ORDER BY total DESC
             LIMIT 10",
            [$currentYear]
        );

        $quoteStats = [
            'total' => Database::fetch("SELECT COUNT(*) FROM quotes WHERE YEAR(created_at) = ?", [$currentYear])['COUNT(*)'],
            'accepted' => Database::fetch("SELECT COUNT(*) FROM quotes WHERE status = 'accepted' AND YEAR(created_at) = ?", [$currentYear])['COUNT(*)'],
            'rejected' => Database::fetch("SELECT COUNT(*) FROM quotes WHERE status = 'rejected' AND YEAR(created_at) = ?", [$currentYear])['COUNT(*)'],
        ];

        $this->view('reports/commercial', [
            'title' => 'Rapport Commercial',
            'monthlyRevenue' => $monthlyRevenue,
            'topClients' => $topClients,
            'quoteStats' => $quoteStats,
            'year' => $currentYear,
        ]);
    }

    public function financial(): void
    {
        $currentYear = (int)($_GET['year'] ?? date('Y'));
        $yearlyData = Transaction::yearlySummary($currentYear);
        $categoryBreakdown = Transaction::byCategory('expense', $currentYear);

        $totalIncome = array_sum(array_column($yearlyData, 'income'));
        $totalExpense = array_sum(array_column($yearlyData, 'expense'));

        $this->view('reports/financial', [
            'title' => 'Rapport Financier',
            'yearlyData' => $yearlyData,
            'categories' => $categoryBreakdown,
            'totalIncome' => $totalIncome,
            'totalExpense' => $totalExpense,
            'year' => $currentYear,
        ]);
    }

    public function hr(): void
    {
        $employees = \App\Models\Employee::allWithUser();
        $leavesByType = Database::fetchAll(
            "SELECT type, COUNT(*) as count
             FROM leaves WHERE YEAR(start_date) = YEAR(CURDATE())
             GROUP BY type"
        );

        $this->view('reports/hr', [
            'title' => 'Rapport RH',
            'employees' => $employees,
            'leavesByType' => $leavesByType,
            'totalEmployees' => count($employees),
        ]);
    }

    public function projects(): void
    {
        $active = Project::activeProjects();
        $completed = Project::completedProjects();

        $projectStats = [
            'active' => count($active),
            'completed' => count($completed),
            'on_time' => 0,
            'delayed' => 0,
        ];

        foreach ($active as $p) {
            if ($p['end_date'] && strtotime($p['end_date']) < time()) {
                $projectStats['delayed']++;
            } else {
                $projectStats['on_time']++;
            }
        }

        $this->view('reports/projects', [
            'title' => 'Rapport Projets',
            'active' => $active,
            'completed' => $completed,
            'stats' => $projectStats,
        ]);
    }

    public function academy(): void
    {
        $trainings = \App\Models\Training::all('start_date', 'DESC');
        $totalRegistrations = Database::fetch("SELECT COUNT(*) FROM training_registrations")['COUNT(*)'];
        $totalRevenue = Database::fetch(
            "SELECT COALESCE(SUM(amount_paid), 0) as total FROM training_registrations WHERE payment_status = 'paid'"
        )['total'];

        $this->view('reports/academy', [
            'title' => 'Rapport Academy',
            'trainings' => $trainings,
            'totalRegistrations' => $totalRegistrations,
            'totalRevenue' => $totalRevenue,
        ]);
    }

    public function export(string $type): void
    {
        $currentYear = (int)date('Y');

        switch ($type) {
            case 'clients':
                $clients = Client::all('company_name', 'ASC');
                $filename = \App\Core\ExcelExporter::exportClients($clients);
                $downloadName = 'clients_' . date('Ymd') . '.xlsx';
                break;

            case 'transactions':
                $transactions = Database::fetchAll(
                    "SELECT * FROM transactions WHERE YEAR(transaction_date) = ? ORDER BY transaction_date",
                    [$currentYear]
                );
                $filename = \App\Core\ExcelExporter::exportTransactions($transactions);
                $downloadName = 'transactions_' . $currentYear . '.xlsx';
                break;

            case 'invoices':
                $invoices = Invoice::all('created_at', 'DESC');
                $filename = \App\Core\ExcelExporter::exportInvoices($invoices);
                $downloadName = 'factures_' . date('Ymd') . '.xlsx';
                break;

            default:
                setFlash('error', 'Type d\'export non reconnu.');
                $this->redirect('/reports');
                return;
        }

        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment; filename="' . $downloadName . '"');
        readfile($filename);
        exit;
    }
}
