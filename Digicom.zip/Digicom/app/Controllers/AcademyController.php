<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Auth;
use App\Models\Training;
use App\Models\User;

class AcademyController extends Controller
{
    public function index(): void
    {
        $publishedTrainings = Training::published();
        $upcomingTrainings = array_slice(array_filter($publishedTrainings, fn($t) => $t['status'] === 'published'), 0, 6);
        $ongoingTrainings = array_filter($publishedTrainings, fn($t) => $t['status'] === 'ongoing');

        $this->view('academy/index', [
            'title' => 'DIGI COM Academy',
            'upcomingTrainings' => $upcomingTrainings,
            'ongoingTrainings' => $ongoingTrainings,
            'totalTrainings' => Training::count(),
        ]);
    }

    public function trainings(): void
    {
        $category = $_GET['category'] ?? '';
        $where = $category ? "category = '" . addslashes($category) . "'" : '';
        $trainings = Training::paginate(
            page: (int)($_GET['page'] ?? 1),
            where: $where,
            orderBy: 'start_date',
            direction: 'DESC'
        );

        $this->view('academy/trainings', [
            'title' => 'Catalogue des formations',
            'trainings' => $trainings,
        ]);
    }

    public function createTraining(): void
    {
        $trainers = User::getActive();
        $this->view('academy/training_form', [
            'title' => 'Nouvelle formation',
            'training' => null,
            'trainers' => $trainers,
        ]);
    }

    public function storeTraining(): void
    {
        $this->validateCsrf();

        Training::create([
            'title' => $_POST['title'] ?? '',
            'category' => $_POST['category'] ?? '',
            'description' => $_POST['description'] ?? '',
            'price' => (float)($_POST['price'] ?? 0),
            'duration_hours' => (int)($_POST['duration_hours'] ?? 0),
            'max_participants' => (int)($_POST['max_participants'] ?? 0),
            'trainer_id' => (int)($_POST['trainer_id'] ?? 0) ?: null,
            'start_date' => $_POST['start_date'] ?? null,
            'end_date' => $_POST['end_date'] ?? null,
            'status' => $_POST['status'] ?? 'draft',
        ]);

        setFlash('success', 'Formation créée avec succès.');
        $this->redirect('/academy/trainings');
    }

    public function showTraining(int $id): void
    {
        $training = Training::find($id);
        if (!$training) { $this->redirect('/academy/trainings'); return; }

        $registrations = Training::registrations($id);
        $trainer = $training['trainer_id'] ? User::find($training['trainer_id']) : null;
        $totalRegistrations = Training::totalRegistrations($id);

        $this->view('academy/training_show', [
            'title' => $training['title'],
            'training' => $training,
            'registrations' => $registrations,
            'trainer' => $trainer,
            'totalRegistrations' => $totalRegistrations,
        ]);
    }

    public function editTraining(int $id): void
    {
        $training = Training::find($id);
        if (!$training) { $this->redirect('/academy/trainings'); return; }

        $trainers = User::getActive();
        $this->view('academy/training_form', [
            'title' => 'Modifier ' . $training['title'],
            'training' => $training,
            'trainers' => $trainers,
        ]);
    }

    public function updateTraining(int $id): void
    {
        $this->validateCsrf();

        Training::update($id, [
            'title' => $_POST['title'] ?? '',
            'category' => $_POST['category'] ?? '',
            'description' => $_POST['description'] ?? '',
            'price' => (float)($_POST['price'] ?? 0),
            'duration_hours' => (int)($_POST['duration_hours'] ?? 0),
            'max_participants' => (int)($_POST['max_participants'] ?? 0),
            'trainer_id' => (int)($_POST['trainer_id'] ?? 0) ?: null,
            'start_date' => $_POST['start_date'] ?? null,
            'end_date' => $_POST['end_date'] ?? null,
            'status' => $_POST['status'] ?? 'draft',
        ]);

        setFlash('success', 'Formation mise à jour.');
        $this->redirect('/academy/trainings/' . $id);
    }

    public function registrations(): void
    {
        $registrations = \App\Core\Database::fetchAll(
            "SELECT tr.*, t.title as training_title
             FROM training_registrations tr
             JOIN trainings t ON tr.training_id = t.id
             ORDER BY tr.registered_at DESC
             LIMIT 200"
        );

        $this->view('academy/registrations', [
            'title' => 'Inscriptions',
            'registrations' => $registrations,
        ]);
    }

    public function storeRegistration(): void
    {
        $this->validateCsrf();

        Training::register((int)$_POST['training_id'], [
            'learner_name' => $_POST['learner_name'] ?? '',
            'learner_email' => $_POST['learner_email'] ?? '',
            'learner_phone' => $_POST['learner_phone'] ?? '',
        ]);

        setFlash('success', 'Inscription enregistrée avec succès.');
        $this->redirect('/academy/trainings/' . $_POST['training_id']);
    }

    public function updateRegistrationStatus(int $id): void
    {
        $this->validateCsrf();
        Training::updateRegistrationStatus($id, $_POST['status'] ?? 'registered');
        setFlash('success', 'Statut mis à jour.');
        $this->back();
    }
}
