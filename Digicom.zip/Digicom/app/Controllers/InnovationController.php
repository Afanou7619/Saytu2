<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Auth;
use App\Core\Database;

class InnovationController extends Controller
{
    public function index(): void
    {
        $projects = Database::fetchAll(
            "SELECT ip.*, u.name as lead_name
             FROM innovation_projects ip
             LEFT JOIN users u ON ip.lead_id = u.id
             ORDER BY ip.created_at DESC"
        );

        $this->view('innovation/index', [
            'title' => 'Innovation Lab',
            'projects' => $projects,
        ]);
    }

    public function projects(): void
    {
        $projects = Database::fetchAll(
            "SELECT ip.*, u.name as lead_name
             FROM innovation_projects ip
             LEFT JOIN users u ON ip.lead_id = u.id
             ORDER BY ip.status, ip.created_at DESC"
        );

        $this->view('innovation/projects', [
            'title' => 'Projets R&D',
            'projects' => $projects,
        ]);
    }

    public function create(): void
    {
        $users = \App\Models\User::getActive();
        $this->view('innovation/create', [
            'title' => 'Nouveau projet Innovation',
            'users' => $users,
        ]);
    }

    public function store(): void
    {
        $this->validateCsrf();

        Database::insert('innovation_projects', [
            'title' => $_POST['title'] ?? '',
            'domain' => $_POST['domain'] ?? '',
            'description' => $_POST['description'] ?? '',
            'lead_id' => (int)($_POST['lead_id'] ?? 0) ?: null,
            'start_date' => $_POST['start_date'] ?? date('Y-m-d'),
        ]);

        setFlash('success', 'Projet innovation créé.');
        $this->redirect('/innovation/projects');
    }

    public function show(int $id): void
    {
        $project = Database::fetch(
            "SELECT ip.*, u.name as lead_name
             FROM innovation_projects ip
             LEFT JOIN users u ON ip.lead_id = u.id
             WHERE ip.id = ?", [$id]
        );

        if (!$project) { $this->redirect('/innovation'); return; }

        $this->view('innovation/show', [
            'title' => $project['title'],
            'project' => $project,
        ]);
    }

    public function library(): void
    {
        $resources = Database::fetchAll(
            "SELECT * FROM documents
             WHERE category = 'media' OR access_level = 'internal'
             ORDER BY created_at DESC
             LIMIT 100"
        );

        $this->view('innovation/library', [
            'title' => 'Bibliothèque technique',
            'resources' => $resources,
        ]);
    }
}
