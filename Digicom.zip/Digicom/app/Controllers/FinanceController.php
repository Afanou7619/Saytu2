<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Auth;
use App\Models\Transaction;

class FinanceController extends Controller
{
    public function index(): void
    {
        $currentMonth = (int)date('m');
        $currentYear = (int)date('Y');

        $summary = Transaction::monthlySummary($currentYear, $currentMonth);
        $categoryBreakdown = Transaction::byCategory('expense', $currentYear);
        $recentTransactions = Transaction::paginate(1, 10, 'transaction_date');

        $this->view('finance/index', [
            'title' => 'Comptabilité & Finances',
            'summary' => $summary,
            'categories' => $categoryBreakdown,
            'recentTransactions' => $recentTransactions['items'],
            'year' => $currentYear,
        ]);
    }

    public function transactions(): void
    {
        $type = $_GET['type'] ?? '';
        $status = $_GET['status'] ?? '';
        $whereParts = [];
        $params = [];

        if ($type) {
            $whereParts[] = "type = ?";
            $params[] = $type;
        }
        if ($status) {
            $whereParts[] = "status = ?";
            $params[] = $status;
        }

        $where = implode(' AND ', $whereParts);
        $transactions = Transaction::paginate(
            page: (int)($_GET['page'] ?? 1),
            where: $where,
            params: $params,
            orderBy: 'transaction_date'
        );

        $this->view('finance/transactions', [
            'title' => 'Transactions',
            'transactions' => $transactions,
            'filterType' => $type,
            'filterStatus' => $status,
        ]);
    }

    public function createTransaction(): void
    {
        $this->view('finance/transaction_form', [
            'title' => 'Nouvelle transaction',
            'transaction' => null,
        ]);
    }

    public function storeTransaction(): void
    {
        $this->validateCsrf();

        Transaction::create([
            'type' => $_POST['type'] ?? 'expense',
            'category' => $_POST['category'] ?? '',
            'amount' => (float)($_POST['amount'] ?? 0),
            'description' => $_POST['description'] ?? '',
            'reference' => $_POST['reference'] ?? '',
            'account' => $_POST['account'] ?? '',
            'transaction_date' => $_POST['transaction_date'] ?? date('Y-m-d'),
            'created_by' => Auth::id(),
        ]);

        setFlash('success', 'Transaction enregistrée.');
        $this->redirect('/finance/transactions');
    }

    public function validateTransaction(int $id): void
    {
        $this->validateCsrf();
        Transaction::update($id, [
            'status' => 'validated',
            'validated_by' => Auth::id(),
        ]);
        setFlash('success', 'Transaction validée.');
        $this->redirect('/finance/transactions');
    }

    public function budget(): void
    {
        $currentYear = (int)date('Y');
        $budgets = \App\Core\Database::fetchAll(
            "SELECT * FROM budgets WHERE year = ? ORDER BY department", [$currentYear]
        );

        $this->view('finance/budget', [
            'title' => 'Suivi budgétaire',
            'budgets' => $budgets,
            'year' => $currentYear,
        ]);
    }

    public function updateBudget(): void
    {
        $this->validateCsrf();

        $year = (int)($_POST['year'] ?? date('Y'));
        $departments = $_POST['departments'] ?? [];
        $allocated = $_POST['allocated'] ?? [];

        foreach ($departments as $i => $dept) {
            if (empty($dept)) continue;
            $amt = (float)($allocated[$i] ?? 0);

            $existing = \App\Core\Database::fetch(
                "SELECT id FROM budgets WHERE department = ? AND year = ?", [$dept, $year]
            );

            if ($existing) {
                \App\Core\Database::update('budgets', ['allocated' => $amt], 'id = ?', [$existing['id']]);
            } else {
                \App\Core\Database::insert('budgets', [
                    'department' => $dept,
                    'year' => $year,
                    'allocated' => $amt,
                ]);
            }
        }

        setFlash('success', 'Budgets mis à jour.');
        $this->redirect('/finance/budget');
    }

    public function reports(): void
    {
        $year = (int)($_GET['year'] ?? date('Y'));
        $yearlyData = Transaction::yearlySummary($year);

        $this->view('finance/reports', [
            'title' => 'Rapports financiers',
            'yearlyData' => $yearlyData,
            'year' => $year,
        ]);
    }

    public function export(): void
    {
        $year = (int)($_GET['year'] ?? date('Y'));
        $transactions = \App\Core\Database::fetchAll(
            "SELECT * FROM transactions WHERE YEAR(transaction_date) = ? ORDER BY transaction_date",
            [$year]
        );

        $filename = \App\Core\ExcelExporter::exportTransactions($transactions);

        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment; filename="transactions_' . $year . '.xlsx"');
        readfile($filename);
    }
}
