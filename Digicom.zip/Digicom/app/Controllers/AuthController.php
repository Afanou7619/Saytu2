<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Auth;
use App\Middleware\CsrfMiddleware;
use App\Models\ActivityLog;

class AuthController extends Controller
{
    public function loginForm(): void
    {
        if (Auth::check()) {
            $this->redirect("/dashboard");
            return;
        }
        $this->view("auth/login", ["title" => "Connexion"], "auth");
    }

    public function login(): void
    {
        if (!CsrfMiddleware::verify($_POST["csrf_token"] ?? "")) {
            setFlash("error", "Session expirée, veuillez réessayer.");
            $this->redirect("/login");
            return;
        }

        $email = trim($_POST["email"] ?? "");
        $password = $_POST["password"] ?? "";

        if (empty($email) || empty($password)) {
            setFlash("error", "Veuillez remplir tous les champs.");
            $this->redirect("/login");
            return;
        }

        if (Auth::login($email, $password)) {
            CsrfMiddleware::regenerate();

            // Redirection vers l'URL prévue ou dashboard
            $intended = $_SESSION["_intended_url"] ?? "/dashboard";
            unset($_SESSION["_intended_url"]);
            $this->redirect($intended);
            return;
        }

        setFlash("error", "Email ou mot de passe incorrect.");
        $this->redirect("/login");
    }

    public function logout(): void
    {
        Auth::logout();
        // Auth::logout fait déjà la redirection
    }

    public function changePasswordForm(): void
    {
        if (!Auth::check()) {
            $this->redirect("/login");
            return;
        }
        $this->view("auth/change_password", [
            "title" => "Changer le mot de passe",
        ]);
    }

    public function changePassword(): void
    {
        $this->validateCsrf();

        $currentPassword = $_POST["current_password"] ?? "";
        $newPassword = $_POST["new_password"] ?? "";
        $confirmPassword = $_POST["confirm_password"] ?? "";

        $user = Auth::user();

        if (!password_verify($currentPassword, $user["password"])) {
            setFlash("error", "Mot de passe actuel incorrect.");
            $this->redirect("/change-password");
            return;
        }

        if ($newPassword !== $confirmPassword) {
            setFlash("error", "Les mots de passe ne correspondent pas.");
            $this->redirect("/change-password");
            return;
        }

        if (strlen($newPassword) < 8) {
            setFlash(
                "error",
                "Le mot de passe doit contenir au moins 8 caractères.",
            );
            $this->redirect("/change-password");
            return;
        }

        $hashed = password_hash($newPassword, PASSWORD_BCRYPT, ["cost" => 12]);
        \App\Models\User::update($user["id"], [
            "password" => $hashed,
            "must_change_password" => 0,
        ]);

        ActivityLog::record($user["id"], "PASSWORD_CHANGED");
        setFlash("success", "Mot de passe modifié avec succès.");
        $this->redirect("/dashboard");
    }

    public function twoFactorForm(): void
    {
        $this->view("auth/2fa", ["title" => "Vérification 2FA"], "auth");
    }

    public function twoFactorVerify(): void
    {
        $this->validateCsrf();
        $code = $_POST["code"] ?? "";

        // Vérification TOTP via RobThree/TwoFactorAuth
        // Implémenté selon les besoins
        if (empty($code) || strlen($code) !== 6) {
            setFlash("error", "Code invalide.");
            $this->redirect("/2fa");
            return;
        }

        $_SESSION["2fa_verified"] = true;
        $this->redirect("/dashboard");
    }
}
