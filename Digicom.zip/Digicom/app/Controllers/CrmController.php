<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Auth;
use App\Models\Client;

class CrmController extends Controller
{
    public function index(): void
    {
        $clients = Client::paginate(page: (int)($_GET['page'] ?? 1));
        $this->view('crm/index', ['title' => 'CRM', 'clients' => $clients]);
    }

    public function clients(): void
    {
        $type = $_GET['type'] ?? 'all';
        $where = '';
        $params = [];

        if ($type === 'client') {
            $where = "type = 'client'";
        } elseif ($type === 'prospect') {
            $where = "type = 'prospect'";
        } elseif ($type === 'partenaire') {
            $where = "type = 'partenaire'";
        }

        $clients = Client::paginate(page: (int)($_GET['page'] ?? 1), where: $where, params: $params, orderBy: 'created_at');
        $this->view('crm/clients', ['title' => 'Clients & Prospects', 'clients' => $clients, 'filterType' => $type]);
    }

    public function createClient(): void
    {
        $this->view('crm/create', ['title' => 'Nouveau client']);
    }

    public function storeClient(): void
    {
        $this->validateCsrf();

        $data = [
            'type' => $_POST['type'] ?? 'prospect',
            'company_name' => $_POST['company_name'] ?? '',
            'contact_name' => $_POST['contact_name'] ?? '',
            'email' => $_POST['email'] ?? '',
            'phone' => $_POST['phone'] ?? '',
            'address' => $_POST['address'] ?? '',
            'segment' => $_POST['segment'] ?? '',
            'source' => $_POST['source'] ?? '',
            'assigned_to' => !empty($_POST['assigned_to']) ? (int)$_POST['assigned_to'] : null,
            'notes' => $_POST['notes'] ?? '',
            'pipeline_stage' => $_POST['pipeline_stage'] ?? 'nouveau',
        ];

        $id = Client::create($data);
        setFlash('success', 'Client créé avec succès.');
        $this->redirect('/crm/clients/' . $id);
    }

    public function showClient(int $id): void
    {
        $client = Client::find($id);
        if (!$client) {
            $this->redirect('/crm/clients');
            return;
        }

        $projects = \App\Models\Project::byClient($id);
        $invoices = \App\Models\Invoice::findAllBy('client_id', $id, 'created_at DESC');
        $quotes = \App\Models\Quote::findAllBy('client_id', $id, 'created_at DESC');

        $this->view('crm/show', [
            'title' => $client['company_name'] ?? 'Client',
            'client' => $client,
            'projects' => $projects,
            'invoices' => $invoices,
            'quotes' => $quotes,
        ]);
    }

    public function editClient(int $id): void
    {
        $client = Client::find($id);
        if (!$client) {
            $this->redirect('/crm/clients');
            return;
        }
        $this->view('crm/edit', ['title' => 'Modifier client', 'client' => $client]);
    }

    public function updateClient(int $id): void
    {
        $this->validateCsrf();

        $data = [
            'type' => $_POST['type'] ?? 'prospect',
            'company_name' => $_POST['company_name'] ?? '',
            'contact_name' => $_POST['contact_name'] ?? '',
            'email' => $_POST['email'] ?? '',
            'phone' => $_POST['phone'] ?? '',
            'address' => $_POST['address'] ?? '',
            'segment' => $_POST['segment'] ?? '',
            'source' => $_POST['source'] ?? '',
            'assigned_to' => !empty($_POST['assigned_to']) ? (int)$_POST['assigned_to'] : null,
            'notes' => $_POST['notes'] ?? '',
            'pipeline_stage' => $_POST['pipeline_stage'] ?? 'nouveau',
        ];

        Client::update($id, $data);
        setFlash('success', 'Client mis à jour.');
        $this->redirect('/crm/clients/' . $id);
    }

    public function deleteClient(int $id): void
    {
        $this->validateCsrf();
        Client::delete($id);
        setFlash('success', 'Client supprimé.');
        $this->redirect('/crm/clients');
    }

    public function kanban(): void
    {
        $kanbanData = Client::kanbanData();
        $this->view('crm/kanban', ['title' => 'Pipeline CRM', 'kanban' => $kanbanData]);
    }

    public function updateKanban(): void
    {
        $this->validateCsrf();
        $clientId = (int)($_POST['client_id'] ?? 0);
        $stage = $_POST['stage'] ?? '';

        if ($clientId && $stage) {
            Client::update($clientId, ['pipeline_stage' => $stage]);
            $this->json(['success' => true]);
            return;
        }
        $this->json(['success' => false, 'error' => 'Données invalides'], 400);
    }

    public function export(): void
    {
        $clients = Client::all('created_at', 'DESC');
        $filename = \App\Core\ExcelExporter::exportClients($clients);

        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment; filename="clients_export.xlsx"');
        readfile($filename);
    }

    public function import(): void
    {
        $this->validateCsrf();
        // Logique d'import CSV
        setFlash('success', 'Import en cours de développement.');
        $this->redirect('/crm/clients');
    }
}
