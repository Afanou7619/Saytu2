<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Auth;
use App\Core\Database;
use App\Models\User;
use App\Models\ActivityLog;

class AdminController extends Controller
{
    public function index(): void
    {
        $totalUsers = User::count();
        $activeUsers = User::count("status = 'active'");
        $recentLogs = ActivityLog::recent(10);

        $this->view('admin/index', [
            'title' => 'Administration',
            'totalUsers' => $totalUsers,
            'activeUsers' => $activeUsers,
            'recentLogs' => $recentLogs,
        ]);
    }

    public function users(): void
    {
        $role = $_GET['role'] ?? '';
        $status = $_GET['status'] ?? '';

        $whereParts = [];
        $params = [];

        if ($role) {
            $whereParts[] = "role = ?";
            $params[] = $role;
        }
        if ($status) {
            $whereParts[] = "status = ?";
            $params[] = $status;
        }

        $where = implode(' AND ', $whereParts);
        $users = User::paginate(
            page: (int)($_GET['page'] ?? 1),
            where: $where,
            params: $params,
            orderBy: 'created_at'
        );

        $this->view('admin/users', [
            'title' => 'Gestion des utilisateurs',
            'users' => $users,
            'filterRole' => $role,
            'filterStatus' => $status,
        ]);
    }

    public function createUser(): void
    {
        $this->view('admin/user_form', [
            'title' => 'Créer un utilisateur',
            'user' => null,
        ]);
    }

    public function storeUser(): void
    {
        $this->validateCsrf();

        $password = password_hash($_POST['password'] ?? 'changeme123', PASSWORD_BCRYPT, ['cost' => 12]);

        User::create([
            'name' => $_POST['name'] ?? '',
            'email' => $_POST['email'] ?? '',
            'password' => $password,
            'role' => $_POST['role'] ?? 'collaborateur',
            'phone' => $_POST['phone'] ?? '',
            'status' => $_POST['status'] ?? 'active',
            'created_by' => Auth::id(),
        ]);

        setFlash('success', 'Utilisateur créé.');
        $this->redirect('/admin/users');
    }

    public function editUser(int $id): void
    {
        $user = User::find($id);
        if (!$user) { $this->redirect('/admin/users'); return; }

        $this->view('admin/user_form', [
            'title' => 'Modifier ' . $user['name'],
            'user' => $user,
        ]);
    }

    public function updateUser(int $id): void
    {
        $this->validateCsrf();

        $data = [
            'name' => $_POST['name'] ?? '',
            'email' => $_POST['email'] ?? '',
            'role' => $_POST['role'] ?? 'collaborateur',
            'phone' => $_POST['phone'] ?? '',
            'status' => $_POST['status'] ?? 'active',
        ];

        // Mise à jour du mot de passe si fourni
        if (!empty($_POST['password'])) {
            $data['password'] = password_hash($_POST['password'], PASSWORD_BCRYPT, ['cost' => 12]);
            $data['must_change_password'] = isset($_POST['must_change_password']) ? 1 : 0;
        }

        User::update($id, $data);
        ActivityLog::record(Auth::id(), 'USER_UPDATED', ['user_id' => $id], 'admin');

        setFlash('success', 'Utilisateur mis à jour.');
        $this->redirect('/admin/users');
    }

    public function suspendUser(int $id): void
    {
        $this->validateCsrf();
        User::update($id, ['status' => 'suspended']);
        ActivityLog::record(Auth::id(), 'USER_SUSPENDED', ['user_id' => $id], 'admin');
        setFlash('success', 'Utilisateur suspendu.');
        $this->redirect('/admin/users');
    }

    public function activateUser(int $id): void
    {
        $this->validateCsrf();
        User::update($id, ['status' => 'active']);
        ActivityLog::record(Auth::id(), 'USER_ACTIVATED', ['user_id' => $id], 'admin');
        setFlash('success', 'Utilisateur réactivé.');
        $this->redirect('/admin/users');
    }

    public function logs(): void
    {
        $module = $_GET['module'] ?? '';
        $userId = $_GET['user_id'] ?? '';

        $whereParts = [];
        $params = [];

        if ($module) {
            $whereParts[] = "module = ?";
            $params[] = $module;
        }
        if ($userId) {
            $whereParts[] = "user_id = ?";
            $params[] = (int)$userId;
        }

        $where = implode(' AND ', $whereParts);
        $logs = \App\Core\Database::fetchAll(
            "SELECT al.*, u.name as user_name
             FROM activity_logs al
             LEFT JOIN users u ON al.user_id = u.id
             " . ($where ? "WHERE {$where}" : "") . "
             ORDER BY al.created_at DESC
             LIMIT 200"
        );

        $this->view('admin/logs', [
            'title' => 'Journaux d\'activité',
            'logs' => $logs,
            'filterModule' => $module,
        ]);
    }

    public function settings(): void
    {
        $this->view('admin/settings', ['title' => 'Paramètres']);
    }

    public function updateSettings(): void
    {
        $this->validateCsrf();

        // Mise à jour du fichier .env
        $envFile = BASE_PATH . '/.env';
        $envContent = file_get_contents($envFile);

        foreach (['APP_NAME', 'APP_URL', 'MAIL_HOST', 'MAIL_USERNAME', 'MAIL_FROM_NAME'] as $key) {
            if (isset($_POST[$key])) {
                $value = $_POST[$key];
                $envContent = preg_replace(
                    "/^{$key}=.*/m",
                    "{$key}=\"{$value}\"",
                    $envContent
                );
            }
        }

        file_put_contents($envFile, $envContent);

        setFlash('success', 'Paramètres mis à jour.');
        $this->redirect('/admin/settings');
    }

    public function createBackup(): void
    {
        $this->validateCsrf();

        $backupDir = STORAGE_PATH . '/backups/';
        if (!is_dir($backupDir)) {
            mkdir($backupDir, 0755, true);
        }

        $filename = 'backup_' . date('Ymd_His') . '.sql';
        $backupPath = $backupDir . $filename;

        $host = $_ENV['DB_HOST'] ?? '127.0.0.1';
        $dbName = $_ENV['DB_NAME'] ?? 'digi_erp';
        $user = $_ENV['DB_USER'] ?? 'root';
        $pass = $_ENV['DB_PASS'] ?? '';

        // Construction de la commande mysqldump
        $command = "mysqldump --host={$host} --user={$user}";
        if ($pass) {
            $command .= " --password={$pass}";
        }
        $command .= " {$dbName} > " . escapeshellarg($backupPath);

        exec($command, $output, $returnCode);

        if ($returnCode === 0) {
            setFlash('success', 'Sauvegarde créée : ' . $filename);
        } else {
            setFlash('error', 'Échec de la sauvegarde.');
        }

        $this->redirect('/admin/settings');
    }

    public function backups(): void
    {
        $backupDir = STORAGE_PATH . '/backups/';
        $files = [];

        if (is_dir($backupDir)) {
            foreach (scandir($backupDir, SCANDIR_SORT_DESCENDING) as $file) {
                if (str_ends_with($file, '.sql')) {
                    $files[] = [
                        'name' => $file,
                        'size' => filesize($backupDir . $file),
                        'date' => date('Y-m-d H:i:s', filemtime($backupDir . $file)),
                    ];
                }
            }
        }

        $this->view('admin/backups', [
            'title' => 'Sauvegardes',
            'backups' => $files,
        ]);
    }
}
