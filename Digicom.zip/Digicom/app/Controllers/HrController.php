<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Auth;
use App\Models\Employee;
use App\Models\Leave;
use App\Models\User;

class HrController extends Controller
{
    public function index(): void
    {
        $totalEmployees = Employee::count("status = 'active'");
        $todayAbsences = Leave::todayAbsences();
        $pendingLeaves = Leave::pending();
        $activeEmployees = Employee::active();

        $this->view('hr/index', [
            'title' => 'Ressources Humaines',
            'totalEmployees' => $totalEmployees,
            'todayAbsences' => $todayAbsences,
            'pendingLeaves' => $pendingLeaves,
            'activeEmployees' => $activeEmployees,
        ]);
    }

    public function employees(): void
    {
        $employees = Employee::allWithUser();
        $this->view('hr/employees', ['title' => 'Employés', 'employees' => $employees]);
    }

    public function createEmployee(): void
    {
        $managers = User::getActive();
        $this->view('hr/employee_form', [
            'title' => 'Nouvel employé',
            'employee' => null,
            'managers' => $managers,
        ]);
    }

    public function storeEmployee(): void
    {
        $this->validateCsrf();

        // Créer d'abord l'utilisateur
        $password = password_hash($_POST['password'] ?? 'changeme123', PASSWORD_BCRYPT, ['cost' => 12]);
        $userId = User::create([
            'name' => $_POST['name'] ?? '',
            'email' => $_POST['email'] ?? '',
            'password' => $password,
            'role' => $_POST['role'] ?? 'collaborateur',
            'phone' => $_POST['phone'] ?? '',
            'created_by' => Auth::id(),
        ]);

        // Créer la fiche employé
        Employee::create([
            'user_id' => $userId,
            'employee_number' => Employee::generateNumber(),
            'position' => $_POST['position'] ?? '',
            'department' => $_POST['department'] ?? '',
            'contract_type' => $_POST['contract_type'] ?? 'CDI',
            'hire_date' => $_POST['hire_date'] ?? date('Y-m-d'),
            'salary' => (float)($_POST['salary'] ?? 0),
            'manager_id' => (int)($_POST['manager_id'] ?? 0) ?: null,
        ]);

        setFlash('success', 'Employé créé avec succès.');
        $this->redirect('/hr/employees');
    }

    public function showEmployee(int $id): void
    {
        $employee = \App\Core\Database::fetch(
            "SELECT e.*, u.name, u.email, u.phone, u.avatar, u.status as user_status
             FROM employees e JOIN users u ON e.user_id = u.id WHERE e.id = ?", [$id]
        );

        if (!$employee) { $this->redirect('/hr/employees'); return; }

        $leaves = Leave::byEmployee($id);
        $evaluations = \App\Core\Database::fetchAll(
            "SELECT * FROM evaluations WHERE employee_id = ? ORDER BY evaluation_date DESC", [$id]
        );

        $this->view('hr/employee_show', [
            'title' => $employee['name'],
            'employee' => $employee,
            'leaves' => $leaves,
            'evaluations' => $evaluations,
        ]);
    }

    public function editEmployee(int $id): void
    {
        $employee = \App\Core\Database::fetch(
            "SELECT e.*, u.name, u.email, u.phone, u.role
             FROM employees e JOIN users u ON e.user_id = u.id WHERE e.id = ?", [$id]
        );
        if (!$employee) { $this->redirect('/hr/employees'); return; }

        $managers = User::getActive();
        $this->view('hr/employee_form', [
            'title' => 'Modifier ' . $employee['name'],
            'employee' => $employee,
            'managers' => $managers,
        ]);
    }

    public function updateEmployee(int $id): void
    {
        $this->validateCsrf();

        $employee = Employee::find($id);
        if (!$employee) { $this->redirect('/hr/employees'); return; }

        User::update($employee['user_id'], [
            'name' => $_POST['name'] ?? '',
            'email' => $_POST['email'] ?? '',
            'role' => $_POST['role'] ?? 'collaborateur',
            'phone' => $_POST['phone'] ?? '',
        ]);

        Employee::update($id, [
            'position' => $_POST['position'] ?? '',
            'department' => $_POST['department'] ?? '',
            'contract_type' => $_POST['contract_type'] ?? 'CDI',
            'salary' => (float)($_POST['salary'] ?? 0),
            'manager_id' => (int)($_POST['manager_id'] ?? 0) ?: null,
        ]);

        setFlash('success', 'Employé mis à jour.');
        $this->redirect('/hr/employees/' . $id);
    }

    // ==================== CONGÉS ====================

    public function leaves(): void
    {
        $status = $_GET['status'] ?? '';
        $where = $status ? "status = '" . addslashes($status) . "'" : '';
        $leaves = Leave::paginate(page: (int)($_GET['page'] ?? 1), where: $where, orderBy: 'start_date', direction: 'DESC');

        $this->view('hr/leaves', ['title' => 'Congés & Absences', 'leaves' => $leaves]);
    }

    public function createLeave(): void
    {
        $employee = \App\Core\Database::fetch(
            "SELECT e.* FROM employees e WHERE e.user_id = ?", [Auth::id()]
        );

        if (!$employee) {
            setFlash('error', 'Fiche employé non trouvée.');
            $this->redirect('/hr/leaves');
            return;
        }

        $this->view('hr/leave_form', [
            'title' => 'Demande de congé',
            'employee' => $employee,
        ]);
    }

    public function storeLeave(): void
    {
        $this->validateCsrf();

        $employee = \App\Core\Database::fetch(
            "SELECT e.* FROM employees e WHERE e.user_id = ?", [Auth::id()]
        );

        $startDate = new \DateTimeImmutable($_POST['start_date']);
        $endDate = new \DateTimeImmutable($_POST['end_date']);
        $days = $startDate->diff($endDate)->days + 1;

        Leave::create([
            'employee_id' => $employee['id'],
            'type' => $_POST['type'] ?? 'paid',
            'start_date' => $_POST['start_date'],
            'end_date' => $_POST['end_date'],
            'days_count' => $days,
            'reason' => $_POST['reason'] ?? '',
        ]);

        // Notification aux RH
        \App\Models\Notification::notifyRole(
            'responsable_rh',
            'leave_request',
            'Nouvelle demande de congé',
            Auth::name() . ' a soumis une demande de congé (' . $days . ' jours)',
            '/hr/leaves'
        );

        setFlash('success', 'Demande de congé soumise.');
        $this->redirect('/hr/leaves');
    }

    public function approveLeave(int $id): void
    {
        $this->validateCsrf();
        Leave::update($id, ['status' => 'approved', 'approved_by' => Auth::id()]);
        setFlash('success', 'Congé approuvé.');
        $this->redirect('/hr/leaves');
    }

    public function rejectLeave(int $id): void
    {
        $this->validateCsrf();
        Leave::update($id, ['status' => 'rejected', 'approved_by' => Auth::id()]);
        setFlash('success', 'Congé rejeté.');
        $this->redirect('/hr/leaves');
    }

    // ==================== ÉVALUATIONS ====================

    public function evaluations(): void
    {
        $evaluations = \App\Core\Database::fetchAll(
            "SELECT ev.*, u.name as employee_name, ev2.name as evaluator_name
             FROM evaluations ev
             JOIN employees e ON ev.employee_id = e.id
             JOIN users u ON e.user_id = u.id
             LEFT JOIN users ev2 ON ev.evaluator_id = ev2.id
             ORDER BY ev.evaluation_date DESC"
        );

        $this->view('hr/evaluations', ['title' => 'Évaluations', 'evaluations' => $evaluations]);
    }

    public function createEvaluation(): void
    {
        $employees = Employee::active();
        $this->view('hr/evaluation_form', [
            'title' => 'Nouvelle évaluation',
            'employees' => $employees,
        ]);
    }

    public function storeEvaluation(): void
    {
        $this->validateCsrf();

        \App\Core\Database::insert('evaluations', [
            'employee_id' => (int)$_POST['employee_id'],
            'evaluator_id' => Auth::id(),
            'period' => $_POST['period'] ?? '',
            'rating' => (float)($_POST['rating'] ?? 0),
            'comments' => $_POST['comments'] ?? '',
            'strengths' => $_POST['strengths'] ?? '',
            'improvements' => $_POST['improvements'] ?? '',
            'evaluation_date' => date('Y-m-d'),
        ]);

        setFlash('success', 'Évaluation enregistrée.');
        $this->redirect('/hr/evaluations');
    }
}
