<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Auth;
use App\Models\Event;
use App\Models\User;

class EventController extends Controller
{
    public function index(): void
    {
        $upcoming = Event::upcoming();
        $allEvents = Event::paginate(page: (int)($_GET['page'] ?? 1), orderBy: 'start_datetime', direction: 'DESC');

        $this->view('events/index', [
            'title' => 'Événementiel & Activation',
            'upcoming' => $upcoming,
            'events' => $allEvents,
        ]);
    }

    public function create(): void
    {
        $users = User::getActive();
        $this->view('events/create', [
            'title' => 'Nouvel événement',
            'users' => $users,
        ]);
    }

    public function store(): void
    {
        $this->validateCsrf();

        Event::create([
            'title' => $_POST['title'] ?? '',
            'type' => $_POST['type'] ?? 'other',
            'start_datetime' => $_POST['start_datetime'] ?? null,
            'end_datetime' => $_POST['end_datetime'] ?? null,
            'location' => $_POST['location'] ?? '',
            'budget' => (float)($_POST['budget'] ?? 0),
            'responsible_id' => (int)($_POST['responsible_id'] ?? 0) ?: null,
            'description' => $_POST['description'] ?? '',
            'max_participants' => (int)($_POST['max_participants'] ?? 0) ?: null,
            'status' => $_POST['status'] ?? 'planning',
        ]);

        setFlash('success', 'Événement créé avec succès.');
        $this->redirect('/events');
    }

    public function show(int $id): void
    {
        $event = Event::find($id);
        if (!$event) { $this->redirect('/events'); return; }

        $participants = Event::participants($id);
        $responsible = $event['responsible_id'] ? User::find($event['responsible_id']) : null;

        $this->view('events/show', [
            'title' => $event['title'],
            'event' => $event,
            'participants' => $participants,
            'responsible' => $responsible,
        ]);
    }

    public function edit(int $id): void
    {
        $event = Event::find($id);
        if (!$event) { $this->redirect('/events'); return; }

        $users = User::getActive();
        $this->view('events/edit', [
            'title' => 'Modifier ' . $event['title'],
            'event' => $event,
            'users' => $users,
        ]);
    }

    public function update(int $id): void
    {
        $this->validateCsrf();

        Event::update($id, [
            'title' => $_POST['title'] ?? '',
            'type' => $_POST['type'] ?? 'other',
            'start_datetime' => $_POST['start_datetime'] ?? null,
            'end_datetime' => $_POST['end_datetime'] ?? null,
            'location' => $_POST['location'] ?? '',
            'budget' => (float)($_POST['budget'] ?? 0),
            'responsible_id' => (int)($_POST['responsible_id'] ?? 0) ?: null,
            'description' => $_POST['description'] ?? '',
            'max_participants' => (int)($_POST['max_participants'] ?? 0) ?: null,
            'status' => $_POST['status'] ?? 'planning',
        ]);

        setFlash('success', 'Événement mis à jour.');
        $this->redirect('/events/' . $id);
    }

    public function delete(int $id): void
    {
        $this->validateCsrf();
        Event::update($id, ['status' => 'cancelled']);
        setFlash('success', 'Événement annulé.');
        $this->redirect('/events');
    }
}
