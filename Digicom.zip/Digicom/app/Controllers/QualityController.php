<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Auth;
use App\Core\Database;
use App\Models\Document;
use App\Models\Project;

class QualityController extends Controller
{
    public function index(): void
    {
        $ncCount = Database::fetch("SELECT COUNT(*) FROM non_conformities WHERE status IN ('open','investigating')")['COUNT(*)'];
        $auditCount = Database::fetch("SELECT COUNT(*) FROM audits WHERE status = 'in_progress'")['COUNT(*)'];
        $satisfactionAvg = Database::fetch("SELECT AVG(rating) as avg FROM satisfaction_surveys")['avg'] ?? 0;

        $this->view('quality/index', [
            'title' => 'Assurance Qualité',
            'ncCount' => $ncCount,
            'auditCount' => $auditCount,
            'satisfactionAvg' => round((float)$satisfactionAvg, 1),
        ]);
    }

    public function procedures(): void
    {
        $procedures = Document::findAllBy('category', 'procedure', 'title ASC');
        $this->view('quality/procedures', [
            'title' => 'Procédures Qualité',
            'procedures' => $procedures,
        ]);
    }

    public function nonConformities(): void
    {
        $ncs = Database::fetchAll(
            "SELECT nc.*, u1.name as reporter_name, u2.name as assignee_name
             FROM non_conformities nc
             LEFT JOIN users u1 ON nc.reported_by = u1.id
             LEFT JOIN users u2 ON nc.assigned_to = u2.id
             ORDER BY nc.status, nc.created_at DESC"
        );

        $this->view('quality/non_conformities', [
            'title' => 'Non-conformités',
            'nonConformities' => $ncs,
        ]);
    }

    public function storeNC(): void
    {
        $this->validateCsrf();

        Database::insert('non_conformities', [
            'reference' => 'NC-' . date('Ymd') . '-' . rand(100, 999),
            'title' => $_POST['title'] ?? '',
            'description' => $_POST['description'] ?? '',
            'severity' => $_POST['severity'] ?? 'minor',
            'source' => $_POST['source'] ?? '',
            'reported_by' => Auth::id(),
            'assigned_to' => (int)($_POST['assigned_to'] ?? 0) ?: null,
        ]);

        setFlash('success', 'Non-conformité enregistrée.');
        $this->redirect('/quality/non-conformities');
    }

    public function audits(): void
    {
        $audits = Database::fetchAll(
            "SELECT a.*, u.name as auditor_name
             FROM audits a
             LEFT JOIN users u ON a.auditor_id = u.id
             ORDER BY a.audit_date DESC"
        );

        $this->view('quality/audits', [
            'title' => 'Audits internes',
            'audits' => $audits,
        ]);
    }

    public function satisfaction(): void
    {
        $surveys = Database::fetchAll(
            "SELECT ss.*, c.company_name
             FROM satisfaction_surveys ss
             LEFT JOIN clients c ON ss.client_id = c.id
             ORDER BY ss.submitted_at DESC"
        );

        $average = Database::fetch("SELECT AVG(rating) as avg FROM satisfaction_surveys")['avg'] ?? 0;
        $count = (int)Database::fetch("SELECT COUNT(*) FROM satisfaction_surveys")['COUNT(*)'];

        $this->view('quality/satisfaction', [
            'title' => 'Satisfaction client',
            'surveys' => $surveys,
            'averageRating' => round((float)$average, 1),
            'totalSurveys' => $count,
        ]);
    }
}
