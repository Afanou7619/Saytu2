<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Auth;
use App\Models\Document;
use App\Models\Project;

class DocumentController extends Controller
{
    public function index(): void
    {
        $category = $_GET['category'] ?? '';
        $search = $_GET['search'] ?? '';

        if ($search) {
            $documents = Document::search($search);
        } elseif ($category) {
            $documents = Document::byCategory($category);
        } else {
            $docs = Document::paginate(page: (int)($_GET['page'] ?? 1), orderBy: 'created_at');
            $documents = $docs['items'];
        }

        $this->view('documents/index', [
            'title' => 'Gestion documentaire',
            'documents' => $documents,
            'filterCategory' => $category,
            'search' => $search,
        ]);
    }

    public function uploadForm(): void
    {
        $projects = Project::all('title', 'ASC');
        $this->view('documents/upload', [
            'title' => 'Uploader un document',
            'projects' => $projects,
        ]);
    }

    public function upload(): void
    {
        $this->validateCsrf();

        $file = $_FILES['file'] ?? null;
        if (!$file || $file['error'] !== UPLOAD_ERR_OK) {
            setFlash('error', 'Erreur lors de l\'upload du fichier.');
            $this->redirect('/documents/upload');
            return;
        }

        // Validation
        $maxSize = config('app.upload.max_size', 10485760);
        $allowedTypes = config('app.upload.allowed_types', []);

        if ($file['size'] > $maxSize) {
            setFlash('error', 'Fichier trop volumineux (max ' . ($maxSize / 1048576) . ' MB).');
            $this->redirect('/documents/upload');
            return;
        }

        $finfo = new \finfo(FILEINFO_MIME_TYPE);
        $mimeType = $finfo->file($file['tmp_name']);

        if (!in_array($mimeType, $allowedTypes)) {
            setFlash('error', 'Type de fichier non autorisé : ' . $mimeType);
            $this->redirect('/documents/upload');
            return;
        }

        // Stockage
        $uploadDir = STORAGE_PATH . '/uploads/documents/';
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }

        $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
        $filename = uniqid('doc_') . '.' . $ext;
        $filePath = $uploadDir . $filename;

        if (!move_uploaded_file($file['tmp_name'], $filePath)) {
            setFlash('error', 'Échec de l\'enregistrement du fichier.');
            $this->redirect('/documents/upload');
            return;
        }

        Document::create([
            'title' => $_POST['title'] ?? $file['name'],
            'category' => $_POST['category'] ?? 'other',
            'file_path' => 'uploads/documents/' . $filename,
            'file_type' => $mimeType,
            'file_size' => $file['size'],
            'access_level' => $_POST['access_level'] ?? 'internal',
            'uploaded_by' => Auth::id(),
            'project_id' => (int)($_POST['project_id'] ?? 0) ?: null,
            'version' => '1.0',
        ]);

        setFlash('success', 'Document uploadé avec succès.');
        $this->redirect('/documents');
    }

    public function show(int $id): void
    {
        $document = Document::find($id);
        if (!$document) { $this->redirect('/documents'); return; }

        $this->view('documents/show', [
            'title' => $document['title'],
            'document' => $document,
        ]);
    }

    public function download(int $id): void
    {
        $document = Document::find($id);
        if (!$document) { $this->redirect('/documents'); return; }

        $filePath = STORAGE_PATH . '/' . $document['file_path'];
        if (!file_exists($filePath)) {
            setFlash('error', 'Fichier introuvable.');
            $this->redirect('/documents');
            return;
        }

        header('Content-Type: ' . $document['file_type']);
        header('Content-Disposition: attachment; filename="' . $document['title'] . '"');
        header('Content-Length: ' . filesize($filePath));
        readfile($filePath);
        exit;
    }

    public function delete(int $id): void
    {
        $this->validateCsrf();
        Document::delete($id);
        setFlash('success', 'Document supprimé.');
        $this->redirect('/documents');
    }
}
