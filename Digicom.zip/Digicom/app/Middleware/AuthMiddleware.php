<?php
declare(strict_types=1);

namespace App\Middleware;

use App\Core\Middleware;
use App\Core\Auth;

class AuthMiddleware extends Middleware
{
    public function handle(): void
    {
        if (!Auth::check()) {
            // Stocker l'URL demandée pour redirection après login
            $_SESSION["_intended_url"] = $_SERVER["REQUEST_URI"];
            $this->redirectToLogin();
        }

        // Vérifier si le mot de passe doit être changé
        if (Auth::mustChangePassword()) {
            $currentPath = parse_url($_SERVER["REQUEST_URI"], PHP_URL_PATH);
            if (defined("BASE_URL") && BASE_URL !== "" && str_starts_with($currentPath, BASE_URL)) {
                $currentPath = substr($currentPath, strlen(BASE_URL));
            }
            $allowedPaths = ["/change-password", "/logout"];

            if (!in_array($currentPath, $allowedPaths)) {
                header("Location: " . url("/change-password"));
                exit();
            }
        }
    }
}
