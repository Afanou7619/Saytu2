<?php
declare(strict_types=1);

namespace App\Middleware;

use App\Core\Middleware;

class CsrfMiddleware extends Middleware
{
    public function handle(): void
    {
        if ($_SERVER["REQUEST_METHOD"] === "POST") {
            // Exclure les requêtes API si nécessaire
            $contentType = $_SERVER["CONTENT_TYPE"] ?? "";
            if (str_contains($contentType, "application/json")) {
                return;
            }

            $token = $_POST["csrf_token"] ?? "";

            if (!self::verify($token)) {
                http_response_code(403);
                setFlash("error", "Token CSRF invalide. Veuillez réessayer.");
                header("Location: " . ($_SERVER["HTTP_REFERER"] ?? url("/")));
                exit();
            }
        }
    }

    /**
     * Génère un token CSRF
     */
    public static function generate(): string
    {
        if (empty($_SESSION["csrf_token"])) {
            $_SESSION["csrf_token"] = bin2hex(random_bytes(32));
        }
        return $_SESSION["csrf_token"];
    }

    /**
     * Vérifie un token CSRF
     */
    public static function verify(string $token): bool
    {
        if (empty($_SESSION["csrf_token"]) || empty($token)) {
            return false;
        }
        return hash_equals($_SESSION["csrf_token"], $token);
    }

    /**
     * Génère le champ hidden pour les formulaires
     */
    public static function field(): string
    {
        $token = self::generate();
        return '<input type="hidden" name="csrf_token" value="' .
            e($token) .
            '">';
    }

    /**
     * Régénère le token (après soumission réussie)
     */
    public static function regenerate(): void
    {
        unset($_SESSION["csrf_token"]);
        self::generate();
    }
}
