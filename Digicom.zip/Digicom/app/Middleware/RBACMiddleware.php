<?php
declare(strict_types=1);

namespace App\Middleware;

use App\Core\Middleware;
use App\Core\Auth;

class RBACMiddleware extends Middleware
{
    private string $module;
    private string $action;

    public function __construct(string $module = '', string $action = 'read')
    {
        $this->module = $module;
        $this->action = $action;
    }

    public function setPermissions(string $module, string $action = 'read'): void
    {
        $this->module = $module;
        $this->action = $action;
    }

    public function handle(): void
    {
        if (!Auth::check()) {
            $this->redirectToLogin();
            return;
        }

        if (!Auth::can($this->module, $this->action)) {
            $this->abort(403, "Accès non autorisé au module {$this->module}");
        }
    }
}
