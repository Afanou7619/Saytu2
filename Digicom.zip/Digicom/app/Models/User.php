<?php
declare(strict_types=1);

namespace App\Models;

use App\Core\Model;
use App\Core\Database;

class User extends Model
{
    protected static string $table = 'users';
    protected static string $primaryKey = 'id';
    protected static array $fillable = [
        'name', 'email', 'password', 'role', 'status',
        'avatar', 'phone', 'two_factor_secret', 'two_factor_enabled',
        'must_change_password', 'created_by',
    ];

    public static function findByEmail(string $email): ?array
    {
        return static::findBy('email', $email);
    }

    public static function updateLastLogin(int $id): void
    {
        Database::update(static::$table, ['last_login' => date('Y-m-d H:i:s')], 'id = ?', [$id]);
    }

    public static function getByRole(string $role): array
    {
        return static::findAllBy('role', $role, 'name ASC');
    }

    public static function getActive(): array
    {
        return Database::fetchAll("SELECT * FROM " . static::$table . " WHERE status = 'active' ORDER BY name ASC");
    }
}
