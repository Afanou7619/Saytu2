<?php
declare(strict_types=1);

namespace App\Models;

use App\Core\Model;
use App\Core\Database;

class Quote extends Model
{
    protected static string $table = 'quotes';
    protected static array $fillable = [
        'reference', 'client_id', 'project_id', 'created_by',
        'status', 'total_ht', 'tax_rate', 'total_ttc',
        'valid_until', 'notes',
    ];

    public static function generateReference(): string
    {
        $year = date('Y');
        $count = Database::fetch(
            "SELECT COUNT(*) FROM " . static::$table . " WHERE created_at >= ?",
            [$year . '-01-01']
        )['COUNT(*)'];
        return sprintf('DEV-%s-%04d', $year, (int)$count + 1);
    }

    public static function items(int $quoteId): array
    {
        return Database::fetchAll(
            "SELECT * FROM quote_items WHERE quote_id = ?", [$quoteId]
        );
    }

    public static function addItem(int $quoteId, array $data): int
    {
        $data['quote_id'] = $quoteId;
        $data['total'] = ($data['quantity'] ?? 1) * ($data['unit_price'] ?? 0);
        return Database::insert('quote_items', $data);
    }

    public static function updateItem(int $itemId, array $data): void
    {
        $data['total'] = ($data['quantity'] ?? 1) * ($data['unit_price'] ?? 0);
        Database::update('quote_items', $data, 'id = ?', [$itemId]);
    }

    public static function deleteItem(int $itemId): void
    {
        Database::delete('quote_items', 'id = ?', [$itemId]);
    }

    public static function pending(): array
    {
        return Database::fetchAll(
            "SELECT q.*, c.company_name as client_name
             FROM " . static::$table . " q
             JOIN clients c ON q.client_id = c.id
             WHERE q.status IN ('draft', 'sent')
             ORDER BY q.created_at DESC"
        );
    }

    public static function updateTotals(int $quoteId): void
    {
        $items = static::items($quoteId);
        $totalHt = array_sum(array_column($items, 'total'));

        $quote = static::find($quoteId);
        $taxRate = $quote['tax_rate'] ?? 18;
        $totalTtc = $totalHt * (1 + $taxRate / 100);

        Database::update(static::$table, [
            'total_ht' => $totalHt,
            'total_ttc' => $totalTtc,
        ], 'id = ?', [$quoteId]);
    }
}
