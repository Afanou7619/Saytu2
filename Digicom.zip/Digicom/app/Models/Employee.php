<?php
declare(strict_types=1);

namespace App\Models;

use App\Core\Model;
use App\Core\Database;

class Employee extends Model
{
    protected static string $table = 'employees';
    protected static array $fillable = [
        'user_id', 'employee_number', 'position', 'department',
        'contract_type', 'hire_date', 'end_date', 'salary', 'manager_id', 'status',
    ];

    public static function generateNumber(): string
    {
        $count = static::count() + 1;
        return 'EMP-' . str_pad((string)$count, 4, '0', STR_PAD_LEFT);
    }

    public static function allWithUser(): array
    {
        return Database::fetchAll(
            "SELECT e.*, u.name, u.email, u.phone, u.avatar, u.status as user_status,
                    m.name as manager_name
             FROM " . static::$table . " e
             JOIN users u ON e.user_id = u.id
             LEFT JOIN users m ON e.manager_id = m.id
             ORDER BY e.department, u.name"
        );
    }

    public static function active(): array
    {
        return Database::fetchAll(
            "SELECT e.*, u.name
             FROM " . static::$table . " e
             JOIN users u ON e.user_id = u.id
             WHERE e.status = 'active'
             ORDER BY u.name"
        );
    }

    public static function byDepartment(string $department): array
    {
        return static::findAllBy('department', $department, 'user_id');
    }
}
