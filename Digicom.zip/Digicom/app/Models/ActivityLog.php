<?php
declare(strict_types=1);

namespace App\Models;

use App\Core\Model;
use App\Core\Database;

class ActivityLog extends Model
{
    protected static string $table = 'activity_logs';
    protected static array $fillable = [
        'user_id', 'action', 'module', 'details', 'ip_address', 'user_agent',
    ];

    /**
     * Enregistre une action dans le journal
     */
    public static function record(?int $userId, string $action, mixed $details = null, string $module = ''): void
    {
        try {
            static::create([
                'user_id' => $userId,
                'action' => $action,
                'module' => $module ?: static::guessModule(),
                'details' => $details ? json_encode($details, JSON_UNESCAPED_UNICODE) : null,
                'ip_address' => $_SERVER['REMOTE_ADDR'] ?? null,
                'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? null,
            ]);
        } catch (\Throwable $e) {
            // Silencieux : ne pas bloquer l'application pour un log
        }
    }

    private static function guessModule(): string
    {
        $uri = $_SERVER['REQUEST_URI'] ?? '';
        $parts = explode('/', trim($uri, '/'));
        return $parts[0] ?: 'dashboard';
    }

    public static function recent(int $limit = 50): array
    {
        return Database::fetchAll(
            "SELECT al.*, u.name as user_name
             FROM " . static::$table . " al
             LEFT JOIN users u ON al.user_id = u.id
             ORDER BY al.created_at DESC
             LIMIT ?",
            [$limit]
        );
    }

    public static function byUser(int $userId, int $limit = 100): array
    {
        return Database::fetchAll(
            "SELECT * FROM " . static::$table . "
             WHERE user_id = ?
             ORDER BY created_at DESC
             LIMIT ?",
            [$userId, $limit]
        );
    }
}
