<?php
declare(strict_types=1);

namespace App\Models;

use App\Core\Model;
use App\Core\Database;

class Project extends Model
{
    protected static string $table = 'projects';
    protected static array $fillable = [
        'title', 'client_id', 'manager_id', 'status', 'start_date',
        'end_date', 'budget', 'spent', 'progress', 'description', 'created_by',
    ];

    public static function activeProjects(): array
    {
        return Database::fetchAll(
            "SELECT p.*, c.company_name as client_name, u.name as manager_name
             FROM " . static::$table . " p
             LEFT JOIN clients c ON p.client_id = c.id
             LEFT JOIN users u ON p.manager_id = u.id
             WHERE p.status IN ('active', 'on_hold')
             ORDER BY p.end_date ASC"
        );
    }

    public static function completedProjects(): array
    {
        return static::findAllBy('status', 'completed', 'end_date DESC');
    }

    public static function byClient(int $clientId): array
    {
        return static::findAllBy('client_id', $clientId, 'created_at DESC');
    }

    public static function updateProgress(int $projectId): void
    {
        $tasks = Database::fetchAll(
            "SELECT COUNT(*) as total, SUM(CASE WHEN status = 'done' THEN 1 ELSE 0 END) as done
             FROM tasks WHERE project_id = ?", [$projectId]
        );

        $total = (int)($tasks[0]['total'] ?? 0);
        $done = (int)($tasks[0]['done'] ?? 0);
        $progress = $total > 0 ? round(($done / $total) * 100) : 0;

        Database::update(static::$table, ['progress' => $progress], 'id = ?', [$projectId]);
    }
}
