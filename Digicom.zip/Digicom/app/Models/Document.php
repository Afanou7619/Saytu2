<?php
declare(strict_types=1);

namespace App\Models;

use App\Core\Model;
use App\Core\Database;

class Document extends Model
{
    protected static string $table = 'documents';
    protected static array $fillable = [
        'title', 'category', 'file_path', 'file_type', 'file_size',
        'access_level', 'uploaded_by', 'project_id', 'task_id', 'version',
    ];

    public static function byCategory(string $category): array
    {
        return static::findAllBy('category', $category, 'created_at DESC');
    }

    public static function byProject(int $projectId): array
    {
        return static::findAllBy('project_id', $projectId, 'created_at DESC');
    }

    public static function search(string $query): array
    {
        return Database::fetchAll(
            "SELECT * FROM " . static::$table . "
             WHERE title LIKE ? OR file_type LIKE ?
             ORDER BY created_at DESC",
            ["%{$query}%", "%{$query}%"]
        );
    }
}
