<?php
declare(strict_types=1);

namespace App\Models;

use App\Core\Model;
use App\Core\Database;

class Leave extends Model
{
    protected static string $table = 'leaves';
    protected static array $fillable = [
        'employee_id', 'type', 'start_date', 'end_date',
        'days_count', 'status', 'approved_by', 'reason',
    ];

    public static function pending(): array
    {
        return Database::fetchAll(
            "SELECT l.*, e.employee_number, u.name as employee_name, e.department
             FROM " . static::$table . " l
             JOIN employees e ON l.employee_id = e.id
             JOIN users u ON e.user_id = u.id
             WHERE l.status = 'pending'
             ORDER BY l.start_date ASC"
        );
    }

    public static function byEmployee(int $employeeId): array
    {
        return static::findAllBy('employee_id', $employeeId, 'start_date DESC');
    }

    public static function todayAbsences(): array
    {
        return Database::fetchAll(
            "SELECT l.*, u.name
             FROM " . static::$table . " l
             JOIN employees e ON l.employee_id = e.id
             JOIN users u ON e.user_id = u.id
             WHERE l.status = 'approved'
               AND CURDATE() BETWEEN l.start_date AND l.end_date"
        );
    }
}
