<?php
declare(strict_types=1);

namespace App\Models;

use App\Core\Model;
use App\Core\Database;

class Transaction extends Model
{
    protected static string $table = 'transactions';
    protected static array $fillable = [
        'type', 'category', 'amount', 'currency', 'description',
        'reference', 'invoice_id', 'account', 'transaction_date',
        'created_by', 'validated_by', 'status',
    ];

    public static function monthlySummary(int $year, int $month): array
    {
        return Database::fetch(
            "SELECT
                COALESCE(SUM(CASE WHEN type = 'income' THEN amount ELSE 0 END), 0) as income,
                COALESCE(SUM(CASE WHEN type = 'expense' THEN amount ELSE 0 END), 0) as expense
             FROM " . static::$table . "
             WHERE status = 'validated'
               AND YEAR(transaction_date) = ?
               AND MONTH(transaction_date) = ?",
            [$year, $month]
        );
    }

    public static function yearlySummary(int $year): array
    {
        return Database::fetchAll(
            "SELECT
                MONTH(transaction_date) as month,
                COALESCE(SUM(CASE WHEN type = 'income' THEN amount ELSE 0 END), 0) as income,
                COALESCE(SUM(CASE WHEN type = 'expense' THEN amount ELSE 0 END), 0) as expense
             FROM " . static::$table . "
             WHERE status = 'validated' AND YEAR(transaction_date) = ?
             GROUP BY MONTH(transaction_date)
             ORDER BY month",
            [$year]
        );
    }

    public static function byCategory(string $type = 'expense', int $year = 0): array
    {
        $year = $year ?: (int)date('Y');
        return Database::fetchAll(
            "SELECT category, SUM(amount) as total
             FROM " . static::$table . "
             WHERE type = ? AND status = 'validated' AND YEAR(transaction_date) = ?
             GROUP BY category
             ORDER BY total DESC",
            [$type, $year]
        );
    }
}
