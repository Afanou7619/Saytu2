<?php
declare(strict_types=1);

namespace App\Models;

use App\Core\Model;
use App\Core\Database;

class Notification extends Model
{
    protected static string $table = 'notifications';
    protected static array $fillable = [
        'user_id', 'type', 'title', 'message', 'link', 'is_read',
    ];

    public static function forUser(int $userId, int $limit = 50): array
    {
        return Database::fetchAll(
            "SELECT * FROM " . static::$table . "
             WHERE user_id = ?
             ORDER BY created_at DESC
             LIMIT ?",
            [$userId, $limit]
        );
    }

    public static function unreadCount(int $userId): int
    {
        return (int) Database::fetch(
            "SELECT COUNT(*) FROM " . static::$table . "
             WHERE user_id = ? AND is_read = 0",
            [$userId]
        )['COUNT(*)'];
    }

    public static function markRead(int $id): void
    {
        Database::update(static::$table, ['is_read' => 1], 'id = ?', [$id]);
    }

    public static function markAllRead(int $userId): void
    {
        Database::update(static::$table, ['is_read' => 1], 'user_id = ? AND is_read = 0', [$userId]);
    }

    /**
     * Crée une notification et l'envoie
     */
    public static function notify(int $userId, string $type, string $title, string $message, string $link = ''): int
    {
        return static::create([
            'user_id' => $userId,
            'type' => $type,
            'title' => $title,
            'message' => $message,
            'link' => $link,
        ]);
    }

    /**
     * Notifie tous les utilisateurs d'un rôle
     */
    public static function notifyRole(string $role, string $type, string $title, string $message, string $link = ''): void
    {
        $users = Database::fetchAll("SELECT id FROM users WHERE role = ? AND status = 'active'", [$role]);
        foreach ($users as $user) {
            static::notify((int)$user['id'], $type, $title, $message, $link);
        }
    }
}
