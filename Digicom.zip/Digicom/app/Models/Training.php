<?php
declare(strict_types=1);

namespace App\Models;

use App\Core\Model;
use App\Core\Database;

class Training extends Model
{
    protected static string $table = 'trainings';
    protected static array $fillable = [
        'title', 'category', 'description', 'price', 'duration_hours',
        'max_participants', 'trainer_id', 'status', 'start_date', 'end_date',
    ];

    public static function published(): array
    {
        return Database::fetchAll(
            "SELECT t.*, u.name as trainer_name
             FROM " . static::$table . " t
             LEFT JOIN users u ON t.trainer_id = u.id
             WHERE t.status IN ('published', 'ongoing')
             ORDER BY t.start_date ASC"
        );
    }

    public static function registrations(int $trainingId): array
    {
        return Database::fetchAll(
            "SELECT * FROM training_registrations WHERE training_id = ? ORDER BY registered_at DESC",
            [$trainingId]
        );
    }

    public static function register(int $trainingId, array $data): int
    {
        $data['training_id'] = $trainingId;
        return Database::insert('training_registrations', $data);
    }

    public static function updateRegistrationStatus(int $regId, string $status): void
    {
        Database::update('training_registrations', ['status' => $status], 'id = ?', [$regId]);
    }

    public static function totalRegistrations(int $trainingId): int
    {
        return (int) Database::fetch(
            "SELECT COUNT(*) FROM training_registrations WHERE training_id = ?",
            [$trainingId]
        )['COUNT(*)'];
    }
}
