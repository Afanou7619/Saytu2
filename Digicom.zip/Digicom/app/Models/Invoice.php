<?php
declare(strict_types=1);

namespace App\Models;

use App\Core\Model;
use App\Core\Database;

class Invoice extends Model
{
    protected static string $table = 'invoices';
    protected static array $fillable = [
        'reference', 'quote_id', 'client_id', 'project_id',
        'status', 'total_ht', 'tax_rate', 'total_ttc', 'paid_amount',
        'due_date', 'paid_at', 'created_by',
    ];

    public static function generateReference(): string
    {
        $year = date('Y');
        $count = Database::fetch(
            "SELECT COUNT(*) FROM " . static::$table . " WHERE created_at >= ?",
            [$year . '-01-01']
        )['COUNT(*)'];
        return sprintf('FAC-%s-%04d', $year, (int)$count + 1);
    }

    public static function items(int $invoiceId): array
    {
        return Database::fetchAll(
            "SELECT * FROM invoice_items WHERE invoice_id = ?", [$invoiceId]
        );
    }

    public static function addItem(int $invoiceId, array $data): int
    {
        $data['invoice_id'] = $invoiceId;
        $data['total'] = ($data['quantity'] ?? 1) * ($data['unit_price'] ?? 0);
        return Database::insert('invoice_items', $data);
    }

    public static function payments(int $invoiceId): array
    {
        return Database::fetchAll(
            "SELECT * FROM payments WHERE invoice_id = ? ORDER BY payment_date DESC",
            [$invoiceId]
        );
    }

    public static function addPayment(array $data): int
    {
        $id = Database::insert('payments', $data);

        // Mise à jour du montant payé et statut
        $invoice = static::find($data['invoice_id']);
        $totalPaid = Database::fetch(
            "SELECT COALESCE(SUM(amount), 0) as total FROM payments WHERE invoice_id = ?",
            [$data['invoice_id']]
        )['total'];

        $status = $invoice['status'];
        if ($totalPaid >= $invoice['total_ttc']) {
            $status = 'paid';
            Database::update(static::$table, [
                'paid_amount' => $totalPaid,
                'status' => 'paid',
                'paid_at' => date('Y-m-d H:i:s'),
            ], 'id = ?', [$data['invoice_id']]);
        } elseif ($totalPaid > 0) {
            Database::update(static::$table, [
                'paid_amount' => $totalPaid,
                'status' => 'partial',
            ], 'id = ?', [$data['invoice_id']]);
        }

        return $id;
    }

    public static function overdue(): array
    {
        return Database::fetchAll(
            "SELECT i.*, c.company_name as client_name
             FROM " . static::$table . " i
             JOIN clients c ON i.client_id = c.id
             WHERE i.due_date < CURDATE() AND i.status NOT IN ('paid', 'cancelled')
             ORDER BY i.due_date ASC"
        );
    }

    public static function updateTotals(int $invoiceId): void
    {
        $items = static::items($invoiceId);
        $totalHt = array_sum(array_column($items, 'total'));

        $invoice = static::find($invoiceId);
        $taxRate = $invoice['tax_rate'] ?? 18;
        $totalTtc = $totalHt * (1 + $taxRate / 100);

        Database::update(static::$table, [
            'total_ht' => $totalHt,
            'total_ttc' => $totalTtc,
        ], 'id = ?', [$invoiceId]);
    }
}
