<?php
declare(strict_types=1);

namespace App\Models;

use App\Core\Model;

class Client extends Model
{
    protected static string $table = 'clients';
    protected static array $fillable = [
        'type', 'company_name', 'contact_name', 'email', 'phone',
        'address', 'segment', 'source', 'status', 'pipeline_stage',
        'assigned_to', 'notes',
    ];

    public static function prospects(): array
    {
        return static::findAllBy('type', 'prospect', 'created_at DESC');
    }

    public static function clientsActifs(): array
    {
        return static::findAllBy('type', 'client', 'company_name ASC');
    }

    public static function byStage(string $stage): array
    {
        return Database::fetchAll(
            "SELECT c.*, u.name as assigned_name FROM " . static::$table . " c
             LEFT JOIN users u ON c.assigned_to = u.id
             WHERE c.pipeline_stage = ? ORDER BY c.created_at DESC",
            [$stage]
        );
    }

    public static function kanbanData(): array
    {
        $stages = ['nouveau', 'contacte', 'devis_envoye', 'negociation', 'gagne', 'perdu'];
        $data = [];
        foreach ($stages as $stage) {
            $data[$stage] = static::byStage($stage);
        }
        return $data;
    }
}
