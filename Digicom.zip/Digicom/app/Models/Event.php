<?php
declare(strict_types=1);

namespace App\Models;

use App\Core\Model;
use App\Core\Database;

class Event extends Model
{
    protected static string $table = 'events';
    protected static array $fillable = [
        'title', 'type', 'start_datetime', 'end_datetime', 'location',
        'budget', 'spent', 'status', 'responsible_id', 'description', 'max_participants',
    ];

    public static function upcoming(): array
    {
        return Database::fetchAll(
            "SELECT e.*, u.name as responsible_name
             FROM " . static::$table . " e
             LEFT JOIN users u ON e.responsible_id = u.id
             WHERE e.start_datetime >= NOW() AND e.status != 'cancelled'
             ORDER BY e.start_datetime ASC"
        );
    }

    public static function participants(int $eventId): array
    {
        return Database::fetchAll(
            "SELECT * FROM event_participants WHERE event_id = ? ORDER BY registered_at DESC",
            [$eventId]
        );
    }

    public static function addParticipant(int $eventId, array $data): int
    {
        $data['event_id'] = $eventId;
        return Database::insert('event_participants', $data);
    }
}
