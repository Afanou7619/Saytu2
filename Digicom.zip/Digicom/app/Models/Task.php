<?php
declare(strict_types=1);

namespace App\Models;

use App\Core\Model;
use App\Core\Database;

class Task extends Model
{
    protected static string $table = 'tasks';
    protected static array $fillable = [
        'project_id', 'title', 'description', 'assigned_to',
        'status', 'priority', 'due_date', 'due_time', 'created_by',
    ];

    public static function byProject(int $projectId): array
    {
        return Database::fetchAll(
            "SELECT t.*, u.name as assigned_name
             FROM " . static::$table . " t
             LEFT JOIN users u ON t.assigned_to = u.id
             WHERE t.project_id = ?
             ORDER BY t.priority DESC, t.due_date ASC",
            [$projectId]
        );
    }

    public static function byUser(int $userId): array
    {
        return Database::fetchAll(
            "SELECT t.*, p.title as project_title
             FROM " . static::$table . " t
             JOIN projects p ON t.project_id = p.id
             WHERE t.assigned_to = ? AND t.status != 'done'
             ORDER BY t.due_date ASC",
            [$userId]
        );
    }

    public static function overdue(): array
    {
        return Database::fetchAll(
            "SELECT t.*, p.title as project_title, u.name as assigned_name
             FROM " . static::$table . " t
             JOIN projects p ON t.project_id = p.id
             LEFT JOIN users u ON t.assigned_to = u.id
             WHERE t.due_date < CURDATE() AND t.status NOT IN ('done', 'review')"
        );
    }

    public static function comments(int $taskId): array
    {
        return Database::fetchAll(
            "SELECT c.*, u.name as user_name
             FROM task_comments c
             JOIN users u ON c.user_id = u.id
             WHERE c.task_id = ?
             ORDER BY c.created_at ASC",
            [$taskId]
        );
    }

    public static function addComment(int $taskId, int $userId, string $content): int
    {
        return Database::insert('task_comments', [
            'task_id' => $taskId,
            'user_id' => $userId,
            'content' => $content,
        ]);
    }
}
